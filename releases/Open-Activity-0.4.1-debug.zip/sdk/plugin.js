'use strict';
// Open Activity config-only sources; see bundled LICENSE.
(function(modules){var cache={};function load(id){if(cache[id])return cache[id].exports;var module={exports:{}};cache[id]=module;modules[id](module,module.exports,load);return module.exports;}load(0);})([
function(module,exports,require){
'use strict';

var settings = require(1);
var uiSettings = require(2);
var preferences=require(3);

var uiPreferences=preferences.create({storage:localStorage});
function preferenceRequest(message){var result;uiPreferences.handle(message,function(value){result=value;});return result;}

// A config-only plugin allows phone settings while the transition watchapp is
// closed. It ships inside the same PBW/UUID and exposes no sources or actions.
Pebble.registerConfigHandler(function (message, respond) {
  try {
    if(typeof message==='string')message=JSON.parse(message);
    if(preferences.isRequest(message)){uiPreferences.handle(message,respond);return;}
    if (!message || message.type === 'getSettings' || message.type === 'load_settings') {
      var current = settings.load(localStorage);
      var loaded = {ok: true, settings: settings.choices(current || settings.defaults()), needsRepair: !current,
        needsMigration: !!current && current.version === 1};
      if (message && message.uiVersion === 1) {
        var appearance = uiSettings.load(localStorage); loaded.appearance = appearance || uiSettings.defaults();
        loaded.needsAppearanceRepair = !appearance;
      }
      if(message&&message.includeUiPreferences)loaded.preferences=preferenceRequest({type:'getUiPreferences'});
      respond(loaded);
    } else if (message.type === 'saveSettings' || message.type === 'save_settings') {
      var normalized = settings.normalize(message.settings);
      var selected = normalized && settings.choices(normalized);
      var appearance = message.uiVersion === 1 ? uiSettings.normalize(message.appearance) : undefined;
      var display=message.preferences===undefined?null:preferences.normalize(message.preferences);
      if (!selected || message.uiVersion === 1 && !appearance || message.preferences!==undefined&&(!display||!appearance||display.lastExplicit!==appearance.theme)) {respond(message.uiVersion === 1 ? {ok: false, rejected: true} : {ok: false}); return;}
      if (!settings.save(localStorage, selected) || appearance && !uiSettings.save(localStorage, appearance)) {respond({ok: false}); return;}
      var receipt = {ok: true, settings: selected};
      if(display){receipt.preferences=preferenceRequest({type:'saveUiPreferences',settings:display});if(!receipt.preferences.ok){respond({ok:false});return;}}
      if (appearance) { receipt.appearance = appearance; receipt.watchDelivery = 'deferred'; }
      respond(receipt);
    } else respond({ok: false});
  } catch (error) { respond({ok: false}); }
});

},
function(module,exports,require){
'use strict';

var KEY = 'open-activity-settings-v1';
var SHORTCUTS = [
  {id: 'hold-up', label: 'Hold Up', button: 1, gesture: 1},
  {id: 'hold-select', label: 'Hold Center', button: 2, gesture: 1},
  {id: 'hold-down', label: 'Hold Down', button: 3, gesture: 1},
  {id: 'hold-back', label: 'Hold Back', button: 0, gesture: 1},
  {id: 'tap-up', label: 'Tap Up', button: 1, gesture: 2},
  {id: 'tap-down', label: 'Tap Down', button: 3, gesture: 2},
  {id: 'combo-back-up', label: 'Hold Back + Up', button: 0, gesture: 3},
  {id: 'combo-up-down', label: 'Hold Up + Down', button: 1, gesture: 3}
];
function role(value) { return value === 'primary' || value === 'secondary'; }
function object(value) { return !!value && typeof value === 'object' && !Array.isArray(value); }
function only(value, allowed) {
  return Object.keys(value).every(function (key) { return allowed.indexOf(key) !== -1; });
}
function defaults() {
  return {version: 2, primaryShortcut: 'hold-down', secondaryShortcut: 'hold-up'};
}
function shortcutId(value) {
  if (value === 'none') return true;
  return SHORTCUTS.some(function (shortcut) { return shortcut.id === value; });
}
function overrides(value, buttons) {
  if (!object(value) || !only(value, buttons)) return null;
  var output = {};
  for (var i = 0; i < buttons.length; i++) {
    var button = buttons[i];
    if (!Object.prototype.hasOwnProperty.call(value, button)) continue;
    var choice = value[button];
    if (choice !== 'default' && !role(choice)) return null;
    if (choice !== 'default') output[button] = choice;
  }
  return output;
}
function normalize(value) {
  if (!object(value)) return null;
  if (value.version === 2) {
    if (!only(value, ['version', 'primaryShortcut', 'secondaryShortcut', 'watchface']) ||
        value.watchface !== undefined && value.watchface !== 'dynamic' && value.watchface !== 'halftone' ||
        !shortcutId(value.primaryShortcut) || !shortcutId(value.secondaryShortcut) ||
        value.primaryShortcut !== 'none' && value.primaryShortcut === value.secondaryShortcut) return null;
    var chosen = {version: 2, primaryShortcut: value.primaryShortcut, secondaryShortcut: value.secondaryShortcut};
    // Omitted means Dynamic, preserving existing records and the default route.
    if (value.watchface === 'halftone') chosen.watchface = 'halftone';
    return chosen;
  }
  if (!only(value, ['version', 'defaultRole', 'holdOverrides', 'tapOverrides', 'comboOverrides']) ||
      value.version !== 1 || !role(value.defaultRole)) return null;
  var holds = overrides(value.holdOverrides, ['up', 'down', 'select', 'back']);
  var taps = value.tapOverrides === undefined ? {} : overrides(value.tapOverrides, ['up', 'down']);
  var combos = value.comboOverrides === undefined ? {} : overrides(value.comboOverrides, ['backUp', 'upDown']);
  if (!holds || !taps || !combos) return null;
  var output = {version: 1, defaultRole: value.defaultRole, holdOverrides: holds};
  if (Object.keys(taps).length) output.tapOverrides = taps;
  if (Object.keys(combos).length) output.comboOverrides = combos;
  return output;
}
function load(storage) {
  try {
    var value = storage.getItem(KEY);
    return value === null || value === undefined ? defaults() : normalize(JSON.parse(value));
  } catch (error) { return null; }
}
function save(storage, value) {
  var settings = normalize(value);
  if (!settings) return false;
  try {
    var encoded = JSON.stringify(settings);
    storage.setItem(KEY, encoded);
    return storage.getItem(KEY) === encoded;
  } catch (error) { return false; }
}
function legacyOverride(settings, shortcut) {
  var name = {0: 'back', 1: 'up', 2: 'select', 3: 'down'}[shortcut.button];
  var chosen;
  if (shortcut.gesture === 1) chosen = settings.holdOverrides;
  else if (shortcut.gesture === 2) chosen = settings.tapOverrides;
  else {
    chosen = settings.comboOverrides;
    name = shortcut.button === 0 ? 'backUp' : 'upDown';
  }
  return chosen && chosen[name];
}
function select(value, button, gesture) {
  if (gesture === undefined) gesture = 1; // Existing callers select hold mappings.
  var settings = normalize(value), shortcut;
  if (!settings || typeof button !== 'number' || Math.floor(button) !== button) return null;
  for (var i = 0; i < SHORTCUTS.length; i++) {
    if (SHORTCUTS[i].button === button && SHORTCUTS[i].gesture === gesture) shortcut = SHORTCUTS[i];
  }
  if (!shortcut) return null;
  if (settings.version === 1) return legacyOverride(settings, shortcut) || settings.defaultRole;
  if (shortcut.id === settings.primaryShortcut) return 'primary';
  if (shortcut.id === settings.secondaryShortcut) return 'secondary';
  return null;
}
function choices(value) {
  var settings = normalize(value);
  if (!settings || settings.version === 2) return settings;
  function choose(target, preferred) {
    var matched = SHORTCUTS.filter(function (shortcut) {
      return (legacyOverride(settings, shortcut) || settings.defaultRole) === target;
    });
    var explicit = matched.filter(function (shortcut) { return legacyOverride(settings, shortcut) === target; });
    var preferredExplicit = explicit.filter(function (shortcut) { return shortcut.id === preferred; });
    var preferredDefault = matched.filter(function (shortcut) { return shortcut.id === preferred; });
    var selected = preferredExplicit[0] || explicit[0] || preferredDefault[0] || matched[0];
    return selected ? selected.id : 'none';
  }
  return {version: 2, primaryShortcut: choose('primary', 'hold-down'), secondaryShortcut: choose('secondary', 'hold-up')};
}
module.exports = {key: KEY, shortcuts: SHORTCUTS, defaults: defaults, normalize: normalize,
  choices: choices, load: load, save: save, select: select};

},
function(module,exports,require){
'use strict';

// UI preferences are independent of the version-1/version-2 shortcut record.
// Reading or changing appearance never rewrites legacy routing bytes.
var KEY = 'open-activity-ui-v1';
function defaults() { return {version: 1, theme: 'light'}; }
function normalize(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value) || value.version !== 1 ||
      Object.keys(value).some(function(key) { return key !== 'version' && key !== 'theme'; }) ||
      value.theme !== 'light' && value.theme !== 'dark') return null;
  return {version: 1, theme: value.theme};
}
function load(storage) {
  try {
    var raw = storage.getItem(KEY);
    return raw === null || raw === undefined ? defaults() : normalize(JSON.parse(raw));
  } catch (error) { return null; }
}
function save(storage, value) {
  var normalized = normalize(value);
  if (!normalized) return false;
  try {
    var encoded = JSON.stringify(normalized);
    if (storage.getItem(KEY) !== encoded) storage.setItem(KEY, encoded);
    return storage.getItem(KEY) === encoded;
  } catch (error) { return false; }
}
module.exports = {key: KEY, defaults: defaults, normalize: normalize, load: load, save: save};

},
function(module,exports,require){
'use strict';

var legacy=require(2);
var KEY='open-activity-ui-preferences-v1';
var sizes=['follow','small','medium','large'],looks=['follow','light','dark'];
function normalize(value){
  if(!value||value.version!==2||Object.keys(value).sort().join(',')!=='appearance,lastExplicit,textSize,version'||
      sizes.indexOf(value.textSize)<0||looks.indexOf(value.appearance)<0||
      ['light','dark'].indexOf(value.lastExplicit)<0||
      value.appearance!=='follow'&&value.appearance!==value.lastExplicit)return null;
  return {version:2,textSize:value.textSize,appearance:value.appearance,lastExplicit:value.lastExplicit};
}
function equal(a,b){return JSON.stringify(a)===JSON.stringify(b);}
function defaults(theme){return {version:2,textSize:'follow',appearance:theme,lastExplicit:theme};}
function put(bytes,at,value){for(var i=0;i<4;i++)bytes[at+i]=(value>>>(8*i))&255;}
function u32(bytes,at){return (bytes[at]|bytes[at+1]<<8|bytes[at+2]<<16|bytes[at+3]<<24)>>>0;}
function encode(settings,revision){
  var bytes=[1,3,0,0];put(bytes,4,revision);put(bytes,8,sizes.indexOf(settings.textSize));
  put(bytes,12,looks.indexOf(settings.appearance));put(bytes,16,looks.indexOf(settings.lastExplicit));return bytes;
}
function decode(input){
  if(!input||input.length!==20)return null;
  var bytes=Array.prototype.slice.call(input);
  if(!bytes.every(function(value){return Number.isInteger(value)&&value>=0&&value<=255;})||
      bytes[0]!==1||bytes[1]!==3||bytes[2]>1||bytes[3]>1)return null;
  var value=normalize({version:2,textSize:sizes[u32(bytes,8)],appearance:looks[u32(bytes,12)],lastExplicit:looks[u32(bytes,16)]});
  return value?{settings:value,revision:u32(bytes,4),status:bytes[2],hello:bytes[3]===1}:null;
}
function matches(frame,record){var value=decode(frame);return !!value&&value.status===0&&value.revision===record.revision&&equal(value.settings,record.settings);}
function next(revision){return ((revision+1)>>>0)||1;}
function isRequest(message){return message&&['getUiPreferences','saveUiPreferences','retryUiPreferences'].indexOf(message.type)>=0;}
function create(options){
  var storage=options.storage,send=options.send,later=options.later||function(fn,ms){return setTimeout(fn,ms);},cancel=options.cancel||function(id){clearTimeout(id);};
  var generation=0,timer=null,attempts=0,watchMismatch=false,closed=false,invalidatedRevision=null,revisionPending=false;
  function stop(){if(timer!==null)cancel(timer);timer=null;}
  function read(){
    var old=legacy.load(storage),raw=storage.getItem(KEY),record,stored=raw!==null&&raw!==undefined;
    if(!stored)return {healthy:!!old,stored:false,record:{version:1,settings:defaults(old?old.theme:'light'),revision:1,applied:null,error:null,legacyTheme:old?old.theme:'light'}};
    try{record=JSON.parse(raw);}catch(error){record=null;}
    if(!record||record.version!==1||!normalize(record.settings)||!Number.isInteger(record.revision)||record.revision<1||record.revision>0xffffffff||
        ['light','dark'].indexOf(record.legacyTheme)<0||record.applied!==null&&!decode(record.applied)||
        record.error!==null&&typeof record.error!=='string')
      return {healthy:false,stored:false,record:{version:1,settings:defaults(old?old.theme:'light'),revision:1,applied:null,error:null,legacyTheme:old?old.theme:'light'}};
    record.settings=normalize(record.settings);
    if(old&&old.theme!==record.legacyTheme){
      record.legacyTheme=old.theme;
      if(old.theme!==record.settings.lastExplicit){
        record.settings.appearance=old.theme;record.settings.lastExplicit=old.theme;
        record.revision=next(record.revision);record.applied=null;record.error=null;stored=false;
      }
    }
    return {healthy:true,stored:stored,record:record};
  }
  function commit(record){
    try{var encoded=JSON.stringify(record);storage.setItem(KEY,encoded);return storage.getItem(KEY)===encoded;}catch(error){return false;}
  }
  function response(state){
    var record=state.record,applied=state.healthy&&!watchMismatch&&matches(record.applied,record);
    return {ok:true,settings:record.settings,needsRepair:!state.healthy,saved:state.stored,
      delivery:{applied:applied,pending:!applied,error:record.error}};
  }
  function retry(g){
    if(g!==generation||attempts>=3||!send)return;
    stop();timer=later(function(){timer=null;if(g===generation)deliver(g);},500*attempts);
  }
  function deliver(g){
    if(g!==generation||attempts>=3||!send)return;
    var state;try{state=read();}catch(error){return;}
    if(!state.healthy||!state.stored||revisionPending||!watchMismatch&&matches(state.record.applied,state.record))return;
    ++attempts;
    var message={OA_OPERATION:7,OA_UI_PREFERENCES:encode(state.record.settings,state.record.revision),OA_THEME:state.record.settings.lastExplicit==='dark'?1:0};
    send(message,function(){retry(g);},function(){
      if(g!==generation)return;
      var latest;try{latest=read();}catch(error){return;}
      if(latest.healthy&&!watchMismatch&&matches(latest.record.applied,latest.record))return;
      stop();timer=later(function(){timer=null;retry(g);},1500);
    });
  }
  function reconcile(force){
    if(closed)return false;
    if(force){watchMismatch=true;revisionPending=true;++generation;stop();}
    var state;try{state=read();}catch(error){return false;}
    if(!state.healthy)return false;
    if(force||revisionPending||state.record.revision===invalidatedRevision){
      watchMismatch=true;invalidatedRevision=state.record.revision;
      state.record.revision=next(state.record.revision);state.record.applied=null;state.record.error=null;
      if(!commit(state.record)){revisionPending=true;return false;}
      revisionPending=false;
    }else if(!state.stored&&!commit(state.record))return false;
    ++generation;attempts=0;stop();deliver(generation);return true;
  }
  function save(value){
    var selected=normalize(value);if(!selected)return {ok:false,error:'invalid_settings'};
    var state;try{state=read();}catch(error){return {ok:false,error:'save_unconfirmed'};}
    var record=state.record;
    if(!state.healthy||!equal(record.settings,selected)){
      record={version:1,settings:selected,revision:state.healthy?next(record.revision):1,
        applied:null,error:null,legacyTheme:record.legacyTheme};
    }
    if(!commit(record))return {ok:false,error:'save_unconfirmed'};
    // The verified new record owns the choices. Keep the earlier phone page's
    // colour-only mirror without making a failed mirror lose the new choice.
    if(legacy.save(storage,{version:1,theme:selected.lastExplicit})){
      record.legacyTheme=selected.lastExplicit;commit(record);
    }
    reconcile(false);
    try{return response(read());}catch(error){return {ok:false,error:'save_unconfirmed'};}
  }
  function receive(input){
    var received=decode(input),state;if(!received)return false;
    try{state=read();}catch(error){return false;}
    if(!state.healthy)return false;
    if(!revisionPending&&state.record.revision!==invalidatedRevision&&received.revision===state.record.revision&&equal(received.settings,state.record.settings)){
      if(received.status===0){
        state.record.applied=encode(received.settings,received.revision);state.record.error=null;
        if(!commit(state.record)){watchMismatch=true;return false;}
        watchMismatch=false,invalidatedRevision=null;
        stop();return true;
      }
      watchMismatch=true;
      state.record.applied=null;state.record.error='watch_save_unconfirmed';commit(state.record);return false;
    }
    if(received.hello){watchMismatch=true;revisionPending=true;invalidatedRevision=state.record.revision;++generation;stop();reconcile(false);}
    return false;
  }
  function handle(message,respond){
    try{
      if(typeof message==='string')message=JSON.parse(message);
      if(message.type==='getUiPreferences')respond(response(read()));
      else if(message.type==='saveUiPreferences')respond(save(message.settings));
      else if(message.type==='retryUiPreferences'){
        if(!reconcile(true)){respond({ok:false,error:'save_unconfirmed'});return;}
        respond(response(read()));
      }else respond({ok:false,error:'unknown_request'});
    }catch(error){respond({ok:false,error:'save_unconfirmed'});}
  }
  function legacyChanged(chosen){
    try{
      if(storage.getItem(KEY)===null)return false;
      var state=read();if(!state.healthy)return false;
      var selected=state.record.settings;selected.appearance=chosen.theme;selected.lastExplicit=chosen.theme;
      return save(selected).ok;
    }catch(error){return false;}
  }
  return {handle:handle,receive:receive,reconcile:reconcile,legacyChanged:legacyChanged,stop:function(){closed=true;++generation;stop();}};
}
module.exports={key:KEY,normalize:normalize,encode:encode,decode:decode,isRequest:isRequest,create:create};

}
]);
