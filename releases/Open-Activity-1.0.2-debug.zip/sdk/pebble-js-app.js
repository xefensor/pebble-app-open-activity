/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;
/******/
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

	__webpack_require__(1);
	module.exports = __webpack_require__(2);


/***/ }),
/* 1 */
/***/ (function(module, exports) {

	/**
	 * Copyright 2024 Google LLC
	 *
	 * Licensed under the Apache License, Version 2.0 (the "License");
	 * you may not use this file except in compliance with the License.
	 * You may obtain a copy of the License at
	 *
	 *     http://www.apache.org/licenses/LICENSE-2.0
	 *
	 * Unless required by applicable law or agreed to in writing, software
	 * distributed under the License is distributed on an "AS IS" BASIS,
	 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	 * See the License for the specific language governing permissions and
	 * limitations under the License.
	 */
	
	(function(p) {
	  if (!p === undefined) {
	    console.error('Pebble object not found!?');
	    return;
	  }
	
	  // Aliases:
	  p.on = p.addEventListener;
	  p.off = p.removeEventListener;
	
	  // For Android (WebView-based) pkjs, print stacktrace for uncaught errors:
	  if (typeof window !== 'undefined' && window.addEventListener) {
	    window.addEventListener('error', function(event) {
	      if (event.error && event.error.stack) {
	        console.error('' + event.error + '\n' + event.error.stack);
	      }
	    });
	  }
	
	})(Pebble);


/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';
	
	var createLauncher = __webpack_require__(3);
	var settings = __webpack_require__(6);
	var uiSettings = __webpack_require__(7);
	var preferences=__webpack_require__(9);
	var launcher = createLauncher({pebble: Pebble, storage: localStorage});
	
	Pebble.addEventListener('ready', function () { launcher.ready(); });
	Pebble.addEventListener('appmessage', function (event) { launcher.message(event && event.payload); });
	Pebble.addEventListener('showConfiguration', function () {
	  // Quick Launch does not need to initialize the legacy configuration page.
	  var page = __webpack_require__(10);
	  var current = settings.load(localStorage);
	  Pebble.openURL('data:text/html;charset=utf-8,' + encodeURIComponent(page(current || settings.defaults(), !current, uiSettings.load(localStorage),launcher.preferences({type:'getUiPreferences'}))));
	});
	Pebble.addEventListener('webviewclosed', function (event) {
	  if (!event || !event.response) return;
	  try {
	    var text = event.response;
	    var response = JSON.parse(text.charAt(0) === '{' ? text : decodeURIComponent(text));
	    if (response && response.uiVersion === 1) {
	      var appearance = uiSettings.normalize(response.appearance);
	      var selected = settings.normalize(response.settings);
	      var display=response.preferences===undefined?null:preferences.normalize(response.preferences);
	      if(appearance&&selected&&(response.preferences===undefined||display&&display.lastExplicit===appearance.theme)&&settings.save(localStorage,selected)&&uiSettings.save(localStorage,appearance)){
	        if(display)launcher.preferences({type:'saveUiPreferences',settings:display});else launcher.appearanceChanged();
	      }
	    } else settings.save(localStorage, response);
	  } catch (error) {}
	});
	Pebble.addEventListener('configmessage', function (event) {
	  if (!event || typeof event.respond !== 'function') return;
	  var message = event.message || event.data || event.payload || event;
	  try {
	    if (typeof message === 'string') message = JSON.parse(message);
	    if(preferences.isRequest(message)){event.respond(launcher.preferences(message));return;}
	    if (!message || message.type === 'getSettings' || message.type === 'load_settings') {
	      var current = settings.load(localStorage);
	      var loaded = {ok: true, settings: settings.choices(current || settings.defaults()),
	        needsRepair: !current, needsMigration: !!current && current.version === 1};
	      if (message && message.uiVersion === 1) {
	        var appearance = uiSettings.load(localStorage); loaded.appearance = appearance || uiSettings.defaults();
	        loaded.needsAppearanceRepair = !appearance;
	      }
	      if(message&&message.includeUiPreferences)loaded.preferences=launcher.preferences({type:'getUiPreferences'});
	      event.respond(loaded);
	    } else if (message.type === 'saveSettings' || message.type === 'save_settings') {
	      var normalized = settings.normalize(message.settings);
	      var selected = normalized && settings.choices(normalized);
	      // Save through the active PKJS DOM and its native write-through store.
	      // Plugin-only writes can be replaced by Android's stale DOM at teardown.
	      var appearance = message.uiVersion === 1 ? uiSettings.normalize(message.appearance) : undefined;
	      var display=message.preferences===undefined?null:preferences.normalize(message.preferences);
	      if (!selected || message.uiVersion === 1 && !appearance || message.preferences!==undefined&&(!display||!appearance||display.lastExplicit!==appearance.theme)) {event.respond(message.uiVersion === 1 ? {ok: false, rejected: true} : {ok: false}); return;}
	      if (!settings.save(localStorage, selected) || appearance && !uiSettings.save(localStorage, appearance)) {event.respond({ok: false}); return;}
	      var receipt = {ok: true, settings: selected};
	      if(display){receipt.preferences=launcher.preferences({type:'saveUiPreferences',settings:display});if(!receipt.preferences.ok){event.respond({ok:false});return;}}
	      if (appearance) {
	        receipt.appearance = appearance;
	        receipt.watchDelivery = !display&&launcher.appearanceChanged() ? 'queued' : 'deferred';
	      }
	      event.respond(receipt);
	    } else event.respond({ok: false});
	  } catch (error) { event.respond({ok: false}); }
	});


/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';
	
	var protocol = __webpack_require__(4);
	var navigation = __webpack_require__(5);
	var settings = __webpack_require__(6);
	var uiSettings = __webpack_require__(7);
	var createQueue = __webpack_require__(8);
	var preferences=__webpack_require__(9);
	var operation = protocol.operation;
	var WATCH_STATE = '00000000-0000-0000-0001-000000000007';
	function uint32(value) {
	  return typeof value === 'number' && isFinite(value) && Math.floor(value) === value && value > 0 && value <= 4294967295;
	}
	
	module.exports = function (options) {
	  var pebble = options.pebble;
	  var now = options.now || function () { return Date.now(); };
	  var later = options.later || function (fn, delay) { return setTimeout(fn, delay); };
	  var cancelLater = options.cancelLater || function (id) { clearTimeout(id); };
	  // Keep generated wire values positive even on signed-int AppMessage bridges.
	  var ticket = options.ticket || function () { return Math.floor(Math.random() * 2147483647) + 1; };
	  var queue = createQueue(function (message, success, failure) { pebble.sendAppMessage(message, success, failure); });
	  var phase = 'idle', attempt = null, ready = false,setupVerified=false;
	  var uiPreferences=preferences.create({storage:options.storage,later:later,cancel:cancelLater,send:function(message,failure,success){
	    if(!ready||!setupVerified||phase!=='idle')return;
	    queue.send(message,success,failure);
	  }});
	  function preferenceRequest(message){var result;uiPreferences.handle(message,function(value){result=value;});return result;}
	
	  function stopSource(current) {
	    if (!current) return;
	    current.sourceDone = true;
	    if (current.source && typeof current.source.unsubscribe === 'function') {
	      try { current.source.unsubscribe(); } catch (error) {}
	    }
	    current.source = null;
	  }
	  function close(notify) {
	    if (phase === 'closed') return;
	    phase = 'closed';uiPreferences.stop(); queue.clear();
	    stopSource(attempt);
	    if (attempt && attempt.timer !== null) cancelLater(attempt.timer);
	    if (notify && attempt) queue.send(protocol.message(operation.CLOSE, {OA_SESSION: attempt.session}));
	  }
	  function current(value) { return attempt === value && phase !== 'closed' && now() < value.deadline; }
	  function sourceData(value, envelope) {
	    if (!current(value) || phase !== 'resolving') return;
	    var destination = navigation.resolve(envelope, value.role, now(), value.watchfaceUuid);
	    stopSource(value);
	    if (!destination) { close(true); return; }
	    value.destination = destination;
	    phase = 'preparing';
	    queue.send(protocol.message(operation.PREPARE, {
	      OA_SESSION: value.session, OA_TICKET: value.ticket,
	      OA_ROLE: protocol.role[value.role], OA_DESTINATION: destination.watchAppUuid
	    }), null, function () { if (current(value)) close(true); });
	  }
	  function start(message) {
	    if (phase !== 'idle') return;
	    setupVerified=false;uiPreferences.stop();queue.clear();
	    var session = protocol.get(message, 'OA_SESSION');
	    var elapsed = protocol.get(message, 'OA_ELAPSED_MS');
	    var button = protocol.get(message, 'OA_BUTTON');
	    var gesture = protocol.get(message, 'OA_GESTURE');
	    var saved = settings.load(options.storage);
	    var role = gesture === protocol.gesture.hold || gesture === protocol.gesture.tap || gesture === protocol.gesture.combo ?
	      settings.select(saved, button, gesture) : null;
	    if (!uint32(session) || typeof elapsed !== 'number' || Math.floor(elapsed) !== elapsed ||
	        elapsed < 0 || elapsed >= protocol.budgetMs || !role) {
	      // A malformed hello never acquires a source or launches an app.
	      attempt = uint32(session) ? {session: session, timer: null} : null;
	      close(true); return;
	    }
	    var requestTicket = ticket();
	    if (!uint32(requestTicket)) { attempt = {session: session, timer: null}; close(true); return; }
	    attempt = {
	      session: session, ticket: requestTicket, role: role,
	      watchfaceUuid: saved.watchface === 'halftone' ? navigation.halftoneUuid : navigation.dynamicUuid,
	      deadline: now() + protocol.budgetMs - elapsed,
	      destination: null, source: null, sourceDone: false, timer: null
	    };
	    var value = attempt;
	    phase = 'resolving';
	    value.timer = later(function () { if (attempt === value) close(true); }, protocol.budgetMs - elapsed);
	    if (typeof pebble.subscribeToSource !== 'function' || typeof pebble.invokeAction !== 'function') {
	      close(true); return;
	    }
	    try {
	      var source = pebble.subscribeToSource({
	        plugin: value.watchfaceUuid,
	        category: 'navigation', item: 'presented_activities', properties: ['hint'],
	        onData: function (envelope) { sourceData(value, envelope); },
	        onError: function () { if (current(value) && phase === 'resolving') close(true); }
	      });
	      if (value.sourceDone || phase === 'closed') {
	        if (source && typeof source.unsubscribe === 'function') source.unsubscribe();
	      } else value.source = source;
	    } catch (error) { close(true); }
	  }
	  function confirm(message) {
	    var value = attempt;
	    if (!value || phase !== 'preparing' || !current(value)) return;
	    var elapsed = protocol.get(message, 'OA_ELAPSED_MS');
	    if (protocol.get(message, 'OA_SESSION') !== value.session ||
	        protocol.get(message, 'OA_TICKET') !== value.ticket ||
	        protocol.get(message, 'OA_ROLE') !== protocol.role[value.role] ||
	        protocol.get(message, 'OA_DESTINATION') !== value.destination.watchAppUuid) return;
	    if (typeof elapsed !== 'number' || Math.floor(elapsed) !== elapsed || elapsed < 0 ||
	        elapsed >= protocol.budgetMs || now() >= value.destination.expiresAtMs) { close(true); return; }
	    // State changes before invocation: duplicate confirmations can never dispatch twice.
	    phase = 'dispatched';
	    var pending;
	    try {
	      pending = pebble.invokeAction({
	        plugin: WATCH_STATE, action: 'launch_app', args: {uuid: value.destination.watchAppUuid},
	        timeoutMs: Math.max(1, Math.min(value.deadline - now(), protocol.budgetMs - elapsed))
	      });
	    } catch (error) { close(true); return; }
	    Promise.resolve(pending).then(function (result) {
	      if (attempt !== value || phase === 'closed') return;
	      if (!result || result.ok !== true) close(true);
	      // On success, the target replaces this native app. Never return to the face here.
	    }, function () { if (attempt === value && phase !== 'closed') close(true); });
	  }
	  return {
	    ready: function () {
	      if (ready || phase === 'closed') return;
	      ready = true;
	      var appearance = uiSettings.load(options.storage);
	      queue.send(protocol.message(operation.REQUEST, appearance ? {OA_THEME: appearance.theme === 'dark' ? 1 : 0} : {}), null, function () { close(false); });
	    },
	    message: function (message) {
	      var reply=protocol.get(message,'OA_UI_PREFERENCES_RESULT');
	      if(reply!==undefined&&phase==='idle'){
	        var decoded=preferences.decode(reply);if(decoded&&decoded.hello)setupVerified=true;
	        uiPreferences.receive(reply);
	      }
	      var kind = protocol.get(message, 'OA_OPERATION');
	      if (kind === operation.HELLO) start(message);
	      else if (kind === operation.CONFIRM) confirm(message);
	      else if (kind === operation.CANCEL && attempt && protocol.get(message, 'OA_SESSION') === attempt.session) close(false);
	    },
	    preferences:preferenceRequest,
	    appearanceChanged: function (complete) {
	      var appearance = uiSettings.load(options.storage);
	      if(uiPreferences.legacyChanged(appearance||{})){if(complete)complete(false);return ready&&setupVerified&&phase==='idle';}
	      if (!ready || !setupVerified || phase !== 'idle' || !appearance) { if (complete) complete(false); return false; }
	      return queue.send(protocol.message(operation.SETTINGS, {OA_THEME: appearance.theme === 'dark' ? 1 : 0}),
	        function () { if (complete) complete(true); }, function () { if (complete) complete(false); });
	    },
	    cancel: function () { close(true); },
	    state: function () { return phase; }
	  };
	};


/***/ }),
/* 4 */
/***/ (function(module, exports) {

	'use strict';
	
	var keys = {
	  OA_OPERATION: 2000, OA_SESSION: 2001, OA_BUTTON: 2002,
	  OA_ROLE: 2003, OA_DESTINATION: 2004, OA_ELAPSED_MS: 2005, OA_TICKET: 2006,
	  OA_GESTURE: 2007, OA_THEME: 2008, OA_UI_PREFERENCES: 2009, OA_UI_PREFERENCES_RESULT: 2010
	};
	module.exports = {
	  keys: keys,
	  operation: {REQUEST: 1, HELLO: 2, PREPARE: 3, CONFIRM: 4, CLOSE: 5, CANCEL: 6, SETTINGS: 7},
	  button: {back: 0, up: 1, select: 2, down: 3},
	  gesture: {hold: 1, tap: 2, combo: 3},
	  role: {primary: 1, secondary: 2},
	  budgetMs: 4000,
	  get: function (message, name) {
	    if (!message) return undefined;
	    return message[name] === undefined ? message[keys[name]] : message[name];
	  },
	  message: function (operation, values) {
	    var output = {}; output[keys.OA_OPERATION] = operation;
	    Object.keys(values || {}).forEach(function (name) { output[keys[name]] = values[name]; });
	    return output;
	  }
	};


/***/ }),
/* 5 */
/***/ (function(module, exports) {

	'use strict';
	
	var DYNAMIC = 'cc1281f1-3b4d-45b5-b235-6881b1fd8fbd';
	var HALFTONE = 'd4dd5046-53be-4624-99e8-46e0b377fe66';
	var HELPER = 'd2d0bf48-cf4c-42f6-8b5f-3657fb2de4e9';
	var ZERO = '00000000-0000-0000-0000-000000000000';
	function object(value) { return !!value && typeof value === 'object' && !Array.isArray(value); }
	function exact(value, fields) {
	  return object(value) && Object.keys(value).length === fields.length &&
	    Object.keys(value).every(function (key) { return fields.indexOf(key) !== -1; });
	}
	function integer(value, minimum, maximum) {
	  return typeof value === 'number' && isFinite(value) && Math.floor(value) === value &&
	    value >= minimum && value <= maximum;
	}
	function uuid(value) {
	  return typeof value === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(value) && value !== ZERO;
	}
	function utf8Bytes(text) {
	  var size = 0;
	  for (var i = 0; i < text.length; ++i) {
	    var ch = text.charCodeAt(i);
	    if (ch < 0x80) ++size;
	    else if (ch < 0x800) size += 2;
	    else if (ch >= 0xd800 && ch <= 0xdbff) {
	      if (++i >= text.length || text.charCodeAt(i) < 0xdc00 || text.charCodeAt(i) > 0xdfff) return Infinity;
	      size += 4;
	    } else if (ch >= 0xdc00 && ch <= 0xdfff) return Infinity;
	    else size += 3;
	  }
	  return size;
	}
	function destination(value) {
	  return value === null || (exact(value, ['watchAppUuid']) && uuid(value.watchAppUuid) && value.watchAppUuid !== HELPER);
	}
	function supportedWatchface(value) { return value === DYNAMIC || value === HALFTONE; }
	function parseHint(text, now, watchfaceUuid) {
	  if (watchfaceUuid === undefined) watchfaceUuid = DYNAMIC;
	  if (!supportedWatchface(watchfaceUuid)) return null;
	  // Every UTF-16 code unit needs at least one UTF-8 byte. Bound untrusted
	  // input before walking it, while retaining exact UTF-8/surrogate validation.
	  if (typeof text !== 'string' || text.length > 512 || utf8Bytes(text) > 512) return null;
	  var hint;
	  try { hint = JSON.parse(text); } catch (error) { return null; }
	  if (!exact(hint, ['schema', 'watchfaceUuid', 'nativeSession', 'viewSequence',
	      'presentationSequence', 'presentedAtMs', 'expiresAtMs', 'primary', 'secondary']) ||
	      hint.schema !== 1 || hint.watchfaceUuid !== watchfaceUuid ||
	      !integer(hint.nativeSession, 1, 4294967295) ||
	      !integer(hint.viewSequence, 1, 4294967295) ||
	      !integer(hint.presentationSequence, 1, 4294967295) ||
	      !integer(hint.presentedAtMs, 1, 9007199254740991) ||
	      !integer(hint.expiresAtMs, 1, 9007199254740991) ||
	      !integer(now, 1, 9007199254740991) || hint.presentedAtMs > now ||
	      hint.expiresAtMs <= now || hint.expiresAtMs <= hint.presentedAtMs ||
	      hint.expiresAtMs - hint.presentedAtMs > 45000 ||
	      !destination(hint.primary) || !destination(hint.secondary)) return null;
	  return hint;
	}
	function resolve(envelope, role, now, watchfaceUuid) {
	  if (watchfaceUuid === undefined) watchfaceUuid = DYNAMIC;
	  if (!supportedWatchface(watchfaceUuid)) return null;
	  if ((role !== 'primary' && role !== 'secondary') || !object(envelope) ||
	      envelope.pluginUuid !== watchfaceUuid || !integer(envelope.validUntilMs, 1, 9007199254740991) ||
	      envelope.validUntilMs <= now || !Array.isArray(envelope.instances) || envelope.instances.length !== 1) return null;
	  var instance = envelope.instances[0];
	  if (!object(instance) || instance.instanceId !== 'current' || !object(instance.properties) ||
	      !object(instance.properties.hint) || !object(instance.properties.hint.longText)) return null;
	  var hint = parseHint(instance.properties.hint.longText.text, now, watchfaceUuid);
	  if (!hint || envelope.validUntilMs > hint.expiresAtMs || !hint[role]) return null;
	  return {watchAppUuid: hint[role].watchAppUuid, expiresAtMs: Math.min(hint.expiresAtMs, envelope.validUntilMs)};
	}
	module.exports = {dynamicUuid: DYNAMIC, halftoneUuid: HALFTONE, supportedWatchface: supportedWatchface, helperUuid: HELPER, uuid: uuid, utf8Bytes: utf8Bytes, parseHint: parseHint, resolve: resolve};


/***/ }),
/* 6 */
/***/ (function(module, exports) {

	'use strict';
	
	var KEY = 'open-activity-settings-v1';
	var SHORTCUTS = [
	  {id: 'hold-up', label: 'Hold Up', button: 1, gesture: 1},
	  {id: 'hold-select', label: 'Hold Center', button: 2, gesture: 1},
	  {id: 'hold-down', label: 'Hold Down', button: 3, gesture: 1},
	  {id: 'hold-back', label: 'Hold Back', button: 0, gesture: 1},
	  {id: 'tap-up', label: 'Tap Up', button: 1, gesture: 2},
	  {id: 'tap-down', label: 'Tap Down', button: 3, gesture: 2},
	  {id: 'combo-back-up', label: 'Hold Back + Up', button: 0, gesture: 3},
	  {id: 'combo-up-down', label: 'Hold Up + Down', button: 1, gesture: 3}
	];
	function role(value) { return value === 'primary' || value === 'secondary'; }
	function object(value) { return !!value && typeof value === 'object' && !Array.isArray(value); }
	function only(value, allowed) {
	  return Object.keys(value).every(function (key) { return allowed.indexOf(key) !== -1; });
	}
	function defaults() {
	  return {version: 2, primaryShortcut: 'hold-down', secondaryShortcut: 'hold-up'};
	}
	function shortcutId(value) {
	  if (value === 'none') return true;
	  return SHORTCUTS.some(function (shortcut) { return shortcut.id === value; });
	}
	function overrides(value, buttons) {
	  if (!object(value) || !only(value, buttons)) return null;
	  var output = {};
	  for (var i = 0; i < buttons.length; i++) {
	    var button = buttons[i];
	    if (!Object.prototype.hasOwnProperty.call(value, button)) continue;
	    var choice = value[button];
	    if (choice !== 'default' && !role(choice)) return null;
	    if (choice !== 'default') output[button] = choice;
	  }
	  return output;
	}
	function normalize(value) {
	  if (!object(value)) return null;
	  if (value.version === 2) {
	    if (!only(value, ['version', 'primaryShortcut', 'secondaryShortcut', 'watchface']) ||
	        value.watchface !== undefined && value.watchface !== 'dynamic' && value.watchface !== 'halftone' ||
	        !shortcutId(value.primaryShortcut) || !shortcutId(value.secondaryShortcut) ||
	        value.primaryShortcut !== 'none' && value.primaryShortcut === value.secondaryShortcut) return null;
	    var chosen = {version: 2, primaryShortcut: value.primaryShortcut, secondaryShortcut: value.secondaryShortcut};
	    // Omitted means Dynamic, preserving existing records and the default route.
	    if (value.watchface === 'halftone') chosen.watchface = 'halftone';
	    return chosen;
	  }
	  if (!only(value, ['version', 'defaultRole', 'holdOverrides', 'tapOverrides', 'comboOverrides']) ||
	      value.version !== 1 || !role(value.defaultRole)) return null;
	  var holds = overrides(value.holdOverrides, ['up', 'down', 'select', 'back']);
	  var taps = value.tapOverrides === undefined ? {} : overrides(value.tapOverrides, ['up', 'down']);
	  var combos = value.comboOverrides === undefined ? {} : overrides(value.comboOverrides, ['backUp', 'upDown']);
	  if (!holds || !taps || !combos) return null;
	  var output = {version: 1, defaultRole: value.defaultRole, holdOverrides: holds};
	  if (Object.keys(taps).length) output.tapOverrides = taps;
	  if (Object.keys(combos).length) output.comboOverrides = combos;
	  return output;
	}
	function load(storage) {
	  try {
	    var value = storage.getItem(KEY);
	    return value === null || value === undefined ? defaults() : normalize(JSON.parse(value));
	  } catch (error) { return null; }
	}
	function save(storage, value) {
	  var settings = normalize(value);
	  if (!settings) return false;
	  try {
	    var encoded = JSON.stringify(settings);
	    storage.setItem(KEY, encoded);
	    return storage.getItem(KEY) === encoded;
	  } catch (error) { return false; }
	}
	function legacyOverride(settings, shortcut) {
	  var name = {0: 'back', 1: 'up', 2: 'select', 3: 'down'}[shortcut.button];
	  var chosen;
	  if (shortcut.gesture === 1) chosen = settings.holdOverrides;
	  else if (shortcut.gesture === 2) chosen = settings.tapOverrides;
	  else {
	    chosen = settings.comboOverrides;
	    name = shortcut.button === 0 ? 'backUp' : 'upDown';
	  }
	  return chosen && chosen[name];
	}
	function select(value, button, gesture) {
	  if (gesture === undefined) gesture = 1; // Existing callers select hold mappings.
	  var settings = normalize(value), shortcut;
	  if (!settings || typeof button !== 'number' || Math.floor(button) !== button) return null;
	  for (var i = 0; i < SHORTCUTS.length; i++) {
	    if (SHORTCUTS[i].button === button && SHORTCUTS[i].gesture === gesture) shortcut = SHORTCUTS[i];
	  }
	  if (!shortcut) return null;
	  if (settings.version === 1) return legacyOverride(settings, shortcut) || settings.defaultRole;
	  if (shortcut.id === settings.primaryShortcut) return 'primary';
	  if (shortcut.id === settings.secondaryShortcut) return 'secondary';
	  return null;
	}
	function choices(value) {
	  var settings = normalize(value);
	  if (!settings || settings.version === 2) return settings;
	  function choose(target, preferred) {
	    var matched = SHORTCUTS.filter(function (shortcut) {
	      return (legacyOverride(settings, shortcut) || settings.defaultRole) === target;
	    });
	    var explicit = matched.filter(function (shortcut) { return legacyOverride(settings, shortcut) === target; });
	    var preferredExplicit = explicit.filter(function (shortcut) { return shortcut.id === preferred; });
	    var preferredDefault = matched.filter(function (shortcut) { return shortcut.id === preferred; });
	    var selected = preferredExplicit[0] || explicit[0] || preferredDefault[0] || matched[0];
	    return selected ? selected.id : 'none';
	  }
	  return {version: 2, primaryShortcut: choose('primary', 'hold-down'), secondaryShortcut: choose('secondary', 'hold-up')};
	}
	module.exports = {key: KEY, shortcuts: SHORTCUTS, defaults: defaults, normalize: normalize,
	  choices: choices, load: load, save: save, select: select};


/***/ }),
/* 7 */
/***/ (function(module, exports) {

	'use strict';
	
	// UI preferences are independent of the version-1/version-2 shortcut record.
	// Reading or changing appearance never rewrites legacy routing bytes.
	var KEY = 'open-activity-ui-v1';
	function defaults() { return {version: 1, theme: 'light'}; }
	function normalize(value) {
	  if (!value || typeof value !== 'object' || Array.isArray(value) || value.version !== 1 ||
	      Object.keys(value).some(function(key) { return key !== 'version' && key !== 'theme'; }) ||
	      value.theme !== 'light' && value.theme !== 'dark') return null;
	  return {version: 1, theme: value.theme};
	}
	function load(storage) {
	  try {
	    var raw = storage.getItem(KEY);
	    return raw === null || raw === undefined ? defaults() : normalize(JSON.parse(raw));
	  } catch (error) { return null; }
	}
	function save(storage, value) {
	  var normalized = normalize(value);
	  if (!normalized) return false;
	  try {
	    var encoded = JSON.stringify(normalized);
	    if (storage.getItem(KEY) !== encoded) storage.setItem(KEY, encoded);
	    return storage.getItem(KEY) === encoded;
	  } catch (error) { return false; }
	}
	module.exports = {key: KEY, defaults: defaults, normalize: normalize, load: load, save: save};


/***/ }),
/* 8 */
/***/ (function(module, exports) {

	'use strict';
	
	// One bounded AppMessage queue. Opening messages never retry; the display
	// controller may retry only after passive setup has been identified.
	module.exports = function (send) {
	  var pending = [], busy = false;
	  function flush() {
	    if (busy || !pending.length) return;
	    var item = pending.shift(), settled = false;
	    busy = true;
	    function done(ok) {
	      if (settled) return;
	      settled = true; busy = false;
	      if (ok && item.success) item.success();
	      if (!ok && item.failure) item.failure();
	      flush();
	    }
	    try { send(item.message, function () { done(true); }, function () { done(false); }); }
	    catch (error) { done(false); }
	  }
	  return {
	    send: function (message, success, failure) {
	      if (pending.length >= 4) { if (failure) failure(); return false; }
	      pending.push({message: message, success: success, failure: failure}); flush(); return true;
	    },
	    clear: function () { pending = []; }
	  };
	};


/***/ }),
/* 9 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';
	
	var legacy=__webpack_require__(7);
	var KEY='open-activity-ui-preferences-v1';
	var sizes=['follow','small','medium','large'],looks=['follow','light','dark'];
	function normalize(value){
	  if(!value||value.version!==2||Object.keys(value).sort().join(',')!=='appearance,lastExplicit,textSize,version'||
	      sizes.indexOf(value.textSize)<0||looks.indexOf(value.appearance)<0||
	      ['light','dark'].indexOf(value.lastExplicit)<0||
	      value.appearance!=='follow'&&value.appearance!==value.lastExplicit)return null;
	  return {version:2,textSize:value.textSize,appearance:value.appearance,lastExplicit:value.lastExplicit};
	}
	function equal(a,b){return JSON.stringify(a)===JSON.stringify(b);}
	function defaults(theme){return {version:2,textSize:'follow',appearance:theme,lastExplicit:theme};}
	function put(bytes,at,value){for(var i=0;i<4;i++)bytes[at+i]=(value>>>(8*i))&255;}
	function u32(bytes,at){return (bytes[at]|bytes[at+1]<<8|bytes[at+2]<<16|bytes[at+3]<<24)>>>0;}
	function encode(settings,revision){
	  var bytes=[1,3,0,0];put(bytes,4,revision);put(bytes,8,sizes.indexOf(settings.textSize));
	  put(bytes,12,looks.indexOf(settings.appearance));put(bytes,16,looks.indexOf(settings.lastExplicit));return bytes;
	}
	function decode(input){
	  if(!input||input.length!==20)return null;
	  var bytes=Array.prototype.slice.call(input);
	  if(!bytes.every(function(value){return Number.isInteger(value)&&value>=0&&value<=255;})||
	      bytes[0]!==1||bytes[1]!==3||bytes[2]>1||bytes[3]>1)return null;
	  var value=normalize({version:2,textSize:sizes[u32(bytes,8)],appearance:looks[u32(bytes,12)],lastExplicit:looks[u32(bytes,16)]});
	  return value?{settings:value,revision:u32(bytes,4),status:bytes[2],hello:bytes[3]===1}:null;
	}
	function matches(frame,record){var value=decode(frame);return !!value&&value.status===0&&value.revision===record.revision&&equal(value.settings,record.settings);}
	function next(revision){return ((revision+1)>>>0)||1;}
	function isRequest(message){return message&&['getUiPreferences','saveUiPreferences','retryUiPreferences'].indexOf(message.type)>=0;}
	function create(options){
	  var storage=options.storage,send=options.send,later=options.later||function(fn,ms){return setTimeout(fn,ms);},cancel=options.cancel||function(id){clearTimeout(id);};
	  var generation=0,timer=null,attempts=0,watchMismatch=false,closed=false,invalidatedRevision=null,revisionPending=false;
	  function stop(){if(timer!==null)cancel(timer);timer=null;}
	  function read(){
	    var old=legacy.load(storage),raw=storage.getItem(KEY),record,stored=raw!==null&&raw!==undefined;
	    if(!stored)return {healthy:!!old,stored:false,record:{version:1,settings:defaults(old?old.theme:'light'),revision:1,applied:null,error:null,legacyTheme:old?old.theme:'light'}};
	    try{record=JSON.parse(raw);}catch(error){record=null;}
	    if(!record||record.version!==1||!normalize(record.settings)||!Number.isInteger(record.revision)||record.revision<1||record.revision>0xffffffff||
	        ['light','dark'].indexOf(record.legacyTheme)<0||record.applied!==null&&!decode(record.applied)||
	        record.error!==null&&typeof record.error!=='string')
	      return {healthy:false,stored:false,record:{version:1,settings:defaults(old?old.theme:'light'),revision:1,applied:null,error:null,legacyTheme:old?old.theme:'light'}};
	    record.settings=normalize(record.settings);
	    if(old&&old.theme!==record.legacyTheme){
	      record.legacyTheme=old.theme;
	      if(old.theme!==record.settings.lastExplicit){
	        record.settings.appearance=old.theme;record.settings.lastExplicit=old.theme;
	        record.revision=next(record.revision);record.applied=null;record.error=null;stored=false;
	      }
	    }
	    return {healthy:true,stored:stored,record:record};
	  }
	  function commit(record){
	    try{var encoded=JSON.stringify(record);storage.setItem(KEY,encoded);return storage.getItem(KEY)===encoded;}catch(error){return false;}
	  }
	  function response(state){
	    var record=state.record,applied=state.healthy&&!watchMismatch&&matches(record.applied,record);
	    return {ok:true,settings:record.settings,needsRepair:!state.healthy,saved:state.stored,
	      delivery:{applied:applied,pending:!applied,error:record.error}};
	  }
	  function retry(g){
	    if(g!==generation||attempts>=3||!send)return;
	    stop();timer=later(function(){timer=null;if(g===generation)deliver(g);},500*attempts);
	  }
	  function deliver(g){
	    if(g!==generation||attempts>=3||!send)return;
	    var state;try{state=read();}catch(error){return;}
	    if(!state.healthy||!state.stored||revisionPending||!watchMismatch&&matches(state.record.applied,state.record))return;
	    ++attempts;
	    var message={OA_OPERATION:7,OA_UI_PREFERENCES:encode(state.record.settings,state.record.revision),OA_THEME:state.record.settings.lastExplicit==='dark'?1:0};
	    send(message,function(){retry(g);},function(){
	      if(g!==generation)return;
	      var latest;try{latest=read();}catch(error){return;}
	      if(latest.healthy&&!watchMismatch&&matches(latest.record.applied,latest.record))return;
	      stop();timer=later(function(){timer=null;retry(g);},1500);
	    });
	  }
	  function reconcile(force){
	    if(closed)return false;
	    if(force){watchMismatch=true;revisionPending=true;++generation;stop();}
	    var state;try{state=read();}catch(error){return false;}
	    if(!state.healthy)return false;
	    if(force||revisionPending||state.record.revision===invalidatedRevision){
	      watchMismatch=true;invalidatedRevision=state.record.revision;
	      state.record.revision=next(state.record.revision);state.record.applied=null;state.record.error=null;
	      if(!commit(state.record)){revisionPending=true;return false;}
	      revisionPending=false;
	    }else if(!state.stored&&!commit(state.record))return false;
	    ++generation;attempts=0;stop();deliver(generation);return true;
	  }
	  function save(value){
	    var selected=normalize(value);if(!selected)return {ok:false,error:'invalid_settings'};
	    var state;try{state=read();}catch(error){return {ok:false,error:'save_unconfirmed'};}
	    var record=state.record;
	    if(!state.healthy||!equal(record.settings,selected)){
	      record={version:1,settings:selected,revision:state.healthy?next(record.revision):1,
	        applied:null,error:null,legacyTheme:record.legacyTheme};
	    }
	    if(!commit(record))return {ok:false,error:'save_unconfirmed'};
	    // The verified new record owns the choices. Keep the earlier phone page's
	    // colour-only mirror without making a failed mirror lose the new choice.
	    if(legacy.save(storage,{version:1,theme:selected.lastExplicit})){
	      record.legacyTheme=selected.lastExplicit;commit(record);
	    }
	    reconcile(false);
	    try{return response(read());}catch(error){return {ok:false,error:'save_unconfirmed'};}
	  }
	  function receive(input){
	    var received=decode(input),state;if(!received)return false;
	    try{state=read();}catch(error){return false;}
	    if(!state.healthy)return false;
	    if(!revisionPending&&state.record.revision!==invalidatedRevision&&received.revision===state.record.revision&&equal(received.settings,state.record.settings)){
	      if(received.status===0){
	        state.record.applied=encode(received.settings,received.revision);state.record.error=null;
	        if(!commit(state.record)){watchMismatch=true;return false;}
	        watchMismatch=false,invalidatedRevision=null;
	        stop();return true;
	      }
	      watchMismatch=true;
	      state.record.applied=null;state.record.error='watch_save_unconfirmed';commit(state.record);return false;
	    }
	    if(received.hello){watchMismatch=true;revisionPending=true;invalidatedRevision=state.record.revision;++generation;stop();reconcile(false);}
	    return false;
	  }
	  function handle(message,respond){
	    try{
	      if(typeof message==='string')message=JSON.parse(message);
	      if(message.type==='getUiPreferences')respond(response(read()));
	      else if(message.type==='saveUiPreferences')respond(save(message.settings));
	      else if(message.type==='retryUiPreferences'){
	        if(!reconcile(true)){respond({ok:false,error:'save_unconfirmed'});return;}
	        respond(response(read()));
	      }else respond({ok:false,error:'unknown_request'});
	    }catch(error){respond({ok:false,error:'save_unconfirmed'});}
	  }
	  function legacyChanged(chosen){
	    try{
	      if(storage.getItem(KEY)===null)return false;
	      var state=read();if(!state.healthy)return false;
	      var selected=state.record.settings;selected.appearance=chosen.theme;selected.lastExplicit=chosen.theme;
	      return save(selected).ok;
	    }catch(error){return false;}
	  }
	  return {handle:handle,receive:receive,reconcile:reconcile,legacyChanged:legacyChanged,stop:function(){closed=true;++generation;stop();}};
	}
	module.exports={key:KEY,normalize:normalize,encode:encode,decode:decode,isRequest:isRequest,create:create};


/***/ }),
/* 10 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';
	
	var settingsStyle = __webpack_require__(11);
	
	var model = __webpack_require__(6);
	var uiModel = __webpack_require__(7);
	var translations = __webpack_require__(12);
	
	// Both settings paths use this layout. The build writes config.html from it.
	function behavior(initial) {
	  'use strict';
	  var primary = document.getElementById('primary'), secondary = document.getElementById('secondary');
	  var watchface = document.getElementById('watchface');
	  var size=document.getElementById('text-size'),deliveryRetry=document.getElementById('delivery-retry');
	  var preferencesSupported=false,savedPreferences='',lastExplicit='light',preferenceDelivery=null,preferenceUncommitted=false,preferencePoll=null;
	  var preferenceGeneration=0,preferenceBusy=false;
	  var theme = document.getElementById('watch-theme'), delivery = document.getElementById('watch-delivery');
	  var appearanceSupported = false, appearanceRepair = false, savedAppearance = '';
	  var locale = String(typeof navigator !== 'undefined' && navigator.language || 'en').toLowerCase().split(/[_.@-]/)[0];
	  if (locale === 'nb' || locale === 'nn') locale = 'no';
	  if (!initial.translations[locale]) locale = 'en';
	  var dictionary = initial.translations && initial.translations[locale] || {};
	  function tr(text) { return dictionary[text] || text; }
	  if (document.documentElement) document.documentElement.lang = locale;
	  if (document.querySelectorAll) Array.prototype.forEach.call(document.querySelectorAll('[data-i18n]'), function(node) { node.textContent = tr(node.getAttribute('data-i18n')); });
	  var fields = [primary, secondary], form = document.getElementById('settings');
	  var save = document.getElementById('save'), discard = document.getElementById('discard');
	  var retry = document.getElementById('retry'), status = document.getElementById('status');
	  var actions = document.getElementById('actions'), conflict = document.getElementById('shortcut-error');
	  var assignment = document.getElementById('assignment-help');
	  var loaded = false, repairing = false, migrating = false, uncertain = false, saved = '', phase = 'loading';
	  var operation = 0, timer = null, bridgeReady = false, pkjsReady = false;
	  var layoutPending = false, lastFlow = null, lastHeight = null;
	  var legacy = initial.mode === 'legacy';
	  function shortcut(value) {
	    return ['none','hold-up','hold-select','hold-down','hold-back','tap-up','tap-down','combo-back-up','combo-up-down'].indexOf(value) !== -1;
	  }
	  function normalize(value) {
	    if (!value || typeof value !== 'object' || Array.isArray(value) || value.version !== 2 ||
	        Object.keys(value).some(function(name) { return ['version','primaryShortcut','secondaryShortcut','watchface'].indexOf(name) === -1; }) ||
	        value.watchface !== undefined && value.watchface !== 'dynamic' && value.watchface !== 'halftone' ||
	        !shortcut(value.primaryShortcut) || !shortcut(value.secondaryShortcut) ||
	        value.primaryShortcut !== 'none' && value.primaryShortcut === value.secondaryShortcut) return null;
	    var chosen = {version: 2, primaryShortcut: value.primaryShortcut, secondaryShortcut: value.secondaryShortcut};
	    if (value.watchface === 'halftone') chosen.watchface = 'halftone';
	    return chosen;
	  }
	  function normalizeAppearance(value) {
	    if (!value || value.version !== 1 || value.theme !== 'light' && value.theme !== 'dark' ||
	        Object.keys(value).some(function(key) { return key !== 'version' && key !== 'theme'; })) return null;
	    return {version: 1, theme: value.theme};
	  }
	  function normalizePreferences(value){
	    return value&&value.version===2&&Object.keys(value).length===4&&['follow','small','medium','large'].indexOf(value.textSize)>=0&&['follow','light','dark'].indexOf(value.appearance)>=0&&['light','dark'].indexOf(value.lastExplicit)>=0&&(value.appearance==='follow'||value.appearance===value.lastExplicit)?{version:2,textSize:value.textSize,appearance:value.appearance,lastExplicit:value.lastExplicit}:null;
	  }
	  function preferenceValue(){return preferencesSupported?normalizePreferences({version:2,textSize:size.value,appearance:theme.value,lastExplicit:lastExplicit}):undefined;}
	  function appearanceValue() { return appearanceSupported ? normalizeAppearance({version:1,theme:theme.value==='follow'?lastExplicit:theme.value}) : undefined; }
	  function stopPreferencePoll(){if(preferencePoll!==null)clearTimeout(preferencePoll);preferencePoll=null;}
	  function cancelPreferencePoll(){stopPreferencePoll();++preferenceGeneration;preferenceBusy=false;}
	  function statusText(node,text){if(node.textContent!==text)node.textContent=text;}
	  function showPreferenceDelivery(){
	    stopPreferencePoll();if(!preferencesSupported)return;
	    delivery.hidden=false;
	    statusText(delivery,tr(preferenceUncommitted||JSON.stringify(preferenceValue())!==savedPreferences?'Unsaved changes.':preferenceDelivery&&preferenceDelivery.applied?'Applied on watch':preferenceDelivery&&preferenceDelivery.error?'Saved on phone · Watch could not confirm saving':'Saved on phone · Pending on watch'));
	    deliveryRetry.hidden=legacy||dirty()||!!(preferenceDelivery&&preferenceDelivery.applied);
	    deliveryRetry.disabled=preferenceBusy||phase!=='ready';
	    if(!legacy&&loaded&&phase==='ready'&&!dirty())preferencePoll=setTimeout(function(){preferencePoll=null;pollPreferences(false);},preferenceDelivery&&preferenceDelivery.applied?5000:2000);
	    layoutActions();
	  }
	  function pollPreferences(force){
	    if(!preferencesSupported||!loaded||phase!=='ready'||dirty()||preferenceBusy)return;
	    var current=++preferenceGeneration;preferenceBusy=true;controls();
	    function active(){return current===preferenceGeneration&&loaded&&phase==='ready'&&!dirty();}
	    function failed(){if(!active())return;preferenceBusy=false;showPreferenceDelivery();}
	    settingsTarget(function(target){
	      // Target discovery can outlive an edit or Save. An old poll must never
	      // replace the shared request/timer owned by that newer operation.
	      if(!active())return;
	      request({type:force?'retryUiPreferences':'getUiPreferences'},function(response){
	        if(!active())return;
	        preferenceBusy=false;
	        if(response&&response.ok&&JSON.stringify(normalizePreferences(response.settings))===savedPreferences)preferenceDelivery=response.delivery;
	        showPreferenceDelivery();
	      },failed,target);
	    },failed);
	  }
	  deliveryRetry.onclick=function(){stopPreferencePoll();pollPreferences(true);};
	  function value() {
	    return normalize({version: 2, primaryShortcut: primary.value, secondaryShortcut: secondary.value, watchface: watchface.value});
	  }
	  function edited() { return loaded && (JSON.stringify(value()) !== saved || appearanceSupported && JSON.stringify(appearanceValue()) !== savedAppearance || preferencesSupported&&JSON.stringify(preferenceValue())!==savedPreferences); }
	  function dirty() { return loaded && (repairing || appearanceRepair || preferenceUncommitted || migrating || uncertain || edited()); }
	  function message(text, error) {
	    statusText(status,tr(text)); status.className = error ? 'status error' : 'status';
	    layoutActions();
	  }
	  function layoutActions() {
	    if (typeof window === 'undefined' || typeof actions.getBoundingClientRect !== 'function') return;
	    if (layoutPending) return;
	    layoutPending = true;
	    // Status, viewport and ResizeObserver notifications may describe the same
	    // frame. Read geometry once after those changes and avoid unchanged writes.
	    if (typeof window.requestAnimationFrame === 'function') window.requestAnimationFrame(measureActions);
	    else setTimeout(measureActions, 0);
	  }
	  function measureActions() {
	    layoutPending = false;
	    var viewport = window.visualViewport && window.visualViewport.height || window.innerHeight;
	    var height = actions.getBoundingClientRect().height;
	    // A short viewport or large text needs a normal-flow action area. Keeping
	    // it fixed would cover the focused picker or the last help paragraph.
	    var inFlow = viewport < 560 || height > viewport * 0.28;
	    var flow = inFlow ? 'true' : 'false', reserved = (inFlow ? 0 : height) + 'px';
	    if (flow !== lastFlow) { actions.setAttribute('data-flow', flow); lastFlow = flow; }
	    if (reserved !== lastHeight) {
	      document.documentElement.style.setProperty('--actions-height', reserved); lastHeight = reserved;
	    }
	  }
	  function selectedLabel(field) {
	    for (var i = 0; i < field.options.length; i++)
	      if (field.options[i].value === field.value) return tr(field.options[i].textContent);
	    return '';
	  }
	  function describe() {
	    var duplicate = loaded && primary.value !== 'none' && primary.value === secondary.value;
	    conflict.hidden = !duplicate;
	    conflict.textContent = duplicate ? tr('Choose a different shortcut for each activity.') : '';
	    fields.forEach(function(field) {
	      document.getElementById(field.id + '-help').textContent = tr(!loaded ? 'Saved choice not loaded yet.' : field.value === 'none' ?
	        'No shortcut assigned.' : field.id === 'secondary' ? 'Opens the smaller activity row.' : 'Opens the large activity.');
	      field.setAttribute('aria-invalid', duplicate ? 'true' : 'false');
	    });
	    fields.concat([watchface,size,theme]).forEach(function(field){
	      field.options[0].textContent=tr(phase==='load-error'?'Not loaded':'Loading saved choice…');
	    });
	    var chosen = fields.filter(function(field) { return field.value && field.value !== 'none'; });
	    assignment.hidden = !!duplicate;
	    assignment.textContent = tr(!loaded ? 'Choose shortcuts, then assign Open Activity to them in Pebble’s Quick Launch settings.' :
	      duplicate ? 'Use a different shortcut for each activity before setting up Quick Launch.' :
	      !chosen.length ? 'No activity shortcut is enabled. Choose a shortcut above to open an activity.' :
	      'In Pebble’s Quick Launch settings, assign Open Activity to {shortcuts}.').replace('{shortcuts}', chosen.map(selectedLabel).join(tr(' and ')));
	    document.getElementById('watch-theme-help').textContent = tr(preferencesSupported?'Follow Pebble appearance is unavailable on this build. It uses your last Light or Dark choice.':appearanceSupported ? 'Watch colours are independent of this phone page.' : 'Update Open Activity to change watch appearance.');
	  }
	  function controls() {
	    var editing = loaded && phase !== 'saving';
	    fields.forEach(function(field) { field.disabled = !editing; });
	    watchface.disabled = !editing;
	    theme.disabled = !editing || !appearanceSupported;size.disabled=!editing||!preferencesSupported;
	    for(var i=0;i<theme.options.length;++i)if(theme.options[i].value==='follow'){
	      // Retain a previously saved Follow value without offering a new choice
	      // that the baseline system appearance API cannot apply.
	      theme.options[i].disabled=true;theme.options[i].hidden=theme.value!=='follow';
	      theme.options[i].textContent=tr('Follow Pebble')+' — '+tr(lastExplicit==='dark'?'Dark':'Light');
	    }
	    deliveryRetry.hidden=!preferencesSupported||legacy||dirty()||!!(preferenceDelivery&&preferenceDelivery.applied);deliveryRetry.disabled=preferenceBusy||phase!=='ready';
	    save.disabled = !editing || !dirty() || !value() || appearanceSupported && !appearanceValue();
	    save.textContent = tr(phase === 'saving' ? 'Saving…' : 'Save');
	    discard.hidden = !legacy && !loaded;
	    discard.disabled = phase === 'saving' || !legacy && !uncertain && !edited();
	    discard.textContent = tr(legacy ? 'Cancel' : uncertain ? 'Reload saved' : 'Discard');
	    retry.hidden = phase !== 'load-error'; describe();
	  }
	  function changed() {
	    if(theme.value&&theme.value!=='follow')lastExplicit=theme.value;
	    cancelPreferencePoll();controls();showPreferenceDelivery();
	    message(!value() ? 'Choose a different shortcut for each activity.' : uncertain ? 'Save not confirmed. Reload saved choices or save again.' :
	      edited() ? 'Unsaved changes.' : repairing || appearanceRepair ? 'Review these choices and save to repair unreadable settings.' :
	      migrating ? 'Save to use these two shortcuts.' : 'No changes to save.', !value() || uncertain);
	  }
	  function apply(settings, repair, migration, appearance, repairAppearance,preferences) {
	    cancelPreferencePoll();
	    primary.value = settings.primaryShortcut; secondary.value = settings.secondaryShortcut;
	    watchface.value = settings.watchface || 'dynamic';
	    var normalizedAppearance = normalizeAppearance(appearance);
	    appearanceSupported = !!normalizedAppearance; appearanceRepair = repairAppearance === true;
	    var display=normalizePreferences(preferences&&preferences.settings);preferencesSupported=!!display;
	    lastExplicit=display?display.lastExplicit:normalizedAppearance?normalizedAppearance.theme:'light';
	    size.value=display?display.textSize:'';theme.value=display?display.appearance:normalizedAppearance?normalizedAppearance.theme:'';
	    savedPreferences=display?JSON.stringify(display):'';preferenceDelivery=preferences&&preferences.delivery||null;preferenceUncommitted=!!(preferences&&preferences.saved===false);
	    if(preferences&&preferences.needsRepair)appearanceRepair=true;
	    savedAppearance = normalizedAppearance ? JSON.stringify(normalizedAppearance) : '';
	    delivery.hidden = true;
	    loaded = true; repairing = repair; migrating = migration; uncertain = false; saved = JSON.stringify(settings); phase = 'ready';
	    controls();showPreferenceDelivery();
	    message(repair || appearanceRepair ? 'Saved settings could not be read. Review these choices before saving.' : migration ? 'Save to use these two shortcuts.' : preferenceUncommitted?'Unsaved changes.':'No changes to save.', repair || appearanceRepair);
	  }
	  function stopTimer() { if (timer !== null) clearTimeout(timer); timer = null; }
	  function loadFailed() {
	    loaded = false; phase = 'load-error'; controls();
	    message('Could not load settings. Retry, or reopen this page from Pebble.', true);
	  }
	  function request(payload, complete, failed, target) {
	    var current = ++operation; stopTimer();
	    timer = setTimeout(function() { if (current === operation) { operation++; timer = null; failed(); } }, 6000);
	    function finish(callback, response) {
	      if (current !== operation) return;
	      operation++; stopTimer(); callback(response);
	    }
	    try {
	      var pending = Pebble.sendMessage(target || 'plugin', payload);
	      if (!pending || typeof pending.then !== 'function') { finish(failed); return; }
	      pending.then(function(response) { finish(complete, response); }, function() { finish(failed); });
	    } catch (error) { finish(failed); }
	  }
	  function load() {
	    var readback = uncertain;
	    cancelPreferencePoll();loaded = false; phase = 'loading';delivery.hidden=true;
	    fields.concat([watchface,size,theme]).forEach(function(field) { field.value = ''; });
	    controls(); message('Loading settings…');
	    if (!bridgeReady) { stopTimer(); timer = setTimeout(loadFailed, 6000); return; }
	    settingsTarget(function(target){request({type: 'getSettings', uiVersion: 1,includeUiPreferences:true}, function(response) {
	      var settings = response && response.ok === true && normalize(response.settings);
	      if (!settings || response.appearance !== undefined && !normalizeAppearance(response.appearance)) { loadFailed(); return; }
	      apply(settings, response.needsRepair === true, response.needsMigration === true, response.appearance, response.needsAppearanceRepair,response.preferences);
	      if (readback && !repairing && !appearanceRepair) message('Saved settings reloaded.');
	    }, loadFailed,target);},loadFailed);
	  }
	  fields.forEach(function(field) { field.onchange = changed;
	    for (var i = 0; i < field.options.length; i++) field.options[i].textContent = tr(field.options[i].textContent);
	  });
	  theme.onchange = size.onchange=changed;
	  watchface.onchange = changed;
	  retry.onclick = load;
	  discard.onclick = function() {
	    if (legacy) location.href = 'pebblejs://close#';
	    else if (loaded && uncertain) load();
	    else if (loaded) apply(JSON.parse(saved), repairing, migrating, savedAppearance ? JSON.parse(savedAppearance) : undefined, appearanceRepair,preferencesSupported?{settings:JSON.parse(savedPreferences),delivery:preferenceDelivery,saved:!preferenceUncommitted}:undefined);
	  };
	  function saveFailed() {
	    uncertain = true; phase = 'ready'; controls();
	    message('Save not confirmed. Reload saved choices or save again.', true);
	  }
	  function settingsTarget(complete, failed) {
	    if (typeof Pebble.targets !== 'function') { complete(pkjsReady ? 'pkjs' : 'plugin'); return; }
	    var settled = false, lookupTimer = setTimeout(function() { finish(failed); }, 6000);
	    function finish(callback, target) { if (settled) return; settled = true; clearTimeout(lookupTimer); callback(target); }
	    try {
	      Promise.resolve(Pebble.targets()).then(function(targets) {
	        if (!Array.isArray(targets)) { finish(failed); return; }
	        finish(complete, targets.some(function(target) { return target && target.id === 'pkjs'; }) ? 'pkjs' : 'plugin');
	      }, function() { finish(failed); });
	    } catch (error) { finish(failed); }
	  }
	  form.onsubmit = function(event) {
	    if (event) event.preventDefault();
	    if (save.disabled) return;
	    var selected = value();
	    if (!selected) { saveFailed(); return; }
	    var selectedAppearance = appearanceValue(),selectedPreferences=preferenceValue();
	    if (legacy) { location.href = 'pebblejs://close#' + encodeURIComponent(JSON.stringify(selectedAppearance ? {uiVersion: 1, settings: selected, appearance: selectedAppearance,preferences:selectedPreferences} : selected)); return; }
	    cancelPreferencePoll();phase = 'saving'; controls(); message('Saving…');
	    var attempts = 0;
	    function confirmed(settings, response) {
	      apply(settings,false,false,selectedAppearance,false,response.preferences);message('✓ Saved');
	      if(!preferencesSupported)delivery.hidden=!selectedAppearance||response.watchDelivery!=='deferred';
	    }
	    function write(target) {
	      if (++attempts > 3) { saveFailed(); return; }
	      var payload = {type: 'saveSettings', settings: selected};
	      if (selectedAppearance) { payload.uiVersion = 1; payload.appearance = selectedAppearance; }
	      if(selectedPreferences)payload.preferences=selectedPreferences;
	      request(payload, function(response) {
	        if (response && response.ok === false && response.rejected === true) {
	          uncertain = false; phase = 'ready'; controls(); message('Couldn’t save. Try again.', true); return;
	        }
	        var accepted = response && response.ok === true && normalize(response.settings);
	        if (!accepted || JSON.stringify(accepted) !== JSON.stringify(selected) || selectedAppearance &&
	            JSON.stringify(normalizeAppearance(response.appearance)) !== JSON.stringify(selectedAppearance)||selectedPreferences&&(!response.preferences||!response.preferences.ok||JSON.stringify(normalizePreferences(response.preferences.settings))!==JSON.stringify(selectedPreferences))) { saveFailed(); return; }
	        // Android PKJS owns a restored DOM snapshot. Keep it synchronized before
	        // shutdown can persist that snapshot over the config plugin's store.
	        if (target === 'plugin') settingsTarget(function(current) { if (current === 'pkjs') write(current); else confirmed(accepted, response); }, saveFailed);
	        else confirmed(accepted, response);
	      }, function() {
	        if (target !== 'pkjs') { saveFailed(); return; }
	        settingsTarget(function(current) { if (current === 'plugin') write(current); else saveFailed(); }, saveFailed);
	      }, target);
	    }
	    settingsTarget(write, saveFailed);
	  };
	  save.onclick = function(event) { if (event) event.preventDefault(); form.onsubmit(); };
	  if (typeof window !== 'undefined') {
	    window.addEventListener('resize', layoutActions);
	    if (window.visualViewport) window.visualViewport.addEventListener('resize', layoutActions);
	    if (typeof ResizeObserver !== 'undefined') new ResizeObserver(layoutActions).observe(actions);
	  }
	  if (legacy) apply(initial.settings, initial.needsRepair, initial.needsMigration, initial.appearance, initial.needsAppearanceRepair,initial.preferences);
	  else {
	    if (typeof Pebble !== 'undefined' && typeof Pebble.addEventListener === 'function') {
	      Pebble.addEventListener('ready', function(event) {
	        if (event && event.target === 'pkjs') { pkjsReady = true; return; }
	        if (event && event.target && event.target !== 'plugin') return;
	        if (bridgeReady) return;
	        bridgeReady = true; load();
	      });
	    }
	    load();
	  }
	}
	function render(initial) {
	  initial.translations = translations;
	  function picker(id, label) {
	    var options = '<option value="none" data-i18n="Not assigned">Not assigned</option>' + model.shortcuts.map(function(shortcut) {
	      return '<option value="' + shortcut.id + '">' + shortcut.label + '</option>';
	    }).join('');
	    return '<label data-i18n="' + label + '" for="' + id + '">' + label + '</label><select id="' + id + '" aria-describedby="' + id + '-help shortcut-error" disabled><option value="" disabled hidden selected data-i18n="Loading saved choice…">Loading saved choice…</option>' + options + '</select><p id="' + id + '-help" class="hint"></p>';
	  }
	  return [
	    '<!doctype html><html lang="en"><head><meta charset="utf-8">',
	    '<meta name="viewport" content="width=device-width,initial-scale=1"><title>Open Activity</title><style id="xoce-settings-style">',
	    settingsStyle,
	    '</style><style>',
	    ':root{--accent:#6f42a9;--accent-ink:#fff}',
	    '@media(prefers-color-scheme:dark){:root{--accent:#c9a7ff;--accent-ink:#211332}}',
	    'select[aria-invalid=true]{border-color:var(--error);box-shadow:0 0 0 1px var(--error)}.inline-error{margin:16px 0 0;font-size:14px;color:var(--error)}.intro{color:var(--muted);font-size:14px}',
	    '.help ol{margin:12px 0 16px;padding-left:22px}.help li{padding-left:3px;margin:9px 0}.help p{color:var(--muted);font-size:14px}.help p:last-child{margin-bottom:0}',
	    '</style></head><body><main><header><h1>Open Activity</h1><p data-i18n="Choose a shortcut for each activity.">Choose a shortcut for each activity.</p></header>',
	    '<details class="card" aria-labelledby="activity-help-heading"><summary id="activity-help-heading" data-i18n="What is an activity?">What is an activity?</summary><p class="hint" data-i18n="Activities are live updates shown by compatible XOCE apps and watchfaces, such as a countdown, music or a new notification.">Activities are live updates shown by compatible XOCE apps and watchfaces, such as a countdown, music or a new notification.</p><p class="hint" data-i18n="Open Activity is an optional shortcut back to the app shown on Dynamic or Halftone. For example, use Quick Launch while a countdown is visible to open Timer. It opens the app, not a particular saved timer.">Open Activity is an optional shortcut back to the app shown on Dynamic or Halftone. For example, use Quick Launch while a countdown is visible to open Timer. It opens the app, not a particular saved timer.</p><p class="hint" data-i18n="Sharing activities between apps needs plugin support and a connected phone. Timer works on its own without sharing.">Sharing activities between apps needs plugin support and a connected phone. Timer works on its own without sharing.</p></details>',
	    '<form id="settings"><section class="card" aria-labelledby="watchface-heading"><h2 id="watchface-heading" data-i18n="Watchface">Watchface</h2><label class="sr-only" for="watchface" data-i18n="Watchface">Watchface</label><select id="watchface" disabled aria-describedby="watchface-help"><option value="" disabled hidden selected data-i18n="Loading saved choice…">Loading saved choice…</option><option value="dynamic">Dynamic</option><option value="halftone">Halftone</option></select><p id="watchface-help" class="hint" data-i18n="Open activities shown by this watchface. Change this choice when you switch watchfaces.">Open activities shown by this watchface. Change this choice when you switch watchfaces.</p></section>',
	    '<section class="card" aria-labelledby="shortcuts-heading"><h2 id="shortcuts-heading" data-i18n="Activity shortcuts">Activity shortcuts</h2>',
	    picker('primary', 'Primary activity'), picker('secondary', 'Secondary activity'),
	    '<p id="shortcut-error" class="inline-error" hidden></p><p id="assignment-help" class="intro" style="margin-top:20px"></p></section>',
	    '<section class="card" aria-labelledby="appearance-heading"><h2 id="appearance-heading" data-i18n="Watch appearance">Watch appearance</h2><label for="text-size" data-i18n="Text size">Text size</label><select id="text-size" disabled aria-describedby="text-size-help watch-delivery"><option value="" disabled hidden selected data-i18n="Loading saved choice…">Loading saved choice…</option><option value="follow" data-i18n="Follow Pebble">Follow Pebble</option><option value="small" data-i18n="Small">Small</option><option value="medium" data-i18n="Medium">Medium</option><option value="large" data-i18n="Large">Large</option></select><p id="text-size-help" class="hint" data-i18n="Follow Pebble uses your watch’s text size.">Follow Pebble uses your watch’s text size.</p><label for="watch-theme" data-i18n="Watch appearance">Watch appearance</label><select id="watch-theme" disabled aria-describedby="watch-theme-help watch-delivery"><option value="" disabled hidden selected data-i18n="Loading saved choice…">Loading saved choice…</option><option value="follow" disabled hidden data-i18n="Follow Pebble">Follow Pebble</option><option value="light" data-i18n="Light">Light</option><option value="dark" data-i18n="Dark">Dark</option></select><p id="watch-theme-help" class="hint"></p><p class="hint" data-i18n="Launch Open Activity from your watch’s app list to apply display settings.">Launch Open Activity from your watch’s app list to apply display settings.</p><p id="watch-delivery" class="hint" role="status" aria-live="polite" aria-atomic="true" data-i18n="Watch appearance will update when Open Activity next opens." hidden>Watch appearance will update when Open Activity next opens.</p><button id="delivery-retry" type="button" data-i18n="Retry watch delivery" hidden>Retry watch delivery</button></section>',
	    '</form><details class="card help"><summary data-i18n="Setup & help">Setup &amp; help</summary><ol><li data-i18n="Install the current build of your selected watchface.">Install the current build of your selected watchface.</li><li data-i18n="Allow Open Activity to launch apps in the Pebble phone app.">Allow Open Activity to launch apps in the Pebble phone app.</li><li data-i18n="In Pebble’s Quick Launch settings, assign this same Open Activity app to each shortcut you want to use.">In Pebble’s Quick Launch settings, assign this same Open Activity app to each shortcut you want to use.</li></ol>',
	    '<p data-i18n="Use one connected watch. This opens the selected watchface’s recent activity. It does not switch sources automatically.">Use one connected watch. This opens the selected watchface’s recent activity. It does not switch sources automatically.</p>',
	    '<p data-i18n="A missing or expired activity returns to the watchface. It never substitutes Primary for a missing Secondary.">A missing or expired activity returns to the watchface. It never substitutes Primary for a missing Secondary.</p>',
	    '<p data-i18n="These choices apply when the shortcut is assigned to Open Activity. Other Quick Launch assignments stay as you set them.">These choices apply when the shortcut is assigned to Open Activity. Other Quick Launch assignments stay as you set them.</p>',
	    '<p data-i18n="Open Activity from the watch’s app list stays open for setup. Open its settings in the Pebble phone app, then press Back on the watch when finished. Assigned Quick Launch shortcuts still open activities automatically.">Open Activity from the watch’s app list stays open for setup. Open its settings in the Pebble phone app, then press Back on the watch when finished. Assigned Quick Launch shortcuts still open activities automatically.</p>',
	    '<p data-i18n="Back cancels while Opening… is shown. A launch already sent to the phone may still finish.">Back cancels while Opening… is shown. A launch already sent to the phone may still finish.</p>',
	    initial.mode === 'legacy' ? '<p class="hint" data-i18n="This legacy settings route closes after Save. Reopen settings to check the saved choices.">This legacy settings route closes after Save. Reopen settings to check the saved choices.</p>' : '',
	    '</details></main><footer id="actions"><div class="footer-inner"><p id="status" class="status" role="status" aria-live="polite" data-i18n="Loading settings…">Loading settings…</p><div class="actions">',
	    '<button id="retry" type="button" hidden data-i18n="Retry loading">Retry loading</button><button id="discard" type="button" disabled data-i18n="Discard">Discard</button><button id="save" type="submit" form="settings" disabled data-i18n="Save">Save</button>',
	    '</div></div></footer><script>(', behavior.toString(), ')(', JSON.stringify(initial).replace(/</g, '\\u003c'), ');</script></body></html>'
	  ].join('\n');
	}
	module.exports = function(settings, invalid, appearance,preferences) {
	  var current = model.normalize(settings) || model.defaults();
	  return render({mode:'legacy',preferences:preferences,settings: model.choices(current), needsRepair: !!invalid, needsMigration: current.version === 1, appearance: appearance || uiModel.defaults(), needsAppearanceRepair: appearance === null});
	};
	module.exports.config = function() { return render({mode: 'plugin'}); };


/***/ }),
/* 11 */
/***/ (function(module, exports) {

	'use strict';
	
	// Shared phone presentation only. Apps keep their own fields, drafts and save
	// controllers. Export a string so bundled HTML and offline Clay use the same CSS.
	module.exports = [
	  ':root{color-scheme:light;--page:#f4f5f7;--card:#fff;--ink:#15181c;--muted:#5d6571;--line:#d9dee6;--field:#f4f5f7;--accent:#145ca3;--accent-ink:#fff;--error:#a1231d;--title-size:28px;--section-size:20px;--card-radius:12px;--control-height:44px;--save-height:48px;--focus-width:3px;--control-motion:144ms;--disclose-motion:160ms;--font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}',
	  '@media(prefers-color-scheme:dark){:root{color-scheme:dark;--page:#11151b;--card:#1d232d;--ink:#f3f5f7;--muted:#b5bfcc;--line:#465165;--field:#252e3b;--accent:#77bbff;--accent-ink:#10151b;--error:#ffb4ab}}',
	  '*,*:before,*:after{box-sizing:border-box}',
	  'html{background:var(--page);color:var(--ink);scroll-padding-bottom:calc(var(--footer-space,var(--actions-height,144px)) + 16px)}',
	  'body{margin:0;background:var(--page);color:var(--ink);font:16px/1.5 var(--font-family)}',
	  'main{max-width:512px;margin:auto;padding:24px 16px calc(var(--footer-space,var(--actions-height,144px)) + 24px)}',
	  'header{margin-bottom:24px}header:after{content:"";display:block;width:48px;height:4px;border-radius:2px;background:var(--accent)}',
	  'h1{margin:0;font-size:var(--title-size);line-height:1.2;letter-spacing:-.6px}header>p{margin:12px 0 16px;color:var(--muted)}',
	  'h2{margin:0 0 16px;font-size:var(--section-size);line-height:1.3;font-weight:700;color:var(--ink)}h3{font-size:17px;margin:16px 0 8px}p{margin:0 0 16px}',
	  '.card{margin:0 0 24px;padding:16px;background:var(--card);border:1px solid var(--line);border-radius:var(--card-radius)}.card>p:last-child{margin-bottom:0}',
	  'button,input,select,textarea{font:inherit}',
	  'button,select,input:not([type=checkbox]):not([type=hidden]),textarea{min-height:var(--control-height);border:1px solid var(--line);border-radius:8px;background:var(--field);color:var(--ink)}',
	  'input,select,textarea{width:100%;min-width:0;padding:9px 12px}select{padding:9px 10px}',
	  'button{padding:9px 12px;font-weight:650;line-height:1.5;text-align:center;cursor:pointer;overflow-wrap:anywhere}',
	  'button:disabled{opacity:.45;cursor:default}select:disabled{opacity:.6}',
	  'label{display:block;margin:16px 0 8px;font-weight:650}label input,label select,label textarea{display:block;margin-top:7px}',
	  'input[type=checkbox]{width:22px;height:22px;padding:0;flex:0 0 22px;accent-color:var(--accent)}',
	  'button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible,summary:focus-visible{outline:var(--focus-width) solid var(--accent);outline-offset:3px}',
	  '.hint{font-size:14px;color:var(--muted);margin:8px 0 0;overflow-wrap:anywhere}',
	  'details>summary{min-height:var(--control-height);display:list-item;line-height:24px;padding:10px 0;align-content:center;cursor:pointer;font-weight:650;color:var(--ink)}details[open]>summary{margin-bottom:16px}',
	  'details>p{font-size:14px;color:var(--muted);margin-top:0}details>p:last-child{margin-bottom:0}',
	  '.error,.status.error{color:var(--error)}',
	  'footer{position:fixed;bottom:0;left:0;right:0;padding:12px 16px max(16px,env(safe-area-inset-bottom));background:var(--page);border-top:1px solid var(--line)}footer[data-flow=true]{position:static}',
	  '.footer-inner{max-width:480px;margin:auto}.status{font-size:14px;line-height:1.5;color:var(--muted);margin:0 0 12px;min-height:21px;text-align:left}',
	  '.actions{display:flex;gap:8px}.actions button{flex:1;min-width:0;overflow-wrap:anywhere}footer[data-flow=true] .actions{flex-direction:column}',
	  '#save{min-height:var(--save-height);background:var(--accent);border-color:var(--accent);color:var(--accent-ink)}',
	  '.sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}[hidden]{display:none!important}',
	  'a{color:var(--accent)}',
	  'button,select,summary{transition:background-color var(--control-motion) ease-out,border-color var(--control-motion) ease-out,color var(--control-motion) ease-out}button:active:not(:disabled){transform:translateY(1px)}',
	  'details[open]>:not(summary){animation:xoce-disclose var(--disclose-motion) ease-out}@keyframes xoce-disclose{from{opacity:0;transform:translateY(-3px)}to{opacity:1;transform:translateY(0)}}',
	  '@media(max-width:340px){main{padding-left:12px;padding-right:12px}.card{padding-left:12px;padding-right:12px}footer{padding-left:12px;padding-right:12px}.actions{flex-wrap:wrap}.actions button{min-width:90px}}',
	  '@media(max-width:260px){.actions{flex-direction:column}main{padding-top:16px}}',
	  '@media(prefers-reduced-motion:reduce){*,*:before,*:after{transition:none!important;animation:none!important}button:active:not(:disabled){transform:none}}'
	].join('\n');


/***/ }),
/* 12 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';
	module.exports=__webpack_require__(13).words;


/***/ }),
/* 13 */
/***/ (function(module, exports) {

	module.exports = {"languages":["en","cs","sk","de","fr","es","it","pt","nl","pl","da","sv","no","fi","hu","ro","tr"],"native":["Activity","Opening...","Open settings in","the Pebble app.","Quick Launch","opens activities.","An activity is an update on Dynamic or Halftone, such as a Timer countdown.","Open settings in the Pebble phone app. Assign Open Activity to Quick Launch to open the app behind the activity on your chosen watchface."],"words":{"en":{"Choose a shortcut for each activity.":"Choose a shortcut for each activity.","Activity shortcuts":"Activity shortcuts","Primary activity":"Primary activity","Secondary activity":"Secondary activity","Not assigned":"Not assigned","Loading saved choice…":"Loading saved choice…","Not loaded":"Not loaded","Saved choice not loaded yet.":"Saved choice not loaded yet.","No shortcut assigned.":"No shortcut assigned.","Opens the smaller activity row.":"Opens the smaller activity row.","Opens the large activity.":"Opens the large activity.","Choose a different shortcut for each activity.":"Choose a different shortcut for each activity.","Choose shortcuts, then assign Open Activity to them in Pebble’s Quick Launch settings.":"Choose shortcuts, then assign Open Activity to them in Pebble’s Quick Launch settings.","Use a different shortcut for each activity before setting up Quick Launch.":"Use a different shortcut for each activity before setting up Quick Launch.","No activity shortcut is enabled. Choose a shortcut above to open an activity.":"No activity shortcut is enabled. Choose a shortcut above to open an activity.","In Pebble’s Quick Launch settings, assign Open Activity to {shortcuts}.":"In Pebble’s Quick Launch settings, assign Open Activity to {shortcuts}."," and ":" and ","Hold Up":"Hold Up","Hold Center":"Hold Center","Hold Down":"Hold Down","Hold Back":"Hold Back","Tap Up":"Tap Up","Tap Down":"Tap Down","Hold Back + Up":"Hold Back + Up","Hold Up + Down":"Hold Up + Down","Watch appearance":"Watch appearance","Light":"Light","Dark":"Dark","Watch colours are independent of this phone page.":"Watch colours are independent of this phone page.","Update Open Activity to change watch appearance.":"Update Open Activity to change watch appearance.","Watch appearance will update when Open Activity next opens.":"Watch appearance will update when Open Activity next opens.","No changes to save.":"No changes to save.","Unsaved changes.":"Unsaved changes.","Saving…":"Saving…","✓ Saved":"✓ Saved","Save":"Save","Discard":"Discard","Cancel":"Cancel","Reload saved":"Reload saved","Retry loading":"Retry loading","Loading settings…":"Loading settings…","Couldn’t save. Try again.":"Couldn’t save. Try again.","Save not confirmed. Reload saved choices or save again.":"Save not confirmed. Reload saved choices or save again.","Review these choices and save to repair unreadable settings.":"Review these choices and save to repair unreadable settings.","Saved settings could not be read. Review these choices before saving.":"Saved settings could not be read. Review these choices before saving.","Save to use these two shortcuts.":"Save to use these two shortcuts.","Could not load settings. Retry, or reopen this page from Pebble.":"Could not load settings. Retry, or reopen this page from Pebble.","Saved settings reloaded.":"Saved settings reloaded.","Setup & help":"Setup & help","Watchface":"Watchface","Open activities shown by this watchface. Change this choice when you switch watchfaces.":"Open activities shown by this watchface. Change this choice when you switch watchfaces.","Install the current build of your selected watchface.":"Install the current build of your selected watchface.","Allow Open Activity to launch apps in the Pebble phone app.":"Allow Open Activity to launch apps in the Pebble phone app.","In Pebble’s Quick Launch settings, assign this same Open Activity app to each shortcut you want to use.":"In Pebble’s Quick Launch settings, assign this same Open Activity app to each shortcut you want to use.","Use one connected watch. This opens the selected watchface’s recent activity. It does not switch sources automatically.":"Use one connected watch. This opens the selected watchface’s recent activity. It does not switch sources automatically.","A missing or expired activity returns to the watchface. It never substitutes Primary for a missing Secondary.":"A missing or expired activity returns to the watchface. It never substitutes Primary for a missing Secondary.","These choices apply when the shortcut is assigned to Open Activity. Other Quick Launch assignments stay as you set them.":"These choices apply when the shortcut is assigned to Open Activity. Other Quick Launch assignments stay as you set them.","Open Activity from the watch’s app list stays open for setup. Open its settings in the Pebble phone app, then press Back on the watch when finished. Assigned Quick Launch shortcuts still open activities automatically.":"Open Activity from the watch’s app list stays open for setup. Open its settings in the Pebble phone app, then press Back on the watch when finished. Assigned Quick Launch shortcuts still open activities automatically.","Back cancels while Opening… is shown. A launch already sent to the phone may still finish.":"Back cancels while Opening… is shown. A launch already sent to the phone may still finish.","This legacy settings route closes after Save. Reopen settings to check the saved choices.":"This legacy settings route closes after Save. Reopen settings to check the saved choices.","Activity":"Activity","Opening...":"Opening...","Open settings in":"Open settings in","the Pebble app.":"the Pebble app.","Quick Launch":"Quick Launch","opens activities.":"opens activities.","Text size":"Text size","Follow Pebble":"Follow Pebble","Small":"Small","Medium":"Medium","Large":"Large","Follow Pebble appearance is unavailable on this build. It uses your last Light or Dark choice.":"Follow Pebble appearance is unavailable on this build. It uses your last Light or Dark choice.","Applied on watch":"Applied on watch","Saved on phone · Pending on watch":"Saved on phone · Pending on watch","Saved on phone · Watch could not confirm saving":"Saved on phone · Watch could not confirm saving","Retry watch delivery":"Retry watch delivery","Follow Pebble uses your watch’s text size.":"Follow Pebble uses your watch’s text size.","Launch Open Activity from your watch’s app list to apply display settings.":"Launch Open Activity from your watch’s app list to apply display settings.","What is an activity?":"What is an activity?","Activities are live updates shown by compatible XOCE apps and watchfaces, such as a countdown, music or a new notification.":"Activities are live updates shown by compatible XOCE apps and watchfaces, such as a countdown, music or a new notification.","Sharing activities between apps needs plugin support and a connected phone. Timer works on its own without sharing.":"Sharing activities between apps needs plugin support and a connected phone. Timer works on its own without sharing.","Open Activity is an optional shortcut back to the app shown on Dynamic or Halftone. For example, use Quick Launch while a countdown is visible to open Timer. It opens the app, not a particular saved timer.":"Open Activity is an optional shortcut back to the app shown on Dynamic or Halftone. For example, use Quick Launch while a countdown is visible to open Timer. It opens the app, not a particular saved timer.","An activity is an update on Dynamic or Halftone, such as a Timer countdown.":"An activity is an update on Dynamic or Halftone, such as a Timer countdown.","Open settings in the Pebble phone app. Assign Open Activity to Quick Launch to open the app behind the activity on your chosen watchface.":"Open settings in the Pebble phone app. Assign Open Activity to Quick Launch to open the app behind the activity on your chosen watchface."},"cs":{"Choose a shortcut for each activity.":"Vyberte zkratku pro každou aktivitu.","Activity shortcuts":"Zkratky aktivit","Primary activity":"Hlavní aktivita","Secondary activity":"Vedlejší aktivita","Not assigned":"Nepřiřazeno","Loading saved choice…":"Načítání uložené volby…","Not loaded":"Nenačteno","Saved choice not loaded yet.":"Uložená volba ještě není načtena.","No shortcut assigned.":"Není přiřazena žádná zkratka.","Opens the smaller activity row.":"Otevře aktivitu v menším řádku.","Opens the large activity.":"Otevře hlavní aktivitu.","Choose a different shortcut for each activity.":"Pro každou aktivitu vyberte jinou zkratku.","Choose shortcuts, then assign Open Activity to them in Pebble’s Quick Launch settings.":"Vyberte zkratky a potom jim v nastavení rychlého spuštění Pebble přiřaďte Open Activity.","Use a different shortcut for each activity before setting up Quick Launch.":"Před nastavením rychlého spuštění vyberte pro každou aktivitu jinou zkratku.","No activity shortcut is enabled. Choose a shortcut above to open an activity.":"Žádná zkratka není zapnutá. Pro otevření aktivity vyberte zkratku výše.","In Pebble’s Quick Launch settings, assign Open Activity to {shortcuts}.":"V nastavení rychlého spuštění Pebble přiřaďte Open Activity ke zkratkám: {shortcuts}."," and ":" a ","Hold Up":"Podržení horního","Hold Center":"Podržení prostředního","Hold Down":"Podržení dolního","Hold Back":"Podržení Zpět","Tap Up":"Stisk horního","Tap Down":"Stisk dolního","Hold Back + Up":"Podržení Zpět + horního","Hold Up + Down":"Podržení horního + dolního","Watch appearance":"Vzhled hodinek","Light":"Světlý","Dark":"Tmavý","Watch colours are independent of this phone page.":"Barvy hodinek jsou nezávislé na vzhledu této stránky.","Update Open Activity to change watch appearance.":"Pro změnu vzhledu aktualizujte Open Activity.","Watch appearance will update when Open Activity next opens.":"Vzhled hodinek se aktualizuje při příštím otevření Open Activity.","No changes to save.":"Žádné změny k uložení.","Unsaved changes.":"Neuložené změny.","Saving…":"Ukládání…","✓ Saved":"✓ Uloženo","Save":"Uložit","Discard":"Zahodit","Cancel":"Zrušit","Reload saved":"Načíst uložené","Retry loading":"Zkusit načíst znovu","Loading settings…":"Načítání nastavení…","Couldn’t save. Try again.":"Uložení se nezdařilo. Zkuste to znovu.","Save not confirmed. Reload saved choices or save again.":"Uložení není potvrzeno. Načtěte uložené volby nebo uložení opakujte.","Review these choices and save to repair unreadable settings.":"Zkontrolujte volby a uložením opravte nečitelné nastavení.","Saved settings could not be read. Review these choices before saving.":"Uložené nastavení nelze přečíst. Před uložením zkontrolujte volby.","Save to use these two shortcuts.":"Uložením začnete používat tyto dvě zkratky.","Could not load settings. Retry, or reopen this page from Pebble.":"Nastavení nelze načíst. Zkuste to znovu nebo stránku znovu otevřete z Pebble.","Saved settings reloaded.":"Uložené nastavení bylo znovu načteno.","Setup & help":"Nastavení a nápověda","Watchface":"Ciferník","Open activities shown by this watchface. Change this choice when you switch watchfaces.":"Otevírat aktivity zobrazené tímto ciferníkem. Při změně ciferníku upravte tuto volbu.","Install the current build of your selected watchface.":"Nainstalujte aktuální sestavení vybraného ciferníku.","Allow Open Activity to launch apps in the Pebble phone app.":"V aplikaci Pebble v telefonu povolte Open Activity spouštět aplikace.","In Pebble’s Quick Launch settings, assign this same Open Activity app to each shortcut you want to use.":"V nastavení rychlého spuštění Pebble přiřaďte stejnou aplikaci Open Activity ke každé požadované zkratce.","Use one connected watch. This opens the selected watchface’s recent activity. It does not switch sources automatically.":"Používejte jedny připojené hodinky. Otevře se poslední aktivita vybraného ciferníku. Zdroj se nepřepíná automaticky.","A missing or expired activity returns to the watchface. It never substitutes Primary for a missing Secondary.":"Chybějící nebo neplatná aktivita vás vrátí na ciferník. Chybějící vedlejší aktivita se nenahradí hlavní.","These choices apply when the shortcut is assigned to Open Activity. Other Quick Launch assignments stay as you set them.":"Volby platí pro zkratky přiřazené Open Activity. Ostatní přiřazení rychlého spuštění zůstávají beze změny.","Open Activity from the watch’s app list stays open for setup. Open its settings in the Pebble phone app, then press Back on the watch when finished. Assigned Quick Launch shortcuts still open activities automatically.":"Při spuštění ze seznamu aplikací zůstane Open Activity otevřená pro nastavení. Otevřete její nastavení v telefonu a po dokončení stiskněte na hodinkách Zpět. Přiřazené zkratky dál otevírají aktivity automaticky.","Back cancels while Opening… is shown. A launch already sent to the phone may still finish.":"Při zobrazení Otevírání… lze akci zrušit tlačítkem Zpět. Spuštění již odeslané do telefonu může být dokončeno.","This legacy settings route closes after Save. Reopen settings to check the saved choices.":"Tato starší cesta nastavení se po uložení zavře. Uložené volby zkontrolujte opětovným otevřením nastavení.","Activity":"Aktivita","Opening...":"Otevírání…","Open settings in":"Nastavení otevřete","the Pebble app.":"v aplikaci Pebble.","Quick Launch":"Rychlé spuštění","opens activities.":"otevírá aktivity.","Text size":"Velikost textu","Follow Pebble":"Podle Pebble","Small":"Malá","Medium":"Střední","Large":"Velká","Follow Pebble appearance is unavailable on this build. It uses your last Light or Dark choice.":"Vzhled podle Pebble není v této verzi dostupný. Použije se poslední světlá nebo tmavá volba.","Applied on watch":"Použito v hodinkách","Saved on phone · Pending on watch":"Uloženo v telefonu · Čeká na hodinky","Saved on phone · Watch could not confirm saving":"Uloženo v telefonu · Hodinky nepotvrdily uložení","Retry watch delivery":"Znovu odeslat do hodinek","Follow Pebble uses your watch’s text size.":"Podle Pebble použije velikost textu nastavenou v hodinkách.","Launch Open Activity from your watch’s app list to apply display settings.":"Nastavení displeje použiješ spuštěním Open Activity ze seznamu aplikací v hodinkách.","What is an activity?":"Co je aktivita?","Activities are live updates shown by compatible XOCE apps and watchfaces, such as a countdown, music or a new notification.":"Aktivity jsou průběžné informace, které zobrazují kompatibilní aplikace a ciferníky XOCE, například odpočet, hudba nebo nové oznámení.","Sharing activities between apps needs plugin support and a connected phone. Timer works on its own without sharing.":"Sdílení aktivit mezi aplikacemi vyžaduje podporu pluginů a připojený telefon. Timer funguje samostatně i bez sdílení.","Open Activity is an optional shortcut back to the app shown on Dynamic or Halftone. For example, use Quick Launch while a countdown is visible to open Timer. It opens the app, not a particular saved timer.":"Open Activity je volitelná zkratka zpět do aplikace zobrazené na Dynamic nebo Halftone. Když vidíte odpočet, můžete přes Quick Launch otevřít Timer. Otevře se aplikace, nikoli konkrétní uložený časovač.","An activity is an update on Dynamic or Halftone, such as a Timer countdown.":"Aktivita je průběžná informace na Dynamic nebo Halftone, například odpočet Timer.","Open settings in the Pebble phone app. Assign Open Activity to Quick Launch to open the app behind the activity on your chosen watchface.":"Otevřete nastavení v aplikaci Pebble v telefonu. Přiřaďte Open Activity ke Quick Launch. Zkratka otevře aplikaci za aktivitou na zvoleném ciferníku."},"sk":{"Choose a shortcut for each activity.":"Vyberte skratku pre každú aktivitu.","Activity shortcuts":"Skratky aktivít","Primary activity":"Hlavná aktivita","Secondary activity":"Vedľajšia aktivita","Not assigned":"Nepriradené","Loading saved choice…":"Načítanie uloženej voľby…","Not loaded":"Nenačítané","Saved choice not loaded yet.":"Uložená voľba ešte nie je načítaná.","No shortcut assigned.":"Nie je priradená skratka.","Opens the smaller activity row.":"Otvorí aktivitu v menšom riadku.","Opens the large activity.":"Otvorí hlavnú aktivitu.","Choose a different shortcut for each activity.":"Pre každú aktivitu vyberte inú skratku.","Choose shortcuts, then assign Open Activity to them in Pebble’s Quick Launch settings.":"Vyberte skratky a priraďte im Open Activity v rýchlom spustení Pebble.","Use a different shortcut for each activity before setting up Quick Launch.":"Pre každú aktivitu vyberte inú skratku.","No activity shortcut is enabled. Choose a shortcut above to open an activity.":"Nie je zapnutá žiadna skratka. Vyberte skratku vyššie.","In Pebble’s Quick Launch settings, assign Open Activity to {shortcuts}.":"V rýchlom spustení Pebble priraďte Open Activity ku skratkám: {shortcuts}."," and ":" a ","Hold Up":"Podržanie horného","Hold Center":"Podržanie stredného","Hold Down":"Podržanie dolného","Hold Back":"Podržanie Späť","Tap Up":"Stlačenie horného","Tap Down":"Stlačenie dolného","Hold Back + Up":"Podržanie Späť + horného","Hold Up + Down":"Podržanie horného + dolného","Watch appearance":"Vzhľad hodiniek","Light":"Svetlý","Dark":"Tmavý","Watch colours are independent of this phone page.":"Vzhľad hodiniek je nezávislý od tejto stránky.","Update Open Activity to change watch appearance.":"Pre zmenu vzhľadu aktualizujte Open Activity.","Watch appearance will update when Open Activity next opens.":"Vzhľad sa aktualizuje pri ďalšom otvorení Open Activity.","No changes to save.":"Žiadne zmeny na uloženie.","Unsaved changes.":"Neuložené zmeny","Saving…":"Ukladá sa…","✓ Saved":"✓ Uložené","Save":"Uložiť","Discard":"Zahodiť zmeny","Cancel":"Zrušiť","Reload saved":"Načítať uložené","Retry loading":"Skúsiť načítať znova","Loading settings…":"Načítavajú sa nastavenia…","Couldn’t save. Try again.":"Nepodarilo sa uložiť. Skúste to znova.","Save not confirmed. Reload saved choices or save again.":"Uloženie nie je potvrdené. Načítajte uložené nastavenia alebo uložte znova.","Review these choices and save to repair unreadable settings.":"Uložené nastavenia sa nedajú prečítať. Pred uložením skontrolujte voľby.","Saved settings could not be read. Review these choices before saving.":"Uložené nastavenia sa nedajú prečítať. Pred uložením skontrolujte voľby.","Save to use these two shortcuts.":"Uložením začnete používať tieto dve skratky.","Could not load settings. Retry, or reopen this page from Pebble.":"Nastavenia sa nedajú načítať. Skúste to znova alebo otvorte stránku z Pebble.","Saved settings reloaded.":"Uložené nastavenia boli znovu načítané.","Setup & help":"Nastavenie a pomoc","Watchface":"Ciferník","Open activities shown by this watchface. Change this choice when you switch watchfaces.":"Otvárať aktivity tohto ciferníka. Pri zmene ciferníka upravte voľbu.","Install the current build of your selected watchface.":"Nainštalujte aktuálne zostavenie vybraného ciferníka.","Allow Open Activity to launch apps in the Pebble phone app.":"V aplikácii Pebble povoľte Open Activity spúšťať aplikácie.","In Pebble’s Quick Launch settings, assign this same Open Activity app to each shortcut you want to use.":"V rýchlom spustení Pebble priraďte tú istú aplikáciu Open Activity ku každej skratke.","Use one connected watch. This opens the selected watchface’s recent activity. It does not switch sources automatically.":"Používajte jedny pripojené hodinky. Otvorí sa posledná aktivita vybraného ciferníka. Zdroj sa neprepína automaticky.","A missing or expired activity returns to the watchface. It never substitutes Primary for a missing Secondary.":"Chýbajúca alebo neplatná aktivita vráti na ciferník. Chýbajúca vedľajšia aktivita sa nenahradí hlavnou.","These choices apply when the shortcut is assigned to Open Activity. Other Quick Launch assignments stay as you set them.":"Voľby platia pre skratky priradené Open Activity. Ostatné priradenia zostávajú nezmenené.","Open Activity from the watch’s app list stays open for setup. Open its settings in the Pebble phone app, then press Back on the watch when finished. Assigned Quick Launch shortcuts still open activities automatically.":"Open Activity zo zoznamu aplikácií zostane otvorená pre nastavenie. Nastavenia otvorte v Pebble v telefóne a nakoniec stlačte Späť na hodinkách. Priradené skratky naďalej otvárajú aktivity automaticky.","Back cancels while Opening… is shown. A launch already sent to the phone may still finish.":"Počas Otváranie… zruší akciu Späť. Už odoslané spustenie môže byť dokončené.","This legacy settings route closes after Save. Reopen settings to check the saved choices.":"Táto staršia cesta sa po uložení zavrie. Voľby skontrolujte opätovným otvorením nastavení.","Activity":"Aktivita","Opening...":"Otváranie…","Open settings in":"Nastavenia otvorte","the Pebble app.":"v aplikácii Pebble.","Quick Launch":"Rýchle spustenie","opens activities.":"otvára aktivity.","Text size":"Veľkosť textu","Follow Pebble":"Podľa Pebble","Small":"Malá","Medium":"Stredná","Large":"Veľká","Follow Pebble appearance is unavailable on this build. It uses your last Light or Dark choice.":"Vzhľad podľa Pebble nie je v tejto verzii dostupný. Použije sa posledná svetlá alebo tmavá voľba.","Applied on watch":"Použité v hodinkách","Saved on phone · Pending on watch":"Uložené v telefóne · Čaká na hodinky","Saved on phone · Watch could not confirm saving":"Uložené v telefóne · Hodinky nepotvrdili uloženie","Retry watch delivery":"Znova odoslať do hodiniek","Follow Pebble uses your watch’s text size.":"Podľa Pebble použije veľkosť textu nastavenú v hodinkách.","Launch Open Activity from your watch’s app list to apply display settings.":"Nastavenie displeja použiješ spustením Open Activity zo zoznamu aplikácií v hodinkách.","What is an activity?":"Čo je aktivita?","Activities are live updates shown by compatible XOCE apps and watchfaces, such as a countdown, music or a new notification.":"Aktivity sú priebežné informácie, ktoré zobrazujú kompatibilné aplikácie a ciferníky XOCE, napríklad odpočet, hudba alebo nové oznámenie.","Sharing activities between apps needs plugin support and a connected phone. Timer works on its own without sharing.":"Zdieľanie aktivít medzi aplikáciami vyžaduje podporu pluginov a pripojený telefón. Timer funguje samostatne aj bez zdieľania.","Open Activity is an optional shortcut back to the app shown on Dynamic or Halftone. For example, use Quick Launch while a countdown is visible to open Timer. It opens the app, not a particular saved timer.":"Open Activity je voliteľná skratka späť do aplikácie zobrazenej na Dynamic alebo Halftone. Keď vidíte odpočet, môžete cez Quick Launch otvoriť Timer. Otvorí sa aplikácia, nie konkrétny uložený časovač.","An activity is an update on Dynamic or Halftone, such as a Timer countdown.":"Aktivita je priebežná informácia na Dynamic alebo Halftone, napríklad odpočet Timer.","Open settings in the Pebble phone app. Assign Open Activity to Quick Launch to open the app behind the activity on your chosen watchface.":"Otvorte nastavenia v aplikácii Pebble v telefóne. Priraďte Open Activity ku Quick Launch. Skratka otvorí aplikáciu za aktivitou na zvolenom ciferníku."},"de":{"Choose a shortcut for each activity.":"Wähle ein Kürzel pro Aktivität.","Activity shortcuts":"Aktivitätskürzel","Primary activity":"Hauptaktivität","Secondary activity":"Zweite Aktivität","Not assigned":"Nicht zugewiesen","Loading saved choice…":"Gespeicherte Auswahl laden…","Not loaded":"Nicht geladen","Saved choice not loaded yet.":"Gespeicherte Auswahl noch nicht geladen.","No shortcut assigned.":"Kein Kürzel zugewiesen.","Opens the smaller activity row.":"Öffnet die kleinere Aktivitätszeile.","Opens the large activity.":"Öffnet die große Aktivität.","Choose a different shortcut for each activity.":"Wähle unterschiedliche Kürzel für die Aktivitäten.","Choose shortcuts, then assign Open Activity to them in Pebble’s Quick Launch settings.":"Wähle Kürzel und weise ihnen Open Activity im Pebble-Schnellstart zu.","Use a different shortcut for each activity before setting up Quick Launch.":"Wähle unterschiedliche Kürzel für die Aktivitäten.","No activity shortcut is enabled. Choose a shortcut above to open an activity.":"Kein Aktivitätskürzel aktiv. Wähle oben ein Kürzel zum Öffnen.","In Pebble’s Quick Launch settings, assign Open Activity to {shortcuts}.":"Weise Open Activity im Pebble-Schnellstart {shortcuts} zu."," and ":" und ","Hold Up":"Obere Taste halten","Hold Center":"Mittlere Taste halten","Hold Down":"Untere Taste halten","Hold Back":"Zurück-Taste halten","Tap Up":"Obere Taste drücken","Tap Down":"Untere Taste drücken","Hold Back + Up":"Zurück + Oben halten","Hold Up + Down":"Oben + Unten halten","Watch appearance":"Darstellung der Uhr","Light":"Hell","Dark":"Dunkel","Watch colours are independent of this phone page.":"Die Uhrendarstellung ist unabhängig von dieser Telefonseite.","Update Open Activity to change watch appearance.":"Aktualisiere Open Activity, um das Uhrendesign zu ändern.","Watch appearance will update when Open Activity next opens.":"Das Uhrendesign wird beim nächsten Öffnen von Open Activity aktualisiert.","No changes to save.":"Keine Änderungen zu speichern.","Unsaved changes.":"Ungespeicherte Änderungen","Saving…":"Wird gespeichert…","✓ Saved":"✓ Gespeichert","Save":"Speichern","Discard":"Verwerfen","Cancel":"Abbrechen","Reload saved":"Gespeicherte laden","Retry loading":"Erneut laden","Loading settings…":"Einstellungen werden geladen…","Couldn’t save. Try again.":"Speichern fehlgeschlagen. Erneut versuchen.","Save not confirmed. Reload saved choices or save again.":"Speichern nicht bestätigt. Gespeicherte Einstellungen neu laden oder erneut speichern.","Review these choices and save to repair unreadable settings.":"Gespeicherte Einstellungen konnten nicht gelesen werden. Auswahl vor dem Speichern prüfen.","Saved settings could not be read. Review these choices before saving.":"Gespeicherte Einstellungen konnten nicht gelesen werden. Auswahl vor dem Speichern prüfen.","Save to use these two shortcuts.":"Speichern, um diese zwei Kürzel zu nutzen.","Could not load settings. Retry, or reopen this page from Pebble.":"Einstellungen konnten nicht geladen werden. Erneut versuchen oder diese Seite über Pebble neu öffnen.","Saved settings reloaded.":"Gespeicherte Einstellungen neu geladen.","Setup & help":"Einrichtung und Hilfe","Watchface":"Zifferblatt","Open activities shown by this watchface. Change this choice when you switch watchfaces.":"Öffne Aktivitäten dieses Zifferblatts. Ändere die Auswahl beim Wechsel des Zifferblatts.","Install the current build of your selected watchface.":"Installiere den aktuellen Build des ausgewählten Zifferblatts.","Allow Open Activity to launch apps in the Pebble phone app.":"Erlaube Open Activity in der Pebble-Telefon-App, Apps zu starten.","In Pebble’s Quick Launch settings, assign this same Open Activity app to each shortcut you want to use.":"Weise dieselbe Open Activity-App jedem gewünschten Kürzel im Pebble-Schnellstart zu.","Use one connected watch. This opens the selected watchface’s recent activity. It does not switch sources automatically.":"Nutze eine verbundene Uhr. Es öffnet die letzte Aktivität des gewählten Zifferblatts. Quellen wechseln nicht automatisch.","A missing or expired activity returns to the watchface. It never substitutes Primary for a missing Secondary.":"Fehlende oder abgelaufene Aktivitäten führen zum Zifferblatt zurück. Eine fehlende zweite Aktivität wird nie durch die Hauptaktivität ersetzt.","These choices apply when the shortcut is assigned to Open Activity. Other Quick Launch assignments stay as you set them.":"Diese Auswahl gilt für Kürzel mit Open Activity. Andere Schnellstart-Zuweisungen bleiben unverändert.","Open Activity from the watch’s app list stays open for setup. Open its settings in the Pebble phone app, then press Back on the watch when finished. Assigned Quick Launch shortcuts still open activities automatically.":"Aus der App-Liste bleibt Open Activity zur Einrichtung offen. Öffne die Einstellungen in der Pebble-Telefon-App und drücke danach Zurück auf der Uhr. Zugewiesene Schnellstart-Kürzel öffnen Aktivitäten weiter automatisch.","Back cancels while Opening… is shown. A launch already sent to the phone may still finish.":"Zurück bricht während Öffnen… ab. Ein bereits ans Telefon gesendeter Start kann trotzdem erfolgen.","This legacy settings route closes after Save. Reopen settings to check the saved choices.":"Diese ältere Einstellungsseite schließt nach dem Speichern. Einstellungen zum Prüfen erneut öffnen.","Activity":"Aktivität","Opening...":"Öffnen…","Open settings in":"Einstellungen in","the Pebble app.":"der Pebble-App.","Quick Launch":"Schnellstart","opens activities.":"öffnet Aktivitäten.","Text size":"Textgröße","Follow Pebble":"Pebble folgen","Small":"Klein","Medium":"Mittel","Large":"Groß","Follow Pebble appearance is unavailable on this build. It uses your last Light or Dark choice.":"Das Pebble-Erscheinungsbild ist in dieser Version nicht verfügbar. Die letzte Auswahl Hell oder Dunkel wird verwendet.","Applied on watch":"Auf der Uhr angewendet","Saved on phone · Pending on watch":"Auf dem Telefon gespeichert · Auf der Uhr ausstehend","Saved on phone · Watch could not confirm saving":"Auf dem Telefon gespeichert · Uhr konnte das Speichern nicht bestätigen","Retry watch delivery":"Erneut an die Uhr senden","Follow Pebble uses your watch’s text size.":"Pebble folgen verwendet die Textgröße deiner Uhr.","Launch Open Activity from your watch’s app list to apply display settings.":"Öffne Open Activity aus der App-Liste deiner Uhr, um die Anzeigeeinstellungen anzuwenden.","What is an activity?":"Was ist eine Aktivität?","Activities are live updates shown by compatible XOCE apps and watchfaces, such as a countdown, music or a new notification.":"Aktivitäten sind aktuelle Informationen in kompatiblen XOCE-Apps und Zifferblättern, etwa ein Countdown, Musik oder eine neue Mitteilung.","Sharing activities between apps needs plugin support and a connected phone. Timer works on its own without sharing.":"Das Teilen von Aktivitäten zwischen Apps benötigt Plugin-Unterstützung und ein verbundenes Telefon. Timer funktioniert auch ohne Teilen.","Open Activity is an optional shortcut back to the app shown on Dynamic or Halftone. For example, use Quick Launch while a countdown is visible to open Timer. It opens the app, not a particular saved timer.":"Open Activity ist ein optionaler Kurzbefehl zurück zur auf Dynamic oder Halftone gezeigten App. Nutze etwa Quick Launch bei sichtbarem Countdown, um Timer zu öffnen. Es öffnet die App, keinen bestimmten gespeicherten Timer.","An activity is an update on Dynamic or Halftone, such as a Timer countdown.":"Eine Aktivität ist eine aktuelle Information auf Dynamic oder Halftone, etwa ein Timer-Countdown.","Open settings in the Pebble phone app. Assign Open Activity to Quick Launch to open the app behind the activity on your chosen watchface.":"Öffne die Einstellungen in der Pebble-App auf dem Telefon. Weise Open Activity Quick Launch zu, um die App hinter der Aktivität auf deinem gewählten Zifferblatt zu öffnen."},"fr":{"Choose a shortcut for each activity.":"Choisissez un raccourci par activité.","Activity shortcuts":"Raccourcis d’activités","Primary activity":"Activité principale","Secondary activity":"Activité secondaire","Not assigned":"Non attribué","Loading saved choice…":"Chargement du choix enregistré…","Not loaded":"Non chargé","Saved choice not loaded yet.":"Choix enregistré pas encore chargé.","No shortcut assigned.":"Aucun raccourci attribué.","Opens the smaller activity row.":"Ouvre la petite ligne d’activité.","Opens the large activity.":"Ouvre la grande activité.","Choose a different shortcut for each activity.":"Choisissez un raccourci différent par activité.","Choose shortcuts, then assign Open Activity to them in Pebble’s Quick Launch settings.":"Choisissez des raccourcis et attribuez-leur Open Activity dans le lancement rapide Pebble.","Use a different shortcut for each activity before setting up Quick Launch.":"Choisissez un raccourci différent par activité.","No activity shortcut is enabled. Choose a shortcut above to open an activity.":"Aucun raccourci actif. Choisissez un raccourci ci-dessus pour ouvrir une activité.","In Pebble’s Quick Launch settings, assign Open Activity to {shortcuts}.":"Dans le lancement rapide de Pebble, attribuez Open Activity à {shortcuts}."," and ":" et ","Hold Up":"Appui long en haut","Hold Center":"Appui long au centre","Hold Down":"Appui long en bas","Hold Back":"Appui long sur Retour","Tap Up":"Appui en haut","Tap Down":"Appui en bas","Hold Back + Up":"Appui long Retour + Haut","Hold Up + Down":"Appui long Haut + Bas","Watch appearance":"Apparence de la montre","Light":"Clair","Dark":"Sombre","Watch colours are independent of this phone page.":"L’apparence de la montre est indépendante de cette page.","Update Open Activity to change watch appearance.":"Mettez Open Activity à jour pour changer l’apparence de la montre.","Watch appearance will update when Open Activity next opens.":"L’apparence se mettra à jour à la prochaine ouverture d’Open Activity.","No changes to save.":"Aucune modification à enregistrer.","Unsaved changes.":"Modifications non enregistrées","Saving…":"Enregistrement…","✓ Saved":"✓ Enregistré","Save":"Enregistrer","Discard":"Annuler les modifications","Cancel":"Annuler","Reload saved":"Recharger","Retry loading":"Réessayer le chargement","Loading settings…":"Chargement des réglages…","Couldn’t save. Try again.":"Échec de l’enregistrement. Réessayez.","Save not confirmed. Reload saved choices or save again.":"Enregistrement non confirmé. Rechargez les réglages enregistrés ou enregistrez à nouveau.","Review these choices and save to repair unreadable settings.":"Impossible de lire les réglages enregistrés. Vérifiez les choix avant d’enregistrer.","Saved settings could not be read. Review these choices before saving.":"Impossible de lire les réglages enregistrés. Vérifiez les choix avant d’enregistrer.","Save to use these two shortcuts.":"Enregistrez pour utiliser ces deux raccourcis.","Could not load settings. Retry, or reopen this page from Pebble.":"Impossible de charger les réglages. Réessayez ou rouvrez cette page depuis Pebble.","Saved settings reloaded.":"Réglages enregistrés rechargés.","Setup & help":"Configuration et aide","Watchface":"Cadran","Open activities shown by this watchface. Change this choice when you switch watchfaces.":"Ouvrez les activités de ce cadran. Modifiez ce choix quand vous changez de cadran.","Install the current build of your selected watchface.":"Installez la version actuelle du cadran choisi.","Allow Open Activity to launch apps in the Pebble phone app.":"Autorisez Open Activity à lancer des apps dans l’app Pebble du téléphone.","In Pebble’s Quick Launch settings, assign this same Open Activity app to each shortcut you want to use.":"Attribuez la même app Open Activity à chaque raccourci voulu dans le lancement rapide Pebble.","Use one connected watch. This opens the selected watchface’s recent activity. It does not switch sources automatically.":"Utilisez une seule montre connectée. L’activité récente du cadran choisi s’ouvre. La source ne change pas automatiquement.","A missing or expired activity returns to the watchface. It never substitutes Primary for a missing Secondary.":"Une activité absente ou expirée ramène au cadran. L’activité principale ne remplace jamais une secondaire absente.","These choices apply when the shortcut is assigned to Open Activity. Other Quick Launch assignments stay as you set them.":"Ces choix concernent les raccourcis attribués à Open Activity. Les autres attributions restent inchangées.","Open Activity from the watch’s app list stays open for setup. Open its settings in the Pebble phone app, then press Back on the watch when finished. Assigned Quick Launch shortcuts still open activities automatically.":"Depuis la liste des apps, Open Activity reste ouverte pour la configuration. Ouvrez ses réglages dans Pebble sur le téléphone, puis appuyez sur Retour sur la montre. Les raccourcis attribués ouvrent toujours automatiquement les activités.","Back cancels while Opening… is shown. A launch already sent to the phone may still finish.":"Retour annule pendant Ouverture… Un lancement déjà envoyé au téléphone peut encore aboutir.","This legacy settings route closes after Save. Reopen settings to check the saved choices.":"Cette ancienne page se ferme après enregistrement. Rouvrez les réglages pour vérifier les choix.","Activity":"Activité","Opening...":"Ouverture…","Open settings in":"Ouvrez les réglages","the Pebble app.":"dans l’app Pebble.","Quick Launch":"Lancement rapide","opens activities.":"ouvre les activités.","Text size":"Taille du texte","Follow Pebble":"Suivre Pebble","Small":"Petite","Medium":"Moyenne","Large":"Grande","Follow Pebble appearance is unavailable on this build. It uses your last Light or Dark choice.":"Le thème Pebble est indisponible dans cette version. Le dernier choix Clair ou Sombre est utilisé.","Applied on watch":"Appliqué sur la montre","Saved on phone · Pending on watch":"Enregistré sur le téléphone · En attente sur la montre","Saved on phone · Watch could not confirm saving":"Enregistré sur le téléphone · La montre n’a pas confirmé l’enregistrement","Retry watch delivery":"Renvoyer à la montre","Follow Pebble uses your watch’s text size.":"Suivre Pebble utilise la taille du texte de votre montre.","Launch Open Activity from your watch’s app list to apply display settings.":"Ouvrez Open Activity depuis la liste des applications de la montre pour appliquer les réglages d’affichage.","What is an activity?":"Qu’est-ce qu’une activité ?","Activities are live updates shown by compatible XOCE apps and watchfaces, such as a countdown, music or a new notification.":"Les activités sont des informations en cours affichées par les apps et cadrans XOCE compatibles : compte à rebours, musique ou nouvelle notification.","Sharing activities between apps needs plugin support and a connected phone. Timer works on its own without sharing.":"Le partage d’activités entre apps nécessite les plugins et un téléphone connecté. Timer fonctionne aussi sans partage.","Open Activity is an optional shortcut back to the app shown on Dynamic or Halftone. For example, use Quick Launch while a countdown is visible to open Timer. It opens the app, not a particular saved timer.":"Open Activity est un raccourci facultatif vers l’app affichée sur Dynamic ou Halftone. Par exemple, utilisez Quick Launch pendant un compte à rebours pour ouvrir Timer. Il ouvre l’app, pas un minuteur enregistré précis.","An activity is an update on Dynamic or Halftone, such as a Timer countdown.":"Une activité est une information sur Dynamic ou Halftone, comme un compte à rebours Timer.","Open settings in the Pebble phone app. Assign Open Activity to Quick Launch to open the app behind the activity on your chosen watchface.":"Ouvrez les réglages dans l’app Pebble du téléphone. Assignez Open Activity à Quick Launch pour ouvrir l’app associée à l’activité sur le cadran choisi."},"es":{"Choose a shortcut for each activity.":"Elige un atajo por actividad.","Activity shortcuts":"Atajos de actividades","Primary activity":"Actividad principal","Secondary activity":"Actividad secundaria","Not assigned":"Sin asignar","Loading saved choice…":"Cargando opción guardada…","Not loaded":"Sin cargar","Saved choice not loaded yet.":"La opción guardada aún no se ha cargado.","No shortcut assigned.":"Ningún atajo asignado.","Opens the smaller activity row.":"Abre la fila pequeña de actividad.","Opens the large activity.":"Abre la actividad grande.","Choose a different shortcut for each activity.":"Elige un atajo distinto para cada actividad.","Choose shortcuts, then assign Open Activity to them in Pebble’s Quick Launch settings.":"Elige atajos y asígnales Open Activity en Inicio rápido de Pebble.","Use a different shortcut for each activity before setting up Quick Launch.":"Elige un atajo distinto para cada actividad.","No activity shortcut is enabled. Choose a shortcut above to open an activity.":"Ningún atajo activo. Elige uno arriba para abrir una actividad.","In Pebble’s Quick Launch settings, assign Open Activity to {shortcuts}.":"En Inicio rápido de Pebble, asigna Open Activity a {shortcuts}."," and ":" y ","Hold Up":"Mantener arriba","Hold Center":"Mantener centro","Hold Down":"Mantener abajo","Hold Back":"Mantener Atrás","Tap Up":"Pulsar arriba","Tap Down":"Pulsar abajo","Hold Back + Up":"Mantener Atrás + Arriba","Hold Up + Down":"Mantener Arriba + Abajo","Watch appearance":"Aspecto del reloj","Light":"Claro","Dark":"Oscuro","Watch colours are independent of this phone page.":"El aspecto del reloj es independiente de esta página.","Update Open Activity to change watch appearance.":"Actualiza Open Activity para cambiar el aspecto del reloj.","Watch appearance will update when Open Activity next opens.":"El aspecto se actualizará al abrir Open Activity de nuevo.","No changes to save.":"No hay cambios para guardar.","Unsaved changes.":"Cambios sin guardar","Saving…":"Guardando…","✓ Saved":"✓ Guardado","Save":"Guardar","Discard":"Descartar","Cancel":"Cancelar","Reload saved":"Recargar guardados","Retry loading":"Reintentar carga","Loading settings…":"Cargando ajustes…","Couldn’t save. Try again.":"No se pudo guardar. Inténtalo de nuevo.","Save not confirmed. Reload saved choices or save again.":"Guardado sin confirmar. Recarga los ajustes guardados o guarda otra vez.","Review these choices and save to repair unreadable settings.":"No se pudieron leer los ajustes guardados. Revisa las opciones antes de guardar.","Saved settings could not be read. Review these choices before saving.":"No se pudieron leer los ajustes guardados. Revisa las opciones antes de guardar.","Save to use these two shortcuts.":"Guarda para usar estos dos atajos.","Could not load settings. Retry, or reopen this page from Pebble.":"No se pudieron cargar los ajustes. Reintenta o abre esta página desde Pebble.","Saved settings reloaded.":"Ajustes guardados recargados.","Setup & help":"Configuración y ayuda","Watchface":"Esfera","Open activities shown by this watchface. Change this choice when you switch watchfaces.":"Abre actividades de esta esfera. Cambia esta opción al cambiar de esfera.","Install the current build of your selected watchface.":"Instala la versión actual de la esfera elegida.","Allow Open Activity to launch apps in the Pebble phone app.":"Permite a Open Activity abrir apps en la app Pebble del teléfono.","In Pebble’s Quick Launch settings, assign this same Open Activity app to each shortcut you want to use.":"Asigna la misma app Open Activity a cada atajo deseado en Inicio rápido de Pebble.","Use one connected watch. This opens the selected watchface’s recent activity. It does not switch sources automatically.":"Usa un solo reloj conectado. Se abre la actividad reciente de la esfera elegida. El origen no cambia automáticamente.","A missing or expired activity returns to the watchface. It never substitutes Primary for a missing Secondary.":"Una actividad ausente o caducada vuelve a la esfera. La principal nunca sustituye a una secundaria ausente.","These choices apply when the shortcut is assigned to Open Activity. Other Quick Launch assignments stay as you set them.":"Estas opciones afectan a atajos asignados a Open Activity. Las demás asignaciones de Inicio rápido no cambian.","Open Activity from the watch’s app list stays open for setup. Open its settings in the Pebble phone app, then press Back on the watch when finished. Assigned Quick Launch shortcuts still open activities automatically.":"Desde la lista de apps, Open Activity queda abierta para configurar. Abre sus ajustes en Pebble del teléfono y pulsa Atrás en el reloj al terminar. Los atajos asignados siguen abriendo actividades automáticamente.","Back cancels while Opening… is shown. A launch already sent to the phone may still finish.":"Atrás cancela durante Abriendo… Un inicio ya enviado al teléfono puede completarse.","This legacy settings route closes after Save. Reopen settings to check the saved choices.":"Esta página antigua se cierra al guardar. Reabre ajustes para comprobar las opciones.","Activity":"Actividad","Opening...":"Abriendo…","Open settings in":"Abre ajustes en","the Pebble app.":"la app Pebble.","Quick Launch":"Inicio rápido","opens activities.":"abre actividades.","Text size":"Tamaño del texto","Follow Pebble":"Seguir Pebble","Small":"Pequeño","Medium":"Mediano","Large":"Grande","Follow Pebble appearance is unavailable on this build. It uses your last Light or Dark choice.":"El aspecto de Pebble no está disponible en esta versión. Se usa la última opción Claro u Oscuro.","Applied on watch":"Aplicado en el reloj","Saved on phone · Pending on watch":"Guardado en el teléfono · Pendiente en el reloj","Saved on phone · Watch could not confirm saving":"Guardado en el teléfono · El reloj no confirmó el guardado","Retry watch delivery":"Reenviar al reloj","Follow Pebble uses your watch’s text size.":"Seguir Pebble usa el tamaño de texto de tu reloj.","Launch Open Activity from your watch’s app list to apply display settings.":"Abre Open Activity desde la lista de aplicaciones del reloj para aplicar los ajustes de pantalla.","What is an activity?":"¿Qué es una actividad?","Activities are live updates shown by compatible XOCE apps and watchfaces, such as a countdown, music or a new notification.":"Las actividades son información en curso que muestran las apps y esferas XOCE compatibles, como una cuenta atrás, música o una nueva notificación.","Sharing activities between apps needs plugin support and a connected phone. Timer works on its own without sharing.":"Compartir actividades entre apps requiere compatibilidad con plugins y un teléfono conectado. Timer funciona por sí solo sin compartir.","Open Activity is an optional shortcut back to the app shown on Dynamic or Halftone. For example, use Quick Launch while a countdown is visible to open Timer. It opens the app, not a particular saved timer.":"Open Activity es un atajo opcional a la app mostrada en Dynamic o Halftone. Por ejemplo, usa Quick Launch con una cuenta atrás visible para abrir Timer. Abre la app, no un temporizador guardado concreto.","An activity is an update on Dynamic or Halftone, such as a Timer countdown.":"Una actividad es información en Dynamic o Halftone, como una cuenta atrás de Timer.","Open settings in the Pebble phone app. Assign Open Activity to Quick Launch to open the app behind the activity on your chosen watchface.":"Abre los ajustes en la app Pebble del teléfono. Asigna Open Activity a Quick Launch para abrir la app asociada a la actividad de la esfera elegida."},"it":{"Choose a shortcut for each activity.":"Scegli una scorciatoia per attività.","Activity shortcuts":"Scorciatoie attività","Primary activity":"Attività principale","Secondary activity":"Attività secondaria","Not assigned":"Non assegnato","Loading saved choice…":"Caricamento scelta salvata…","Not loaded":"Non caricato","Saved choice not loaded yet.":"Scelta salvata non ancora caricata.","No shortcut assigned.":"Nessuna scorciatoia assegnata.","Opens the smaller activity row.":"Apre la riga attività più piccola.","Opens the large activity.":"Apre l’attività grande.","Choose a different shortcut for each activity.":"Scegli scorciatoie diverse per le attività.","Choose shortcuts, then assign Open Activity to them in Pebble’s Quick Launch settings.":"Scegli scorciatoie e assegna loro Open Activity nell’avvio rapido Pebble.","Use a different shortcut for each activity before setting up Quick Launch.":"Scegli scorciatoie diverse per le attività.","No activity shortcut is enabled. Choose a shortcut above to open an activity.":"Nessuna scorciatoia attiva. Scegline una sopra per aprire un’attività.","In Pebble’s Quick Launch settings, assign Open Activity to {shortcuts}.":"Nell’avvio rapido di Pebble assegna Open Activity a {shortcuts}."," and ":" e ","Hold Up":"Tieni premuto su","Hold Center":"Tieni premuto centro","Hold Down":"Tieni premuto giù","Hold Back":"Tieni premuto Indietro","Tap Up":"Premi su","Tap Down":"Premi giù","Hold Back + Up":"Tieni Indietro + Su","Hold Up + Down":"Tieni Su + Giù","Watch appearance":"Aspetto dell’orologio","Light":"Chiaro","Dark":"Scuro","Watch colours are independent of this phone page.":"L’aspetto dell’orologio è indipendente da questa pagina.","Update Open Activity to change watch appearance.":"Aggiorna Open Activity per cambiare l’aspetto dell’orologio.","Watch appearance will update when Open Activity next opens.":"L’aspetto si aggiornerà alla prossima apertura di Open Activity.","No changes to save.":"Nessuna modifica da salvare.","Unsaved changes.":"Modifiche non salvate","Saving…":"Salvataggio…","✓ Saved":"✓ Salvato","Save":"Salva","Discard":"Scarta","Cancel":"Annulla","Reload saved":"Ricarica salvate","Retry loading":"Riprova caricamento","Loading settings…":"Caricamento impostazioni…","Couldn’t save. Try again.":"Salvataggio non riuscito. Riprova.","Save not confirmed. Reload saved choices or save again.":"Salvataggio non confermato. Ricarica le impostazioni salvate o salva di nuovo.","Review these choices and save to repair unreadable settings.":"Impossibile leggere le impostazioni salvate. Controlla le scelte prima di salvare.","Saved settings could not be read. Review these choices before saving.":"Impossibile leggere le impostazioni salvate. Controlla le scelte prima di salvare.","Save to use these two shortcuts.":"Salva per usare queste due scorciatoie.","Could not load settings. Retry, or reopen this page from Pebble.":"Impossibile caricare le impostazioni. Riprova o riapri questa pagina da Pebble.","Saved settings reloaded.":"Impostazioni salvate ricaricate.","Setup & help":"Configurazione e aiuto","Watchface":"Quadrante","Open activities shown by this watchface. Change this choice when you switch watchfaces.":"Apri le attività di questo quadrante. Cambia la scelta quando cambi quadrante.","Install the current build of your selected watchface.":"Installa la versione attuale del quadrante scelto.","Allow Open Activity to launch apps in the Pebble phone app.":"Consenti a Open Activity di avviare app nell’app Pebble sul telefono.","In Pebble’s Quick Launch settings, assign this same Open Activity app to each shortcut you want to use.":"Assegna la stessa app Open Activity a ogni scorciatoia desiderata nell’avvio rapido Pebble.","Use one connected watch. This opens the selected watchface’s recent activity. It does not switch sources automatically.":"Usa un solo orologio connesso. Si apre l’attività recente del quadrante scelto. La sorgente non cambia automaticamente.","A missing or expired activity returns to the watchface. It never substitutes Primary for a missing Secondary.":"Un’attività assente o scaduta torna al quadrante. La principale non sostituisce mai una secondaria assente.","These choices apply when the shortcut is assigned to Open Activity. Other Quick Launch assignments stay as you set them.":"Le scelte valgono per scorciatoie assegnate a Open Activity. Le altre assegnazioni restano invariate.","Open Activity from the watch’s app list stays open for setup. Open its settings in the Pebble phone app, then press Back on the watch when finished. Assigned Quick Launch shortcuts still open activities automatically.":"Dall’elenco app, Open Activity resta aperta per configurarla. Apri le impostazioni in Pebble sul telefono, poi premi Indietro sull’orologio. Le scorciatoie assegnate continuano ad aprire attività automaticamente.","Back cancels while Opening… is shown. A launch already sent to the phone may still finish.":"Indietro annulla durante Apertura… Un avvio già inviato al telefono può completarsi.","This legacy settings route closes after Save. Reopen settings to check the saved choices.":"Questa pagina precedente si chiude dopo Salva. Riapri le impostazioni per verificare le scelte.","Activity":"Attività","Opening...":"Apertura…","Open settings in":"Apri impostazioni","the Pebble app.":"nell’app Pebble.","Quick Launch":"Avvio rapido","opens activities.":"apre le attività.","Text size":"Dimensione del testo","Follow Pebble":"Segui Pebble","Small":"Piccolo","Medium":"Medio","Large":"Grande","Follow Pebble appearance is unavailable on this build. It uses your last Light or Dark choice.":"L’aspetto Pebble non è disponibile in questa versione. Viene usata l’ultima scelta Chiaro o Scuro.","Applied on watch":"Applicato sull’orologio","Saved on phone · Pending on watch":"Salvato sul telefono · In attesa sull’orologio","Saved on phone · Watch could not confirm saving":"Salvato sul telefono · L’orologio non ha confermato il salvataggio","Retry watch delivery":"Invia di nuovo all’orologio","Follow Pebble uses your watch’s text size.":"Segui Pebble usa la dimensione del testo dell’orologio.","Launch Open Activity from your watch’s app list to apply display settings.":"Apri Open Activity dall’elenco delle app dell’orologio per applicare le impostazioni dello schermo.","What is an activity?":"Che cos’è un’attività?","Activities are live updates shown by compatible XOCE apps and watchfaces, such as a countdown, music or a new notification.":"Le attività sono aggiornamenti mostrati dalle app e dai quadranti XOCE compatibili, come un conto alla rovescia, musica o una nuova notifica.","Sharing activities between apps needs plugin support and a connected phone. Timer works on its own without sharing.":"La condivisione delle attività tra app richiede il supporto dei plugin e un telefono connesso. Timer funziona anche senza condivisione.","Open Activity is an optional shortcut back to the app shown on Dynamic or Halftone. For example, use Quick Launch while a countdown is visible to open Timer. It opens the app, not a particular saved timer.":"Open Activity è una scorciatoia facoltativa all’app mostrata su Dynamic o Halftone. Ad esempio, usa Quick Launch con un conto alla rovescia visibile per aprire Timer. Apre l’app, non un timer salvato specifico.","An activity is an update on Dynamic or Halftone, such as a Timer countdown.":"Un’attività è un aggiornamento su Dynamic o Halftone, come un conto alla rovescia Timer.","Open settings in the Pebble phone app. Assign Open Activity to Quick Launch to open the app behind the activity on your chosen watchface.":"Apri le impostazioni nell’app Pebble sul telefono. Assegna Open Activity a Quick Launch per aprire l’app associata all’attività sul quadrante scelto."},"pt":{"Choose a shortcut for each activity.":"Escolha um atalho por atividade.","Activity shortcuts":"Atalhos de atividades","Primary activity":"Atividade principal","Secondary activity":"Atividade secundária","Not assigned":"Não atribuído","Loading saved choice…":"A carregar escolha guardada…","Not loaded":"Não carregado","Saved choice not loaded yet.":"Escolha guardada ainda não carregada.","No shortcut assigned.":"Nenhum atalho atribuído.","Opens the smaller activity row.":"Abre a linha de atividade menor.","Opens the large activity.":"Abre a atividade grande.","Choose a different shortcut for each activity.":"Escolha um atalho diferente para cada atividade.","Choose shortcuts, then assign Open Activity to them in Pebble’s Quick Launch settings.":"Escolha atalhos e atribua-lhes Open Activity no início rápido Pebble.","Use a different shortcut for each activity before setting up Quick Launch.":"Escolha um atalho diferente para cada atividade.","No activity shortcut is enabled. Choose a shortcut above to open an activity.":"Nenhum atalho ativo. Escolha um acima para abrir uma atividade.","In Pebble’s Quick Launch settings, assign Open Activity to {shortcuts}.":"No início rápido do Pebble, atribua Open Activity a {shortcuts}."," and ":" e ","Hold Up":"Manter cima premido","Hold Center":"Manter centro premido","Hold Down":"Manter baixo premido","Hold Back":"Manter Voltar premido","Tap Up":"Premir cima","Tap Down":"Premir baixo","Hold Back + Up":"Manter Voltar + Cima","Hold Up + Down":"Manter Cima + Baixo","Watch appearance":"Aspeto do relógio","Light":"Claro","Dark":"Escuro","Watch colours are independent of this phone page.":"O aspeto do relógio é independente desta página.","Update Open Activity to change watch appearance.":"Atualize Open Activity para mudar o aspeto do relógio.","Watch appearance will update when Open Activity next opens.":"O aspeto atualiza na próxima abertura do Open Activity.","No changes to save.":"Não há alterações para guardar.","Unsaved changes.":"Alterações por guardar","Saving…":"A guardar…","✓ Saved":"✓ Guardado","Save":"Guardar","Discard":"Descartar","Cancel":"Cancelar","Reload saved":"Recarregar guardadas","Retry loading":"Tentar carregar de novo","Loading settings…":"A carregar definições…","Couldn’t save. Try again.":"Não foi possível guardar. Tente novamente.","Save not confirmed. Reload saved choices or save again.":"Gravação não confirmada. Recarregue as definições guardadas ou guarde novamente.","Review these choices and save to repair unreadable settings.":"Não foi possível ler definições guardadas. Reveja as escolhas antes de guardar.","Saved settings could not be read. Review these choices before saving.":"Não foi possível ler definições guardadas. Reveja as escolhas antes de guardar.","Save to use these two shortcuts.":"Guarde para usar estes dois atalhos.","Could not load settings. Retry, or reopen this page from Pebble.":"Não foi possível carregar definições. Tente novamente ou reabra esta página pelo Pebble.","Saved settings reloaded.":"Definições guardadas recarregadas.","Setup & help":"Configuração e ajuda","Watchface":"Mostrador","Open activities shown by this watchface. Change this choice when you switch watchfaces.":"Abra atividades deste mostrador. Altere a escolha ao mudar de mostrador.","Install the current build of your selected watchface.":"Instale a versão atual do mostrador escolhido.","Allow Open Activity to launch apps in the Pebble phone app.":"Permita ao Open Activity iniciar apps na app Pebble do telefone.","In Pebble’s Quick Launch settings, assign this same Open Activity app to each shortcut you want to use.":"Atribua a mesma app Open Activity a cada atalho pretendido no início rápido Pebble.","Use one connected watch. This opens the selected watchface’s recent activity. It does not switch sources automatically.":"Use um só relógio ligado. Abre a atividade recente do mostrador escolhido. A origem não muda automaticamente.","A missing or expired activity returns to the watchface. It never substitutes Primary for a missing Secondary.":"Uma atividade ausente ou expirada volta ao mostrador. A principal nunca substitui uma secundária ausente.","These choices apply when the shortcut is assigned to Open Activity. Other Quick Launch assignments stay as you set them.":"Estas escolhas aplicam-se a atalhos atribuídos ao Open Activity. As outras atribuições não mudam.","Open Activity from the watch’s app list stays open for setup. Open its settings in the Pebble phone app, then press Back on the watch when finished. Assigned Quick Launch shortcuts still open activities automatically.":"Pela lista de apps, Open Activity fica aberta para configurar. Abra definições no Pebble do telefone e prima Voltar no relógio ao terminar. Atalhos atribuídos continuam a abrir atividades automaticamente.","Back cancels while Opening… is shown. A launch already sent to the phone may still finish.":"Voltar cancela durante A abrir… Um início já enviado ao telefone ainda pode terminar.","This legacy settings route closes after Save. Reopen settings to check the saved choices.":"Esta página antiga fecha ao guardar. Reabra definições para verificar as escolhas.","Activity":"Atividade","Opening...":"A abrir…","Open settings in":"Abra as definições","the Pebble app.":"na app Pebble.","Quick Launch":"Início rápido","opens activities.":"abre atividades.","Text size":"Tamanho do texto","Follow Pebble":"Seguir Pebble","Small":"Pequeno","Medium":"Médio","Large":"Grande","Follow Pebble appearance is unavailable on this build. It uses your last Light or Dark choice.":"O aspeto do Pebble não está disponível nesta versão. É usada a última escolha Claro ou Escuro.","Applied on watch":"Aplicado no relógio","Saved on phone · Pending on watch":"Guardado no telefone · Pendente no relógio","Saved on phone · Watch could not confirm saving":"Guardado no telefone · O relógio não confirmou a gravação","Retry watch delivery":"Reenviar para o relógio","Follow Pebble uses your watch’s text size.":"Seguir Pebble usa o tamanho de texto do relógio.","Launch Open Activity from your watch’s app list to apply display settings.":"Abre Open Activity na lista de aplicações do relógio para aplicar as definições do ecrã.","What is an activity?":"O que é uma atividade?","Activities are live updates shown by compatible XOCE apps and watchfaces, such as a countdown, music or a new notification.":"As atividades são informações em curso mostradas por apps e mostradores XOCE compatíveis, como uma contagem decrescente, música ou uma nova notificação.","Sharing activities between apps needs plugin support and a connected phone. Timer works on its own without sharing.":"Partilhar atividades entre apps requer suporte de plugins e um telemóvel ligado. O Timer também funciona sozinho, sem partilha.","Open Activity is an optional shortcut back to the app shown on Dynamic or Halftone. For example, use Quick Launch while a countdown is visible to open Timer. It opens the app, not a particular saved timer.":"Open Activity é um atalho opcional para a app mostrada no Dynamic ou Halftone. Use Quick Launch com uma contagem visível para abrir o Timer. Abre a app, não um temporizador guardado específico.","An activity is an update on Dynamic or Halftone, such as a Timer countdown.":"Uma atividade é uma informação no Dynamic ou Halftone, como uma contagem do Timer.","Open settings in the Pebble phone app. Assign Open Activity to Quick Launch to open the app behind the activity on your chosen watchface.":"Abra as definições na app Pebble do telemóvel. Atribua Open Activity ao Quick Launch para abrir a app da atividade no mostrador escolhido."},"nl":{"Choose a shortcut for each activity.":"Kies een sneltoets per activiteit.","Activity shortcuts":"Activiteitssneltoetsen","Primary activity":"Hoofdactiviteit","Secondary activity":"Tweede activiteit","Not assigned":"Niet toegewezen","Loading saved choice…":"Opgeslagen keuze laden…","Not loaded":"Niet geladen","Saved choice not loaded yet.":"Opgeslagen keuze nog niet geladen.","No shortcut assigned.":"Geen sneltoets toegewezen.","Opens the smaller activity row.":"Opent de kleinere activiteitsrij.","Opens the large activity.":"Opent de grote activiteit.","Choose a different shortcut for each activity.":"Kies een andere sneltoets per activiteit.","Choose shortcuts, then assign Open Activity to them in Pebble’s Quick Launch settings.":"Kies sneltoetsen en wijs Open Activity eraan toe in Pebble Snelstart.","Use a different shortcut for each activity before setting up Quick Launch.":"Kies een andere sneltoets per activiteit.","No activity shortcut is enabled. Choose a shortcut above to open an activity.":"Geen activiteitssneltoets actief. Kies hierboven een sneltoets om een activiteit te openen.","In Pebble’s Quick Launch settings, assign Open Activity to {shortcuts}.":"Wijs Open Activity in Pebble Snelstart toe aan {shortcuts}."," and ":" en ","Hold Up":"Bovenste knop vasthouden","Hold Center":"Middelste knop vasthouden","Hold Down":"Onderste knop vasthouden","Hold Back":"Terugknop vasthouden","Tap Up":"Bovenste knop indrukken","Tap Down":"Onderste knop indrukken","Hold Back + Up":"Terug + Boven vasthouden","Hold Up + Down":"Boven + Onder vasthouden","Watch appearance":"Uiterlijk van het horloge","Light":"Licht","Dark":"Donker","Watch colours are independent of this phone page.":"Het uiterlijk van het horloge staat los van deze telefoonpagina.","Update Open Activity to change watch appearance.":"Werk Open Activity bij om het horloge-uiterlijk te wijzigen.","Watch appearance will update when Open Activity next opens.":"Het uiterlijk wordt bijgewerkt als Open Activity opnieuw opent.","No changes to save.":"Geen wijzigingen om op te slaan.","Unsaved changes.":"Niet-opgeslagen wijzigingen","Saving…":"Opslaan…","✓ Saved":"✓ Opgeslagen","Save":"Opslaan","Discard":"Verwerpen","Cancel":"Annuleren","Reload saved":"Opgeslagen laden","Retry loading":"Opnieuw laden","Loading settings…":"Instellingen laden…","Couldn’t save. Try again.":"Opslaan mislukt. Probeer opnieuw.","Save not confirmed. Reload saved choices or save again.":"Opslaan niet bevestigd. Laad opgeslagen instellingen opnieuw of sla opnieuw op.","Review these choices and save to repair unreadable settings.":"Opgeslagen instellingen konden niet worden gelezen. Controleer je keuzes vóór opslaan.","Saved settings could not be read. Review these choices before saving.":"Opgeslagen instellingen konden niet worden gelezen. Controleer je keuzes vóór opslaan.","Save to use these two shortcuts.":"Sla op om deze twee sneltoetsen te gebruiken.","Could not load settings. Retry, or reopen this page from Pebble.":"Instellingen laden mislukt. Probeer opnieuw of heropen deze pagina via Pebble.","Saved settings reloaded.":"Opgeslagen instellingen opnieuw geladen.","Setup & help":"Instellen en hulp","Watchface":"Wijzerplaat","Open activities shown by this watchface. Change this choice when you switch watchfaces.":"Open activiteiten van deze wijzerplaat. Wijzig dit bij wisselen van wijzerplaat.","Install the current build of your selected watchface.":"Installeer de huidige versie van de gekozen wijzerplaat.","Allow Open Activity to launch apps in the Pebble phone app.":"Geef Open Activity toestemming om apps te starten in de Pebble-telefoonapp.","In Pebble’s Quick Launch settings, assign this same Open Activity app to each shortcut you want to use.":"Wijs dezelfde Open Activity-app toe aan elke gewenste sneltoets in Pebble Snelstart.","Use one connected watch. This opens the selected watchface’s recent activity. It does not switch sources automatically.":"Gebruik één verbonden horloge. De recente activiteit van de gekozen wijzerplaat opent. Bronnen wisselen niet automatisch.","A missing or expired activity returns to the watchface. It never substitutes Primary for a missing Secondary.":"Een ontbrekende of verlopen activiteit keert terug naar de wijzerplaat. Een ontbrekende tweede activiteit wordt nooit vervangen door de hoofdactiviteit.","These choices apply when the shortcut is assigned to Open Activity. Other Quick Launch assignments stay as you set them.":"Deze keuzes gelden voor sneltoetsen met Open Activity. Andere Snelstart-toewijzingen blijven zoals ingesteld.","Open Activity from the watch’s app list stays open for setup. Open its settings in the Pebble phone app, then press Back on the watch when finished. Assigned Quick Launch shortcuts still open activities automatically.":"Vanuit de applijst blijft Open Activity open voor instellen. Open de instellingen in Pebble op de telefoon en druk daarna op Terug op het horloge. Toegewezen sneltoetsen openen nog steeds automatisch activiteiten.","Back cancels while Opening… is shown. A launch already sent to the phone may still finish.":"Terug annuleert tijdens Openen… Een al naar de telefoon verstuurde start kan doorgaan.","This legacy settings route closes after Save. Reopen settings to check the saved choices.":"Deze oudere instellingenroute sluit na opslaan. Heropen instellingen om de keuzes te controleren.","Activity":"Activiteit","Opening...":"Openen…","Open settings in":"Open instellingen","the Pebble app.":"in de Pebble-app.","Quick Launch":"Snelstart","opens activities.":"opent activiteiten.","Text size":"Tekstgrootte","Follow Pebble":"Pebble volgen","Small":"Klein","Medium":"Gemiddeld","Large":"Groot","Follow Pebble appearance is unavailable on this build. It uses your last Light or Dark choice.":"De Pebble-weergave is niet beschikbaar in deze versie. De laatste keuze Licht of Donker wordt gebruikt.","Applied on watch":"Toegepast op horloge","Saved on phone · Pending on watch":"Opgeslagen op telefoon · Wacht op horloge","Saved on phone · Watch could not confirm saving":"Opgeslagen op telefoon · Horloge kon opslaan niet bevestigen","Retry watch delivery":"Opnieuw naar horloge sturen","Follow Pebble uses your watch’s text size.":"Pebble volgen gebruikt de tekstgrootte van je horloge.","Launch Open Activity from your watch’s app list to apply display settings.":"Open Open Activity vanuit de app-lijst op je horloge om de scherminstellingen toe te passen.","What is an activity?":"Wat is een activiteit?","Activities are live updates shown by compatible XOCE apps and watchfaces, such as a countdown, music or a new notification.":"Activiteiten zijn actuele updates in compatibele XOCE-apps en wijzerplaten, zoals een aftelling, muziek of een nieuwe melding.","Sharing activities between apps needs plugin support and a connected phone. Timer works on its own without sharing.":"Activiteiten delen tussen apps vereist pluginondersteuning en een verbonden telefoon. Timer werkt ook zelfstandig zonder delen.","Open Activity is an optional shortcut back to the app shown on Dynamic or Halftone. For example, use Quick Launch while a countdown is visible to open Timer. It opens the app, not a particular saved timer.":"Open Activity is een optionele snelkoppeling naar de app op Dynamic of Halftone. Gebruik bijvoorbeeld Quick Launch bij een zichtbare aftelling om Timer te openen. Het opent de app, geen specifieke opgeslagen timer.","An activity is an update on Dynamic or Halftone, such as a Timer countdown.":"Een activiteit is een update op Dynamic of Halftone, zoals een aftelling van Timer.","Open settings in the Pebble phone app. Assign Open Activity to Quick Launch to open the app behind the activity on your chosen watchface.":"Open de instellingen in de Pebble-telefoonapp. Wijs Open Activity toe aan Quick Launch om de app achter de activiteit op je gekozen wijzerplaat te openen."},"pl":{"Choose a shortcut for each activity.":"Wybierz skrót dla każdej aktywności.","Activity shortcuts":"Skróty aktywności","Primary activity":"Główna aktywność","Secondary activity":"Druga aktywność","Not assigned":"Nieprzypisany","Loading saved choice…":"Ładowanie zapisanego wyboru…","Not loaded":"Nie załadowano","Saved choice not loaded yet.":"Zapisany wybór nie został jeszcze wczytany.","No shortcut assigned.":"Nie przypisano skrótu.","Opens the smaller activity row.":"Otwiera mniejszy wiersz aktywności.","Opens the large activity.":"Otwiera dużą aktywność.","Choose a different shortcut for each activity.":"Wybierz inny skrót dla każdej aktywności.","Choose shortcuts, then assign Open Activity to them in Pebble’s Quick Launch settings.":"Wybierz skróty i przypisz im Open Activity w szybkim uruchamianiu Pebble.","Use a different shortcut for each activity before setting up Quick Launch.":"Wybierz inny skrót dla każdej aktywności.","No activity shortcut is enabled. Choose a shortcut above to open an activity.":"Żaden skrót nie jest aktywny. Wybierz skrót powyżej, aby otwierać aktywność.","In Pebble’s Quick Launch settings, assign Open Activity to {shortcuts}.":"W szybkim uruchamianiu Pebble przypisz Open Activity do {shortcuts}."," and ":" i ","Hold Up":"Przytrzymaj górny","Hold Center":"Przytrzymaj środkowy","Hold Down":"Przytrzymaj dolny","Hold Back":"Przytrzymaj Wstecz","Tap Up":"Naciśnij górny","Tap Down":"Naciśnij dolny","Hold Back + Up":"Przytrzymaj Wstecz + Góra","Hold Up + Down":"Przytrzymaj Góra + Dół","Watch appearance":"Wygląd zegarka","Light":"Jasny","Dark":"Ciemny","Watch colours are independent of this phone page.":"Wygląd zegarka jest niezależny od tej strony.","Update Open Activity to change watch appearance.":"Zaktualizuj Open Activity, aby zmieniać wygląd zegarka.","Watch appearance will update when Open Activity next opens.":"Wygląd zostanie zastosowany przy następnym otwarciu Open Activity.","No changes to save.":"Brak zmian do zapisania.","Unsaved changes.":"Niezapisane zmiany","Saving…":"Zapisywanie…","✓ Saved":"✓ Zapisano","Save":"Zapisz","Discard":"Odrzuć","Cancel":"Anuluj","Reload saved":"Wczytaj zapisane","Retry loading":"Ponów ładowanie","Loading settings…":"Wczytywanie ustawień…","Couldn’t save. Try again.":"Nie udało się zapisać. Spróbuj ponownie.","Save not confirmed. Reload saved choices or save again.":"Zapis niepotwierdzony. Wczytaj zapisane ustawienia lub zapisz ponownie.","Review these choices and save to repair unreadable settings.":"Nie udało się odczytać zapisanych ustawień. Sprawdź wybory przed zapisem.","Saved settings could not be read. Review these choices before saving.":"Nie udało się odczytać zapisanych ustawień. Sprawdź wybory przed zapisem.","Save to use these two shortcuts.":"Zapisz, aby używać tych dwóch skrótów.","Could not load settings. Retry, or reopen this page from Pebble.":"Nie udało się wczytać ustawień. Spróbuj ponownie lub otwórz stronę z Pebble.","Saved settings reloaded.":"Zapisane ustawienia wczytano ponownie.","Setup & help":"Konfiguracja i pomoc","Watchface":"Tarcza","Open activities shown by this watchface. Change this choice when you switch watchfaces.":"Otwieraj aktywności tej tarczy. Zmień wybór po zmianie tarczy.","Install the current build of your selected watchface.":"Zainstaluj aktualną wersję wybranej tarczy.","Allow Open Activity to launch apps in the Pebble phone app.":"Zezwól Open Activity uruchamiać aplikacje w aplikacji Pebble telefonu.","In Pebble’s Quick Launch settings, assign this same Open Activity app to each shortcut you want to use.":"Przypisz tę samą aplikację Open Activity do każdego skrótu w szybkim uruchamianiu Pebble.","Use one connected watch. This opens the selected watchface’s recent activity. It does not switch sources automatically.":"Używaj jednego połączonego zegarka. Otwiera ostatnią aktywność wybranej tarczy. Źródło nie zmienia się automatycznie.","A missing or expired activity returns to the watchface. It never substitutes Primary for a missing Secondary.":"Brak lub wygaśnięcie aktywności przywraca tarczę. Główna nigdy nie zastępuje brakującej drugiej.","These choices apply when the shortcut is assigned to Open Activity. Other Quick Launch assignments stay as you set them.":"Wybory dotyczą skrótów przypisanych do Open Activity. Pozostałe przypisania pozostają bez zmian.","Open Activity from the watch’s app list stays open for setup. Open its settings in the Pebble phone app, then press Back on the watch when finished. Assigned Quick Launch shortcuts still open activities automatically.":"Uruchomione z listy aplikacji Open Activity pozostaje otwarte do konfiguracji. Otwórz ustawienia w Pebble telefonu, po zakończeniu naciśnij Wstecz na zegarku. Przypisane skróty nadal automatycznie otwierają aktywności.","Back cancels while Opening… is shown. A launch already sent to the phone may still finish.":"Wstecz anuluje podczas Otwieranie… Uruchomienie wysłane do telefonu może się dokończyć.","This legacy settings route closes after Save. Reopen settings to check the saved choices.":"Ten starszy ekran zamyka się po zapisie. Otwórz ustawienia ponownie, aby sprawdzić wybory.","Activity":"Aktywność","Opening...":"Otwieranie…","Open settings in":"Otwórz ustawienia","the Pebble app.":"w aplikacji Pebble.","Quick Launch":"Szybkie uruch.","opens activities.":"otwiera aktywności.","Text size":"Rozmiar tekstu","Follow Pebble":"Według Pebble","Small":"Mały","Medium":"Średni","Large":"Duży","Follow Pebble appearance is unavailable on this build. It uses your last Light or Dark choice.":"Wygląd według Pebble jest niedostępny w tej wersji. Używany jest ostatni wybór Jasny lub Ciemny.","Applied on watch":"Zastosowano na zegarku","Saved on phone · Pending on watch":"Zapisano w telefonie · Oczekuje na zegarek","Saved on phone · Watch could not confirm saving":"Zapisano w telefonie · Zegarek nie potwierdził zapisu","Retry watch delivery":"Wyślij ponownie na zegarek","Follow Pebble uses your watch’s text size.":"Według Pebble używa rozmiaru tekstu zegarka.","Launch Open Activity from your watch’s app list to apply display settings.":"Otwórz Open Activity z listy aplikacji zegarka, aby zastosować ustawienia ekranu.","What is an activity?":"Czym jest aktywność?","Activities are live updates shown by compatible XOCE apps and watchfaces, such as a countdown, music or a new notification.":"Aktywności to bieżące informacje wyświetlane przez zgodne aplikacje i tarcze XOCE, takie jak odliczanie, muzyka lub nowe powiadomienie.","Sharing activities between apps needs plugin support and a connected phone. Timer works on its own without sharing.":"Udostępnianie aktywności między aplikacjami wymaga obsługi wtyczek i połączonego telefonu. Timer działa też samodzielnie bez udostępniania.","Open Activity is an optional shortcut back to the app shown on Dynamic or Halftone. For example, use Quick Launch while a countdown is visible to open Timer. It opens the app, not a particular saved timer.":"Open Activity to opcjonalny skrót do aplikacji widocznej na Dynamic lub Halftone. Użyj Quick Launch przy widocznym odliczaniu, aby otworzyć Timer. Otwiera aplikację, nie konkretny zapisany minutnik.","An activity is an update on Dynamic or Halftone, such as a Timer countdown.":"Aktywność to informacja na Dynamic lub Halftone, np. odliczanie Timer.","Open settings in the Pebble phone app. Assign Open Activity to Quick Launch to open the app behind the activity on your chosen watchface.":"Otwórz ustawienia w aplikacji Pebble na telefonie. Przypisz Open Activity do Quick Launch, aby otworzyć aplikację aktywności z wybranej tarczy."},"da":{"Choose a shortcut for each activity.":"Vælg en genvej til hver aktivitet.","Activity shortcuts":"Aktivitetsgenveje","Primary activity":"Primær aktivitet","Secondary activity":"Sekundær aktivitet","Not assigned":"Ikke tildelt","Loading saved choice…":"Indlæser gemt valg…","Not loaded":"Ikke indlæst","Saved choice not loaded yet.":"Gemt valg er ikke indlæst endnu.","No shortcut assigned.":"Ingen genvej tildelt.","Opens the smaller activity row.":"Åbner den mindre aktivitetsrække.","Opens the large activity.":"Åbner den store aktivitet.","Choose a different shortcut for each activity.":"Vælg en forskellig genvej til hver aktivitet.","Choose shortcuts, then assign Open Activity to them in Pebble’s Quick Launch settings.":"Vælg genveje og tildel dem Open Activity i Pebbles hurtigstart.","Use a different shortcut for each activity before setting up Quick Launch.":"Vælg en forskellig genvej til hver aktivitet.","No activity shortcut is enabled. Choose a shortcut above to open an activity.":"Ingen aktivitetsgenvej er aktiv. Vælg en ovenfor for at åbne en aktivitet.","In Pebble’s Quick Launch settings, assign Open Activity to {shortcuts}.":"Tildel Open Activity til {shortcuts} i Pebbles hurtigstart."," and ":" og ","Hold Up":"Hold øverste knap","Hold Center":"Hold midterknappen","Hold Down":"Hold nederste knap","Hold Back":"Hold Tilbage","Tap Up":"Tryk øverste knap","Tap Down":"Tryk nederste knap","Hold Back + Up":"Hold Tilbage + Op","Hold Up + Down":"Hold Op + Ned","Watch appearance":"Urets udseende","Light":"Lyst","Dark":"Mørkt","Watch colours are independent of this phone page.":"Urets udseende er uafhængigt af denne telefonside.","Update Open Activity to change watch appearance.":"Opdater Open Activity for at ændre urets udseende.","Watch appearance will update when Open Activity next opens.":"Udseendet opdateres næste gang Open Activity åbnes.","No changes to save.":"Ingen ændringer at gemme.","Unsaved changes.":"Ikke-gemte ændringer","Saving…":"Gemmer…","✓ Saved":"✓ Gemt","Save":"Gem","Discard":"Kassér","Cancel":"Annuller","Reload saved":"Indlæs gemte","Retry loading":"Prøv at indlæse igen","Loading settings…":"Indlæser indstillinger…","Couldn’t save. Try again.":"Kunne ikke gemme. Prøv igen.","Save not confirmed. Reload saved choices or save again.":"Lagring ikke bekræftet. Genindlæs gemte indstillinger eller gem igen.","Review these choices and save to repair unreadable settings.":"Gemte indstillinger kunne ikke læses. Tjek valgene før du gemmer.","Saved settings could not be read. Review these choices before saving.":"Gemte indstillinger kunne ikke læses. Tjek valgene før du gemmer.","Save to use these two shortcuts.":"Gem for at bruge disse to genveje.","Could not load settings. Retry, or reopen this page from Pebble.":"Kunne ikke indlæse indstillinger. Prøv igen eller genåbn siden fra Pebble.","Saved settings reloaded.":"Gemte indstillinger indlæst igen.","Setup & help":"Opsætning og hjælp","Watchface":"Urskive","Open activities shown by this watchface. Change this choice when you switch watchfaces.":"Åbn aktiviteter fra denne urskive. Skift valget, når du skifter urskive.","Install the current build of your selected watchface.":"Installer den aktuelle version af den valgte urskive.","Allow Open Activity to launch apps in the Pebble phone app.":"Tillad Open Activity at starte apps i Pebble-telefonappen.","In Pebble’s Quick Launch settings, assign this same Open Activity app to each shortcut you want to use.":"Tildel samme Open Activity-app til hver ønsket genvej i Pebbles hurtigstart.","Use one connected watch. This opens the selected watchface’s recent activity. It does not switch sources automatically.":"Brug ét tilsluttet ur. Den valgte urskives seneste aktivitet åbnes. Kilden skifter ikke automatisk.","A missing or expired activity returns to the watchface. It never substitutes Primary for a missing Secondary.":"Manglende eller udløbet aktivitet vender tilbage til urskiven. Primær erstatter aldrig en manglende sekundær.","These choices apply when the shortcut is assigned to Open Activity. Other Quick Launch assignments stay as you set them.":"Valgene gælder genveje tildelt Open Activity. Andre hurtigstart-tildelinger bevares.","Open Activity from the watch’s app list stays open for setup. Open its settings in the Pebble phone app, then press Back on the watch when finished. Assigned Quick Launch shortcuts still open activities automatically.":"Fra applisten forbliver Open Activity åben til opsætning. Åbn indstillinger i Pebble på telefonen, og tryk Tilbage på uret bagefter. Tildelte genveje åbner stadig aktiviteter automatisk.","Back cancels while Opening… is shown. A launch already sent to the phone may still finish.":"Tilbage annullerer under Åbner… En start sendt til telefonen kan stadig gennemføres.","This legacy settings route closes after Save. Reopen settings to check the saved choices.":"Denne ældre side lukker efter Gem. Genåbn indstillinger for at tjekke valgene.","Activity":"Aktivitet","Opening...":"Åbner…","Open settings in":"Åbn indstillinger","the Pebble app.":"i Pebble-appen.","Quick Launch":"Hurtigstart","opens activities.":"åbner aktiviteter.","Text size":"Tekststørrelse","Follow Pebble":"Følg Pebble","Small":"Lille","Medium":"Mellem","Large":"Stor","Follow Pebble appearance is unavailable on this build. It uses your last Light or Dark choice.":"Pebbles udseende er ikke tilgængeligt i denne version. Dit seneste valg Lys eller Mørk bruges.","Applied on watch":"Anvendt på uret","Saved on phone · Pending on watch":"Gemt på telefonen · Afventer uret","Saved on phone · Watch could not confirm saving":"Gemt på telefonen · Uret kunne ikke bekræfte lagringen","Retry watch delivery":"Send til uret igen","Follow Pebble uses your watch’s text size.":"Følg Pebble bruger urets tekststørrelse.","Launch Open Activity from your watch’s app list to apply display settings.":"Åbn Open Activity fra urets appliste for at anvende skærmindstillingerne.","What is an activity?":"Hvad er en aktivitet?","Activities are live updates shown by compatible XOCE apps and watchfaces, such as a countdown, music or a new notification.":"Aktiviteter er aktuelle oplysninger i kompatible XOCE-apps og urskiver, f.eks. en nedtælling, musik eller en ny notifikation.","Sharing activities between apps needs plugin support and a connected phone. Timer works on its own without sharing.":"Deling af aktiviteter mellem apps kræver pluginunderstøttelse og en tilsluttet telefon. Timer virker også alene uden deling.","Open Activity is an optional shortcut back to the app shown on Dynamic or Halftone. For example, use Quick Launch while a countdown is visible to open Timer. It opens the app, not a particular saved timer.":"Open Activity er en valgfri genvej til appen vist på Dynamic eller Halftone. Brug f.eks. Quick Launch under en synlig nedtælling for at åbne Timer. Den åbner appen, ikke en bestemt gemt timer.","An activity is an update on Dynamic or Halftone, such as a Timer countdown.":"En aktivitet er en opdatering på Dynamic eller Halftone, f.eks. en nedtælling fra Timer.","Open settings in the Pebble phone app. Assign Open Activity to Quick Launch to open the app behind the activity on your chosen watchface.":"Åbn indstillingerne i Pebble-appen på telefonen. Tildel Open Activity til Quick Launch for at åbne appen bag aktiviteten på din valgte urskive."},"sv":{"Choose a shortcut for each activity.":"Välj en genväg för varje aktivitet.","Activity shortcuts":"Aktivitetsgenvägar","Primary activity":"Primär aktivitet","Secondary activity":"Sekundär aktivitet","Not assigned":"Inte tilldelad","Loading saved choice…":"Läser in sparat val…","Not loaded":"Inte inläst","Saved choice not loaded yet.":"Sparat val har inte lästs in ännu.","No shortcut assigned.":"Ingen genväg tilldelad.","Opens the smaller activity row.":"Öppnar den mindre aktivitetsraden.","Opens the large activity.":"Öppnar den stora aktiviteten.","Choose a different shortcut for each activity.":"Välj olika genvägar för aktiviteterna.","Choose shortcuts, then assign Open Activity to them in Pebble’s Quick Launch settings.":"Välj genvägar och tilldela dem Open Activity i Pebbles snabbstart.","Use a different shortcut for each activity before setting up Quick Launch.":"Välj olika genvägar för aktiviteterna.","No activity shortcut is enabled. Choose a shortcut above to open an activity.":"Ingen aktivitetsgenväg är aktiv. Välj en ovan för att öppna en aktivitet.","In Pebble’s Quick Launch settings, assign Open Activity to {shortcuts}.":"Tilldela Open Activity till {shortcuts} i Pebbles snabbstart."," and ":" och ","Hold Up":"Håll övre knappen","Hold Center":"Håll mittknappen","Hold Down":"Håll nedre knappen","Hold Back":"Håll Bakåt","Tap Up":"Tryck övre knappen","Tap Down":"Tryck nedre knappen","Hold Back + Up":"Håll Bakåt + Upp","Hold Up + Down":"Håll Upp + Ned","Watch appearance":"Klockans utseende","Light":"Ljust","Dark":"Mörkt","Watch colours are independent of this phone page.":"Klockans utseende är oberoende av den här sidan.","Update Open Activity to change watch appearance.":"Uppdatera Open Activity för att ändra klockans utseende.","Watch appearance will update when Open Activity next opens.":"Utseendet uppdateras nästa gång Open Activity öppnas.","No changes to save.":"Inga ändringar att spara.","Unsaved changes.":"Osparade ändringar","Saving…":"Sparar…","✓ Saved":"✓ Sparat","Save":"Spara","Discard":"Kasta ändringar","Cancel":"Avbryt","Reload saved":"Läs in sparade","Retry loading":"Försök läsa in igen","Loading settings…":"Läser in inställningar…","Couldn’t save. Try again.":"Kunde inte spara. Försök igen.","Save not confirmed. Reload saved choices or save again.":"Sparandet inte bekräftat. Läs in sparade inställningar eller spara igen.","Review these choices and save to repair unreadable settings.":"Sparade inställningar kunde inte läsas. Granska valen innan du sparar.","Saved settings could not be read. Review these choices before saving.":"Sparade inställningar kunde inte läsas. Granska valen innan du sparar.","Save to use these two shortcuts.":"Spara för att använda dessa två genvägar.","Could not load settings. Retry, or reopen this page from Pebble.":"Kunde inte läsa in inställningar. Försök igen eller öppna sidan från Pebble.","Saved settings reloaded.":"Sparade inställningar inlästa igen.","Setup & help":"Inställning och hjälp","Watchface":"Urtavla","Open activities shown by this watchface. Change this choice when you switch watchfaces.":"Öppna aktiviteter från denna urtavla. Ändra valet när du byter urtavla.","Install the current build of your selected watchface.":"Installera aktuell version av vald urtavla.","Allow Open Activity to launch apps in the Pebble phone app.":"Tillåt Open Activity att starta appar i Pebble-appen på telefonen.","In Pebble’s Quick Launch settings, assign this same Open Activity app to each shortcut you want to use.":"Tilldela samma Open Activity-app till varje önskad genväg i Pebbles snabbstart.","Use one connected watch. This opens the selected watchface’s recent activity. It does not switch sources automatically.":"Använd en ansluten klocka. Den valda urtavlans senaste aktivitet öppnas. Källan växlas inte automatiskt.","A missing or expired activity returns to the watchface. It never substitutes Primary for a missing Secondary.":"Saknad eller utgången aktivitet återgår till urtavlan. Primär ersätter aldrig en saknad sekundär.","These choices apply when the shortcut is assigned to Open Activity. Other Quick Launch assignments stay as you set them.":"Valen gäller genvägar tilldelade Open Activity. Andra snabbstartstilldelningar behålls.","Open Activity from the watch’s app list stays open for setup. Open its settings in the Pebble phone app, then press Back on the watch when finished. Assigned Quick Launch shortcuts still open activities automatically.":"Från applistan förblir Open Activity öppen för inställning. Öppna inställningar i Pebble på telefonen och tryck Bakåt på klockan när du är klar. Tilldelade genvägar öppnar fortfarande aktiviteter automatiskt.","Back cancels while Opening… is shown. A launch already sent to the phone may still finish.":"Bakåt avbryter under Öppnar… En start som skickats till telefonen kan ändå slutföras.","This legacy settings route closes after Save. Reopen settings to check the saved choices.":"Denna äldre sida stängs efter Spara. Öppna inställningar igen för att kontrollera valen.","Activity":"Aktivitet","Opening...":"Öppnar…","Open settings in":"Öppna inställningar","the Pebble app.":"i Pebble-appen.","Quick Launch":"Snabbstart","opens activities.":"öppnar aktiviteter.","Text size":"Textstorlek","Follow Pebble":"Följ Pebble","Small":"Liten","Medium":"Mellan","Large":"Stor","Follow Pebble appearance is unavailable on this build. It uses your last Light or Dark choice.":"Pebbles utseende är inte tillgängligt i denna version. Ditt senaste val Ljust eller Mörkt används.","Applied on watch":"Tillämpat på klockan","Saved on phone · Pending on watch":"Sparat på telefonen · Väntar på klockan","Saved on phone · Watch could not confirm saving":"Sparat på telefonen · Klockan kunde inte bekräfta sparandet","Retry watch delivery":"Skicka till klockan igen","Follow Pebble uses your watch’s text size.":"Följ Pebble använder klockans textstorlek.","Launch Open Activity from your watch’s app list to apply display settings.":"Öppna Open Activity från klockans applista för att tillämpa skärminställningarna.","What is an activity?":"Vad är en aktivitet?","Activities are live updates shown by compatible XOCE apps and watchfaces, such as a countdown, music or a new notification.":"Aktiviteter är aktuella uppdateringar i kompatibla XOCE-appar och urtavlor, till exempel en nedräkning, musik eller en ny avisering.","Sharing activities between apps needs plugin support and a connected phone. Timer works on its own without sharing.":"Delning av aktiviteter mellan appar kräver pluginstöd och en ansluten telefon. Timer fungerar även självständigt utan delning.","Open Activity is an optional shortcut back to the app shown on Dynamic or Halftone. For example, use Quick Launch while a countdown is visible to open Timer. It opens the app, not a particular saved timer.":"Open Activity är en valfri genväg till appen som visas på Dynamic eller Halftone. Använd exempelvis Quick Launch när en nedräkning syns för att öppna Timer. Den öppnar appen, inte en viss sparad timer.","An activity is an update on Dynamic or Halftone, such as a Timer countdown.":"En aktivitet är en uppdatering på Dynamic eller Halftone, som en nedräkning från Timer.","Open settings in the Pebble phone app. Assign Open Activity to Quick Launch to open the app behind the activity on your chosen watchface.":"Öppna inställningarna i Pebble-appen på telefonen. Tilldela Open Activity till Quick Launch för att öppna appen bakom aktiviteten på din valda urtavla."},"no":{"Choose a shortcut for each activity.":"Velg en snarvei for hver aktivitet.","Activity shortcuts":"Aktivitetssnarveier","Primary activity":"Primær aktivitet","Secondary activity":"Sekundær aktivitet","Not assigned":"Ikke tilordnet","Loading saved choice…":"Laster lagret valg…","Not loaded":"Ikke lastet","Saved choice not loaded yet.":"Lagret valg er ikke lastet ennå.","No shortcut assigned.":"Ingen snarvei tilordnet.","Opens the smaller activity row.":"Åpner den mindre aktivitetsraden.","Opens the large activity.":"Åpner den store aktiviteten.","Choose a different shortcut for each activity.":"Velg ulike snarveier for aktivitetene.","Choose shortcuts, then assign Open Activity to them in Pebble’s Quick Launch settings.":"Velg snarveier og tilordne dem Open Activity i Pebbles hurtigstart.","Use a different shortcut for each activity before setting up Quick Launch.":"Velg ulike snarveier for aktivitetene.","No activity shortcut is enabled. Choose a shortcut above to open an activity.":"Ingen aktivitetssnarvei er aktiv. Velg en over for å åpne en aktivitet.","In Pebble’s Quick Launch settings, assign Open Activity to {shortcuts}.":"Tilordne Open Activity til {shortcuts} i Pebbles hurtigstart."," and ":" og ","Hold Up":"Hold øvre knapp","Hold Center":"Hold midtknappen","Hold Down":"Hold nedre knapp","Hold Back":"Hold Tilbake","Tap Up":"Trykk øvre knapp","Tap Down":"Trykk nedre knapp","Hold Back + Up":"Hold Tilbake + Opp","Hold Up + Down":"Hold Opp + Ned","Watch appearance":"Klokkens utseende","Light":"Lyst","Dark":"Mørkt","Watch colours are independent of this phone page.":"Klokkens utseende er uavhengig av denne telefonsiden.","Update Open Activity to change watch appearance.":"Oppdater Open Activity for å endre klokkens utseende.","Watch appearance will update when Open Activity next opens.":"Utseendet oppdateres neste gang Open Activity åpnes.","No changes to save.":"Ingen endringer å lagre.","Unsaved changes.":"Ulagrede endringer","Saving…":"Lagrer…","✓ Saved":"✓ Lagret","Save":"Lagre","Discard":"Forkast","Cancel":"Avbryt","Reload saved":"Last lagrede","Retry loading":"Prøv å laste igjen","Loading settings…":"Laster innstillinger…","Couldn’t save. Try again.":"Kunne ikke lagre. Prøv igjen.","Save not confirmed. Reload saved choices or save again.":"Lagring ikke bekreftet. Last inn lagrede innstillinger eller lagre igjen.","Review these choices and save to repair unreadable settings.":"Lagrede innstillinger kunne ikke leses. Sjekk valgene før lagring.","Saved settings could not be read. Review these choices before saving.":"Lagrede innstillinger kunne ikke leses. Sjekk valgene før lagring.","Save to use these two shortcuts.":"Lagre for å bruke disse to snarveiene.","Could not load settings. Retry, or reopen this page from Pebble.":"Kunne ikke laste innstillinger. Prøv igjen eller åpne siden på nytt fra Pebble.","Saved settings reloaded.":"Lagrede innstillinger lastet på nytt.","Setup & help":"Oppsett og hjelp","Watchface":"Urskive","Open activities shown by this watchface. Change this choice when you switch watchfaces.":"Åpne aktiviteter fra denne urskiven. Endre valget når du bytter urskive.","Install the current build of your selected watchface.":"Installer gjeldende versjon av valgt urskive.","Allow Open Activity to launch apps in the Pebble phone app.":"Tillat Open Activity å starte apper i Pebble-appen på telefonen.","In Pebble’s Quick Launch settings, assign this same Open Activity app to each shortcut you want to use.":"Tilordne samme Open Activity-app til hver ønsket snarvei i Pebbles hurtigstart.","Use one connected watch. This opens the selected watchface’s recent activity. It does not switch sources automatically.":"Bruk én tilkoblet klokke. Den valgte urskivens siste aktivitet åpnes. Kilden byttes ikke automatisk.","A missing or expired activity returns to the watchface. It never substitutes Primary for a missing Secondary.":"Manglende eller utløpt aktivitet går tilbake til urskiven. Primær erstatter aldri en manglende sekundær.","These choices apply when the shortcut is assigned to Open Activity. Other Quick Launch assignments stay as you set them.":"Valgene gjelder snarveier tilordnet Open Activity. Andre hurtigstarttilordninger beholdes.","Open Activity from the watch’s app list stays open for setup. Open its settings in the Pebble phone app, then press Back on the watch when finished. Assigned Quick Launch shortcuts still open activities automatically.":"Fra applisten forblir Open Activity åpen for oppsett. Åpne innstillinger i Pebble på telefonen og trykk Tilbake på klokken etterpå. Tilordnede snarveier åpner fortsatt aktiviteter automatisk.","Back cancels while Opening… is shown. A launch already sent to the phone may still finish.":"Tilbake avbryter under Åpner… En start sendt til telefonen kan fortsatt fullføres.","This legacy settings route closes after Save. Reopen settings to check the saved choices.":"Denne eldre siden lukkes etter Lagre. Åpne innstillingene igjen for å sjekke valgene.","Activity":"Aktivitet","Opening...":"Åpner…","Open settings in":"Åpne innstillinger","the Pebble app.":"i Pebble-appen.","Quick Launch":"Hurtigstart","opens activities.":"åpner aktiviteter.","Text size":"Tekststørrelse","Follow Pebble":"Følg Pebble","Small":"Liten","Medium":"Middels","Large":"Stor","Follow Pebble appearance is unavailable on this build. It uses your last Light or Dark choice.":"Pebbles utseende er ikke tilgjengelig i denne versjonen. Ditt siste valg Lyst eller Mørkt brukes.","Applied on watch":"Brukt på klokken","Saved on phone · Pending on watch":"Lagret på telefonen · Venter på klokken","Saved on phone · Watch could not confirm saving":"Lagret på telefonen · Klokken kunne ikke bekrefte lagringen","Retry watch delivery":"Send til klokken igjen","Follow Pebble uses your watch’s text size.":"Følg Pebble bruker klokkens tekststørrelse.","Launch Open Activity from your watch’s app list to apply display settings.":"Åpne Open Activity fra klokkens appliste for å bruke skjerminnstillingene.","What is an activity?":"Hva er en aktivitet?","Activities are live updates shown by compatible XOCE apps and watchfaces, such as a countdown, music or a new notification.":"Aktiviteter er aktuelle oppdateringer i kompatible XOCE-apper og urskiver, som en nedtelling, musikk eller et nytt varsel.","Sharing activities between apps needs plugin support and a connected phone. Timer works on its own without sharing.":"Deling av aktiviteter mellom apper krever pluginstøtte og en tilkoblet telefon. Timer fungerer også alene uten deling.","Open Activity is an optional shortcut back to the app shown on Dynamic or Halftone. For example, use Quick Launch while a countdown is visible to open Timer. It opens the app, not a particular saved timer.":"Open Activity er en valgfri snarvei til appen som vises på Dynamic eller Halftone. Bruk for eksempel Quick Launch når en nedtelling vises for å åpne Timer. Den åpner appen, ikke en bestemt lagret timer.","An activity is an update on Dynamic or Halftone, such as a Timer countdown.":"En aktivitet er en oppdatering på Dynamic eller Halftone, som en nedtelling fra Timer.","Open settings in the Pebble phone app. Assign Open Activity to Quick Launch to open the app behind the activity on your chosen watchface.":"Åpne innstillingene i Pebble-appen på telefonen. Tilordne Open Activity til Quick Launch for å åpne appen bak aktiviteten på den valgte urskiven."},"fi":{"Choose a shortcut for each activity.":"Valitse pikavalinta kullekin toiminnolle.","Activity shortcuts":"Toimintojen pikavalinnat","Primary activity":"Ensisijainen toiminto","Secondary activity":"Toissijainen toiminto","Not assigned":"Ei määritetty","Loading saved choice…":"Ladataan tallennettua valintaa…","Not loaded":"Ei ladattu","Saved choice not loaded yet.":"Tallennettua valintaa ei ole vielä ladattu.","No shortcut assigned.":"Ei määritettyä pikavalintaa.","Opens the smaller activity row.":"Avaa pienemmän toimintorivin.","Opens the large activity.":"Avaa suuren toiminnon.","Choose a different shortcut for each activity.":"Valitse eri pikavalinta jokaiselle toiminnolle.","Choose shortcuts, then assign Open Activity to them in Pebble’s Quick Launch settings.":"Valitse pikavalinnat ja määritä niihin Open Activity Pebblen pikakäynnistyksessä.","Use a different shortcut for each activity before setting up Quick Launch.":"Valitse eri pikavalinta jokaiselle toiminnolle.","No activity shortcut is enabled. Choose a shortcut above to open an activity.":"Toiminnon pikavalintaa ei ole käytössä. Valitse yllä pikavalinta avataksesi toiminnon.","In Pebble’s Quick Launch settings, assign Open Activity to {shortcuts}.":"Määritä Open Activity pikavalintoihin {shortcuts} Pebblen pikakäynnistyksessä."," and ":" ja ","Hold Up":"Pidä yläpainiketta","Hold Center":"Pidä keskipainiketta","Hold Down":"Pidä alapainiketta","Hold Back":"Pidä takaisinpainiketta","Tap Up":"Paina yläpainiketta","Tap Down":"Paina alapainiketta","Hold Back + Up":"Pidä Takaisin + Ylös","Hold Up + Down":"Pidä Ylös + Alas","Watch appearance":"Kellon ulkoasu","Light":"Vaalea","Dark":"Tumma","Watch colours are independent of this phone page.":"Kellon ulkoasu on riippumaton tästä puhelinsivusta.","Update Open Activity to change watch appearance.":"Päivitä Open Activity muuttaaksesi kellon ulkoasua.","Watch appearance will update when Open Activity next opens.":"Ulkoasu päivittyy, kun Open Activity avataan seuraavan kerran.","No changes to save.":"Ei tallennettavia muutoksia.","Unsaved changes.":"Tallentamattomia muutoksia","Saving…":"Tallennetaan…","✓ Saved":"✓ Tallennettu","Save":"Tallenna","Discard":"Hylkää","Cancel":"Peruuta","Reload saved":"Lataa tallennetut","Retry loading":"Yritä ladata uudelleen","Loading settings…":"Ladataan asetuksia…","Couldn’t save. Try again.":"Tallennus epäonnistui. Yritä uudelleen.","Save not confirmed. Reload saved choices or save again.":"Tallennusta ei vahvistettu. Lataa tallennetut asetukset tai tallenna uudelleen.","Review these choices and save to repair unreadable settings.":"Tallennettuja asetuksia ei voitu lukea. Tarkista valinnat ennen tallennusta.","Saved settings could not be read. Review these choices before saving.":"Tallennettuja asetuksia ei voitu lukea. Tarkista valinnat ennen tallennusta.","Save to use these two shortcuts.":"Tallenna käyttääksesi näitä kahta pikavalintaa.","Could not load settings. Retry, or reopen this page from Pebble.":"Asetuksia ei voitu ladata. Yritä uudelleen tai avaa sivu Pebblestä.","Saved settings reloaded.":"Tallennetut asetukset ladattu uudelleen.","Setup & help":"Asetukset ja ohje","Watchface":"Kellotaulu","Open activities shown by this watchface. Change this choice when you switch watchfaces.":"Avaa tämän kellotaulun toiminnot. Muuta valintaa vaihtaessasi kellotaulua.","Install the current build of your selected watchface.":"Asenna valitun kellotaulun nykyinen versio.","Allow Open Activity to launch apps in the Pebble phone app.":"Salli Open Activityn avata sovelluksia puhelimen Pebble-sovelluksessa.","In Pebble’s Quick Launch settings, assign this same Open Activity app to each shortcut you want to use.":"Määritä sama Open Activity jokaiseen haluamaasi pikavalintaan Pebblen pikakäynnistyksessä.","Use one connected watch. This opens the selected watchface’s recent activity. It does not switch sources automatically.":"Käytä yhtä yhdistettyä kelloa. Valitun kellotaulun viimeisin toiminto avautuu. Lähde ei vaihdu automaattisesti.","A missing or expired activity returns to the watchface. It never substitutes Primary for a missing Secondary.":"Puuttuva tai vanhentunut toiminto palaa kellotauluun. Ensisijainen ei koskaan korvaa puuttuvaa toissijaista.","These choices apply when the shortcut is assigned to Open Activity. Other Quick Launch assignments stay as you set them.":"Valinnat koskevat Open Activitylle määritettyjä pikavalintoja. Muut pikakäynnistysmääritykset säilyvät.","Open Activity from the watch’s app list stays open for setup. Open its settings in the Pebble phone app, then press Back on the watch when finished. Assigned Quick Launch shortcuts still open activities automatically.":"Sovelluslistasta Open Activity jää auki asetuksia varten. Avaa asetukset puhelimen Pebblessä ja paina lopuksi Takaisin kellossa. Määritetyt pikavalinnat avaavat edelleen toiminnot automaattisesti.","Back cancels while Opening… is shown. A launch already sent to the phone may still finish.":"Takaisin peruuttaa Avataan…-tilassa. Puhelimeen jo lähetetty käynnistys voi silti valmistua.","This legacy settings route closes after Save. Reopen settings to check the saved choices.":"Tämä vanha asetussivu sulkeutuu tallennuksen jälkeen. Avaa asetukset uudelleen tarkistaaksesi valinnat.","Activity":"Toiminto","Opening...":"Avataan…","Open settings in":"Avaa asetukset","the Pebble app.":"Pebble-sovelluksessa.","Quick Launch":"Pikakäynnistys","opens activities.":"avaa toimintoja.","Text size":"Tekstin koko","Follow Pebble":"Seuraa Pebbleä","Small":"Pieni","Medium":"Keskikokoinen","Large":"Suuri","Follow Pebble appearance is unavailable on this build. It uses your last Light or Dark choice.":"Pebblen ulkoasu ei ole käytettävissä tässä versiossa. Käytetään viimeisintä Vaalea- tai Tumma-valintaa.","Applied on watch":"Käytössä kellossa","Saved on phone · Pending on watch":"Tallennettu puhelimeen · Odottaa kelloa","Saved on phone · Watch could not confirm saving":"Tallennettu puhelimeen · Kello ei vahvistanut tallennusta","Retry watch delivery":"Lähetä kelloon uudelleen","Follow Pebble uses your watch’s text size.":"Seuraa Pebbleä käyttää kellon tekstikokoa.","Launch Open Activity from your watch’s app list to apply display settings.":"Avaa Open Activity kellon sovellusluettelosta ottaaksesi näyttöasetukset käyttöön.","What is an activity?":"Mikä on toiminto?","Activities are live updates shown by compatible XOCE apps and watchfaces, such as a countdown, music or a new notification.":"Toiminnot ovat yhteensopivien XOCE-sovellusten ja kellotaulujen näyttämiä ajankohtaisia tietoja, kuten ajastus, musiikki tai uusi ilmoitus.","Sharing activities between apps needs plugin support and a connected phone. Timer works on its own without sharing.":"Toimintojen jakaminen sovellusten välillä vaatii lisäosatuen ja yhteyden puhelimeen. Timer toimii myös itsenäisesti ilman jakamista.","Open Activity is an optional shortcut back to the app shown on Dynamic or Halftone. For example, use Quick Launch while a countdown is visible to open Timer. It opens the app, not a particular saved timer.":"Open Activity on valinnainen oikotie Dynamic- tai Halftone-kellotaulun näyttämään sovellukseen. Avaa esimerkiksi Timer Quick Launchilla ajastuksen näkyessä. Se avaa sovelluksen, ei tiettyä tallennettua ajastinta.","An activity is an update on Dynamic or Halftone, such as a Timer countdown.":"Toiminto on Dynamic- tai Halftone-kellotaulun päivitys, kuten Timer-ajastus.","Open settings in the Pebble phone app. Assign Open Activity to Quick Launch to open the app behind the activity on your chosen watchface.":"Avaa asetukset puhelimen Pebble-sovelluksessa. Määritä Open Activity Quick Launchiin avataksesi valitun kellotaulun toiminnon taustalla olevan sovelluksen."},"hu":{"Choose a shortcut for each activity.":"Válassz gyorsgombot minden tevékenységhez.","Activity shortcuts":"Tevékenység-gyorsgombok","Primary activity":"Elsődleges tevékenység","Secondary activity":"Másodlagos tevékenység","Not assigned":"Nincs hozzárendelve","Loading saved choice…":"Mentett választás betöltése…","Not loaded":"Nincs betöltve","Saved choice not loaded yet.":"A mentett választás még nincs betöltve.","No shortcut assigned.":"Nincs hozzárendelt gyorsgomb.","Opens the smaller activity row.":"A kisebb tevékenységsort nyitja meg.","Opens the large activity.":"A nagy tevékenységet nyitja meg.","Choose a different shortcut for each activity.":"Minden tevékenységhez más gyorsgombot válassz.","Choose shortcuts, then assign Open Activity to them in Pebble’s Quick Launch settings.":"Válassz gyorsgombokat és rendeld hozzájuk az Open Activityt a Pebble gyorsindításában.","Use a different shortcut for each activity before setting up Quick Launch.":"Minden tevékenységhez más gyorsgombot válassz.","No activity shortcut is enabled. Choose a shortcut above to open an activity.":"Nincs aktív gyorsgomb. Válassz egyet fent a tevékenység megnyitásához.","In Pebble’s Quick Launch settings, assign Open Activity to {shortcuts}.":"A Pebble gyorsindításában rendeld az Open Activityt ezekhez: {shortcuts}."," and ":" és ","Hold Up":"Felső gomb nyomva","Hold Center":"Középső gomb nyomva","Hold Down":"Alsó gomb nyomva","Hold Back":"Vissza gomb nyomva","Tap Up":"Felső gomb megnyomása","Tap Down":"Alsó gomb megnyomása","Hold Back + Up":"Vissza + Fel nyomva","Hold Up + Down":"Fel + Le nyomva","Watch appearance":"Óra megjelenése","Light":"Világos","Dark":"Sötét","Watch colours are independent of this phone page.":"Az óra megjelenése független ettől a telefonos oldaltól.","Update Open Activity to change watch appearance.":"Frissítsd az Open Activityt az óra megjelenésének módosításához.","Watch appearance will update when Open Activity next opens.":"A megjelenés az Open Activity következő megnyitásakor frissül.","No changes to save.":"Nincs mentendő módosítás.","Unsaved changes.":"Nem mentett módosítások","Saving…":"Mentés…","✓ Saved":"✓ Mentve","Save":"Mentés","Discard":"Elvetés","Cancel":"Mégse","Reload saved":"Mentettek betöltése","Retry loading":"Betöltés újra","Loading settings…":"Beállítások betöltése…","Couldn’t save. Try again.":"Nem sikerült menteni. Próbálja újra.","Save not confirmed. Reload saved choices or save again.":"A mentés nincs megerősítve. Töltsd újra a mentett beállításokat vagy ments újra.","Review these choices and save to repair unreadable settings.":"A mentett beállítások nem olvashatók. Mentés előtt ellenőrizd a választásokat.","Saved settings could not be read. Review these choices before saving.":"A mentett beállítások nem olvashatók. Mentés előtt ellenőrizd a választásokat.","Save to use these two shortcuts.":"Ments a két gyorsgomb használatához.","Could not load settings. Retry, or reopen this page from Pebble.":"Nem sikerült betölteni a beállításokat. Próbáld újra vagy nyisd meg az oldalt a Pebble-ből.","Saved settings reloaded.":"Mentett beállítások újratöltve.","Setup & help":"Beállítás és súgó","Watchface":"Számlap","Open activities shown by this watchface. Change this choice when you switch watchfaces.":"Ennek a számlapnak a tevékenységeit nyitja meg. Számlapváltáskor módosítsd ezt.","Install the current build of your selected watchface.":"Telepítsd a kiválasztott számlap aktuális verzióját.","Allow Open Activity to launch apps in the Pebble phone app.":"Engedélyezd az alkalmazásindítást az Open Activitynek a telefon Pebble alkalmazásában.","In Pebble’s Quick Launch settings, assign this same Open Activity app to each shortcut you want to use.":"Ugyanazt az Open Activity alkalmazást rendeld minden kívánt gyorsgombhoz a Pebble gyorsindításában.","Use one connected watch. This opens the selected watchface’s recent activity. It does not switch sources automatically.":"Egy csatlakoztatott órát használj. A választott számlap legutóbbi tevékenységét nyitja meg. A forrás nem vált automatikusan.","A missing or expired activity returns to the watchface. It never substitutes Primary for a missing Secondary.":"Hiányzó vagy lejárt tevékenység visszatér a számlapra. Az elsődleges soha nem helyettesíti a hiányzó másodlagost.","These choices apply when the shortcut is assigned to Open Activity. Other Quick Launch assignments stay as you set them.":"Ezek a választások az Open Activityhez rendelt gyorsgombokra érvényesek. A többi hozzárendelés változatlan.","Open Activity from the watch’s app list stays open for setup. Open its settings in the Pebble phone app, then press Back on the watch when finished. Assigned Quick Launch shortcuts still open activities automatically.":"Az alkalmazáslistából indított Open Activity nyitva marad beállításhoz. Nyisd meg a beállításait a telefon Pebble alkalmazásában, majd nyomd meg a Vissza gombot az órán. A hozzárendelt gyorsgombok továbbra is automatikusan nyitják a tevékenységeket.","Back cancels while Opening… is shown. A launch already sent to the phone may still finish.":"A Vissza megszakítja a Megnyitás… állapotot. A telefonra már elküldött indítás még befejeződhet.","This legacy settings route closes after Save. Reopen settings to check the saved choices.":"Ez a régi beállítási oldal mentés után bezárul. A választások ellenőrzéséhez nyisd meg újra.","Activity":"Tevékenység","Opening...":"Megnyitás…","Open settings in":"Nyisd a beállítást","the Pebble app.":"a Pebble appban.","Quick Launch":"Gyorsindítás","opens activities.":"tevékenységet nyit.","Text size":"Szövegméret","Follow Pebble":"Pebble követése","Small":"Kicsi","Medium":"Közepes","Large":"Nagy","Follow Pebble appearance is unavailable on this build. It uses your last Light or Dark choice.":"A Pebble megjelenése ebben a verzióban nem érhető el. Az utolsó Világos vagy Sötét választás érvényes.","Applied on watch":"Alkalmazva az órán","Saved on phone · Pending on watch":"Mentve a telefonon · Várakozás az órára","Saved on phone · Watch could not confirm saving":"Mentve a telefonon · Az óra nem igazolta vissza a mentést","Retry watch delivery":"Újraküldés az órára","Follow Pebble uses your watch’s text size.":"A Pebble követése az óra szövegméretét használja.","Launch Open Activity from your watch’s app list to apply display settings.":"A kijelzőbeállítások alkalmazásához nyisd meg az Open Activity alkalmazást az óra alkalmazáslistájából.","What is an activity?":"Mi az a tevékenység?","Activities are live updates shown by compatible XOCE apps and watchfaces, such as a countdown, music or a new notification.":"A tevékenységek a kompatibilis XOCE-alkalmazásokban és számlapokon megjelenő aktuális információk, például visszaszámlálás, zene vagy új értesítés.","Sharing activities between apps needs plugin support and a connected phone. Timer works on its own without sharing.":"A tevékenységek alkalmazások közötti megosztásához bővítménytámogatás és csatlakoztatott telefon kell. A Timer megosztás nélkül is önállóan működik.","Open Activity is an optional shortcut back to the app shown on Dynamic or Halftone. For example, use Quick Launch while a countdown is visible to open Timer. It opens the app, not a particular saved timer.":"Az Open Activity választható gyorsparancs a Dynamic vagy Halftone számlapon látható alkalmazáshoz. Látható visszaszámlálásnál a Quick Launch megnyithatja a Timert. Az alkalmazást nyitja meg, nem egy adott mentett időzítőt.","An activity is an update on Dynamic or Halftone, such as a Timer countdown.":"A tevékenység egy frissítés a Dynamic vagy Halftone számlapon, például a Timer visszaszámlálása.","Open settings in the Pebble phone app. Assign Open Activity to Quick Launch to open the app behind the activity on your chosen watchface.":"Nyisd meg a beállításokat a telefon Pebble alkalmazásában. Rendeld az Open Activityt a Quick Launchhoz, hogy megnyithasd a választott számlap tevékenységéhez tartozó alkalmazást."},"ro":{"Choose a shortcut for each activity.":"Alege o scurtătură pentru fiecare activitate.","Activity shortcuts":"Scurtături activități","Primary activity":"Activitate principală","Secondary activity":"Activitate secundară","Not assigned":"Neatribuit","Loading saved choice…":"Se încarcă alegerea salvată…","Not loaded":"Neîncărcat","Saved choice not loaded yet.":"Alegerea salvată nu e încă încărcată.","No shortcut assigned.":"Nicio scurtătură atribuită.","Opens the smaller activity row.":"Deschide rândul mic de activitate.","Opens the large activity.":"Deschide activitatea mare.","Choose a different shortcut for each activity.":"Alege scurtături diferite pentru activități.","Choose shortcuts, then assign Open Activity to them in Pebble’s Quick Launch settings.":"Alege scurtături și atribuie-le Open Activity în lansarea rapidă Pebble.","Use a different shortcut for each activity before setting up Quick Launch.":"Alege scurtături diferite pentru activități.","No activity shortcut is enabled. Choose a shortcut above to open an activity.":"Nicio scurtătură activă. Alege una mai sus pentru a deschide o activitate.","In Pebble’s Quick Launch settings, assign Open Activity to {shortcuts}.":"În lansarea rapidă Pebble, atribuie Open Activity la {shortcuts}."," and ":" și ","Hold Up":"Ține butonul de sus","Hold Center":"Ține butonul din mijloc","Hold Down":"Ține butonul de jos","Hold Back":"Ține Înapoi","Tap Up":"Apasă sus","Tap Down":"Apasă jos","Hold Back + Up":"Ține Înapoi + Sus","Hold Up + Down":"Ține Sus + Jos","Watch appearance":"Aspectul ceasului","Light":"Luminoasă","Dark":"Întunecată","Watch colours are independent of this phone page.":"Aspectul ceasului este independent de această pagină.","Update Open Activity to change watch appearance.":"Actualizează Open Activity pentru a schimba aspectul ceasului.","Watch appearance will update when Open Activity next opens.":"Aspectul se actualizează la următoarea deschidere Open Activity.","No changes to save.":"Nu sunt modificări de salvat.","Unsaved changes.":"Modificări nesalvate","Saving…":"Se salvează…","✓ Saved":"✓ Salvat","Save":"Salvați","Discard":"Renunțați","Cancel":"Anulează","Reload saved":"Reîncărcați salvate","Retry loading":"Reîncearcă încărcarea","Loading settings…":"Se încarcă setările…","Couldn’t save. Try again.":"Salvarea a eșuat. Încercați din nou.","Save not confirmed. Reload saved choices or save again.":"Salvare neconfirmată. Reîncarcă setările salvate sau salvează din nou.","Review these choices and save to repair unreadable settings.":"Setările salvate nu au putut fi citite. Verifică alegerile înainte de salvare.","Saved settings could not be read. Review these choices before saving.":"Setările salvate nu au putut fi citite. Verifică alegerile înainte de salvare.","Save to use these two shortcuts.":"Salvează pentru a folosi aceste două scurtături.","Could not load settings. Retry, or reopen this page from Pebble.":"Setările nu au putut fi încărcate. Reîncearcă sau redeschide pagina din Pebble.","Saved settings reloaded.":"Setările salvate au fost reîncărcate.","Setup & help":"Configurare și ajutor","Watchface":"Cadran","Open activities shown by this watchface. Change this choice when you switch watchfaces.":"Deschide activitățile acestui cadran. Schimbă alegerea când schimbi cadranul.","Install the current build of your selected watchface.":"Instalează versiunea actuală a cadranului ales.","Allow Open Activity to launch apps in the Pebble phone app.":"Permite Open Activity să pornească aplicații în aplicația Pebble de pe telefon.","In Pebble’s Quick Launch settings, assign this same Open Activity app to each shortcut you want to use.":"Atribuie aceeași aplicație Open Activity fiecărei scurtături dorite în lansarea rapidă Pebble.","Use one connected watch. This opens the selected watchface’s recent activity. It does not switch sources automatically.":"Folosește un singur ceas conectat. Deschide activitatea recentă a cadranului ales. Sursa nu se schimbă automat.","A missing or expired activity returns to the watchface. It never substitutes Primary for a missing Secondary.":"O activitate lipsă sau expirată revine la cadran. Principala nu înlocuiește niciodată o secundară lipsă.","These choices apply when the shortcut is assigned to Open Activity. Other Quick Launch assignments stay as you set them.":"Alegerile se aplică scurtăturilor atribuite Open Activity. Celelalte atribuiri rămân neschimbate.","Open Activity from the watch’s app list stays open for setup. Open its settings in the Pebble phone app, then press Back on the watch when finished. Assigned Quick Launch shortcuts still open activities automatically.":"Din lista de aplicații, Open Activity rămâne deschisă pentru configurare. Deschide setările în Pebble pe telefon, apoi apasă Înapoi pe ceas. Scurtăturile atribuite continuă să deschidă activități automat.","Back cancels while Opening… is shown. A launch already sent to the phone may still finish.":"Înapoi anulează în timpul Se deschide… O lansare deja trimisă telefonului se poate finaliza.","This legacy settings route closes after Save. Reopen settings to check the saved choices.":"Această pagină veche se închide după salvare. Redeschide setările pentru a verifica alegerile.","Activity":"Activitate","Opening...":"Se deschide…","Open settings in":"Deschide setările","the Pebble app.":"în aplicația Pebble.","Quick Launch":"Lansare rapidă","opens activities.":"deschide activități.","Text size":"Mărimea textului","Follow Pebble":"Urmează Pebble","Small":"Mic","Medium":"Mediu","Large":"Mare","Follow Pebble appearance is unavailable on this build. It uses your last Light or Dark choice.":"Aspectul Pebble nu este disponibil în această versiune. Se folosește ultima alegere Luminos sau Întunecat.","Applied on watch":"Aplicat pe ceas","Saved on phone · Pending on watch":"Salvat pe telefon · În așteptare pe ceas","Saved on phone · Watch could not confirm saving":"Salvat pe telefon · Ceasul nu a confirmat salvarea","Retry watch delivery":"Retrimite la ceas","Follow Pebble uses your watch’s text size.":"Urmează Pebble folosește mărimea textului de pe ceas.","Launch Open Activity from your watch’s app list to apply display settings.":"Deschide Open Activity din lista de aplicații a ceasului pentru a aplica setările ecranului.","What is an activity?":"Ce este o activitate?","Activities are live updates shown by compatible XOCE apps and watchfaces, such as a countdown, music or a new notification.":"Activitățile sunt informații curente afișate de aplicațiile și cadranele XOCE compatibile, precum o numărătoare inversă, muzică sau o notificare nouă.","Sharing activities between apps needs plugin support and a connected phone. Timer works on its own without sharing.":"Partajarea activităților între aplicații necesită suport pentru pluginuri și un telefon conectat. Timer funcționează și independent, fără partajare.","Open Activity is an optional shortcut back to the app shown on Dynamic or Halftone. For example, use Quick Launch while a countdown is visible to open Timer. It opens the app, not a particular saved timer.":"Open Activity este o scurtătură opțională către aplicația afișată pe Dynamic sau Halftone. Folosește Quick Launch când vezi o numărătoare pentru a deschide Timer. Deschide aplicația, nu un temporizator salvat anume.","An activity is an update on Dynamic or Halftone, such as a Timer countdown.":"O activitate este o informație pe Dynamic sau Halftone, cum ar fi o numărătoare Timer.","Open settings in the Pebble phone app. Assign Open Activity to Quick Launch to open the app behind the activity on your chosen watchface.":"Deschide setările în aplicația Pebble de pe telefon. Atribuie Open Activity la Quick Launch pentru a deschide aplicația activității de pe cadranul ales."},"tr":{"Choose a shortcut for each activity.":"Her etkinlik için kısayol seç.","Activity shortcuts":"Etkinlik kısayolları","Primary activity":"Birincil etkinlik","Secondary activity":"İkincil etkinlik","Not assigned":"Atanmadı","Loading saved choice…":"Kayıtlı seçim yükleniyor…","Not loaded":"Yüklenmedi","Saved choice not loaded yet.":"Kayıtlı seçim henüz yüklenmedi.","No shortcut assigned.":"Kısayol atanmadı.","Opens the smaller activity row.":"Küçük etkinlik satırını açar.","Opens the large activity.":"Büyük etkinliği açar.","Choose a different shortcut for each activity.":"Her etkinlik için farklı kısayol seç.","Choose shortcuts, then assign Open Activity to them in Pebble’s Quick Launch settings.":"Kısayolları seç ve Pebble Hızlı Başlat ayarlarında onlara Open Activity’yi ata.","Use a different shortcut for each activity before setting up Quick Launch.":"Her etkinlik için farklı kısayol seç.","No activity shortcut is enabled. Choose a shortcut above to open an activity.":"Etkinlik kısayolu etkin değil. Etkinlik açmak için yukarıdan seç.","In Pebble’s Quick Launch settings, assign Open Activity to {shortcuts}.":"Pebble Hızlı Başlat ayarlarında Open Activity’yi {shortcuts} için ata."," and ":" ve ","Hold Up":"Üst düğmeyi basılı tut","Hold Center":"Orta düğmeyi basılı tut","Hold Down":"Alt düğmeyi basılı tut","Hold Back":"Geri düğmesini basılı tut","Tap Up":"Üst düğmeye bas","Tap Down":"Alt düğmeye bas","Hold Back + Up":"Geri + Yukarı basılı tut","Hold Up + Down":"Yukarı + Aşağı basılı tut","Watch appearance":"Saat görünümü","Light":"Açık","Dark":"Koyu","Watch colours are independent of this phone page.":"Saatin görünümü bu telefon sayfasından bağımsızdır.","Update Open Activity to change watch appearance.":"Saat görünümünü değiştirmek için Open Activity’yi güncelle.","Watch appearance will update when Open Activity next opens.":"Görünüm Open Activity bir sonraki açıldığında güncellenir.","No changes to save.":"Kaydedilecek değişiklik yok.","Unsaved changes.":"Kaydedilmemiş değişiklikler","Saving…":"Kaydediliyor…","✓ Saved":"✓ Kaydedildi","Save":"Kaydet","Discard":"Vazgeç","Cancel":"İptal","Reload saved":"Kayıtlı ayarları yükle","Retry loading":"Yüklemeyi yeniden dene","Loading settings…":"Ayarlar yükleniyor…","Couldn’t save. Try again.":"Kaydedilemedi. Tekrar deneyin.","Save not confirmed. Reload saved choices or save again.":"Kayıt doğrulanmadı. Kayıtlı ayarları yeniden yükle veya tekrar kaydet.","Review these choices and save to repair unreadable settings.":"Kayıtlı ayarlar okunamadı. Kaydetmeden önce seçimleri kontrol et.","Saved settings could not be read. Review these choices before saving.":"Kayıtlı ayarlar okunamadı. Kaydetmeden önce seçimleri kontrol et.","Save to use these two shortcuts.":"Bu iki kısayolu kullanmak için kaydet.","Could not load settings. Retry, or reopen this page from Pebble.":"Ayarlar yüklenemedi. Tekrar dene veya sayfayı Pebble’dan yeniden aç.","Saved settings reloaded.":"Kayıtlı ayarlar yeniden yüklendi.","Setup & help":"Kurulum ve yardım","Watchface":"Saat yüzü","Open activities shown by this watchface. Change this choice when you switch watchfaces.":"Bu saat yüzünün etkinliklerini aç. Saat yüzünü değiştirince bu seçimi de değiştir.","Install the current build of your selected watchface.":"Seçtiğin saat yüzünün güncel derlemesini yükle.","Allow Open Activity to launch apps in the Pebble phone app.":"Telefonun Pebble uygulamasında Open Activity’ye uygulama başlatma izni ver.","In Pebble’s Quick Launch settings, assign this same Open Activity app to each shortcut you want to use.":"Pebble Hızlı Başlat ayarlarında istediğin her kısayola aynı Open Activity uygulamasını ata.","Use one connected watch. This opens the selected watchface’s recent activity. It does not switch sources automatically.":"Tek bağlı saat kullan. Seçili saat yüzünün son etkinliği açılır. Kaynak otomatik değişmez.","A missing or expired activity returns to the watchface. It never substitutes Primary for a missing Secondary.":"Eksik veya süresi dolmuş etkinlik saat yüzüne döner. Eksik ikincil etkinliğin yerine birincil açılmaz.","These choices apply when the shortcut is assigned to Open Activity. Other Quick Launch assignments stay as you set them.":"Bu seçimler Open Activity’ye atanmış kısayollar için geçerlidir. Diğer Hızlı Başlat atamaları değişmez.","Open Activity from the watch’s app list stays open for setup. Open its settings in the Pebble phone app, then press Back on the watch when finished. Assigned Quick Launch shortcuts still open activities automatically.":"Uygulama listesinden açılan Open Activity ayarlar için açık kalır. Telefonda Pebble’dan ayarlarını aç, bitince saatte Geri’ye bas. Atanmış kısayollar etkinlikleri otomatik açmaya devam eder.","Back cancels while Opening… is shown. A launch already sent to the phone may still finish.":"Açılıyor… sırasında Geri iptal eder. Telefona gönderilmiş bir başlatma yine tamamlanabilir.","This legacy settings route closes after Save. Reopen settings to check the saved choices.":"Bu eski ayar sayfası kaydedince kapanır. Seçimleri kontrol etmek için ayarları yeniden aç.","Activity":"Etkinlik","Opening...":"Açılıyor…","Open settings in":"Ayarları aç","the Pebble app.":"Pebble uygulamasında.","Quick Launch":"Hızlı Başlat","opens activities.":"etkinlikleri açar.","Text size":"Metin boyutu","Follow Pebble":"Pebble’ı izle","Small":"Küçük","Medium":"Orta","Large":"Büyük","Follow Pebble appearance is unavailable on this build. It uses your last Light or Dark choice.":"Pebble görünümü bu sürümde kullanılamıyor. Son Açık veya Koyu seçiminiz kullanılır.","Applied on watch":"Saatte uygulandı","Saved on phone · Pending on watch":"Telefona kaydedildi · Saat bekleniyor","Saved on phone · Watch could not confirm saving":"Telefona kaydedildi · Saat kaydetmeyi onaylamadı","Retry watch delivery":"Saate yeniden gönder","Follow Pebble uses your watch’s text size.":"Pebble’ı izle, saatinizin metin boyutunu kullanır.","Launch Open Activity from your watch’s app list to apply display settings.":"Ekran ayarlarını uygulamak için saatinizin uygulama listesinden Open Activity’yi açın.","What is an activity?":"Etkinlik nedir?","Activities are live updates shown by compatible XOCE apps and watchfaces, such as a countdown, music or a new notification.":"Etkinlikler, uyumlu XOCE uygulama ve saat yüzlerinde gösterilen geri sayım, müzik veya yeni bildirim gibi güncel bilgilerdir.","Sharing activities between apps needs plugin support and a connected phone. Timer works on its own without sharing.":"Uygulamalar arasında etkinlik paylaşımı için eklenti desteği ve bağlı bir telefon gerekir. Timer paylaşım olmadan da bağımsız çalışır.","Open Activity is an optional shortcut back to the app shown on Dynamic or Halftone. For example, use Quick Launch while a countdown is visible to open Timer. It opens the app, not a particular saved timer.":"Open Activity, Dynamic veya Halftone’da gösterilen uygulamaya dönmek için isteğe bağlı bir kısayoldur. Örneğin geri sayım görünürken Quick Launch ile Timer’ı açın. Belirli bir kayıtlı zamanlayıcıyı değil, uygulamayı açar.","An activity is an update on Dynamic or Halftone, such as a Timer countdown.":"Etkinlik, Dynamic veya Halftone’daki Timer geri sayımı gibi bir güncellemedir.","Open settings in the Pebble phone app. Assign Open Activity to Quick Launch to open the app behind the activity on your chosen watchface.":"Telefondaki Pebble uygulamasında ayarları açın. Seçilen saat yüzündeki etkinliğin uygulamasını açmak için Open Activity’yi Quick Launch’a atayın."}},"nativeWords":{"cs":{"Open settings in":"Nastavení v","the Pebble app.":"aplikaci Pebble."},"sk":{"Open settings in":"Nastavenia v","the Pebble app.":"aplikácii Pebble."},"fr":{"Open settings in":"Réglages dans","the Pebble app.":"l’app Pebble.","opens activities.":"ouvre l’activité."},"it":{"Open settings in":"Impostazioni in"},"pt":{"Open settings in":"Definições na","the Pebble app.":"app Pebble."},"nl":{"Open settings in":"Instellingen in","the Pebble app.":"de Pebble-app."},"pl":{"Open settings in":"Ustawienia w","the Pebble app.":"aplikacji Pebble.","opens activities.":"otwiera aktyw."},"sv":{"Open settings in":"Inställningar i"},"no":{"Open settings in":"Innstillinger i"},"fi":{"Open settings in":"Avaa asetukset","the Pebble app.":"Pebble-appista."},"hu":{"opens activities.":"aktivitást nyit."},"ro":{"Open settings in":"Setări în","the Pebble app.":"aplicația Pebble.","opens activities.":"deschide activ."},"tr":{"the Pebble app.":"Pebble’dan."}},"nativeLayout":{"Open settings in":[24,168],"the Pebble app.":[24,168],"Quick Launch":[22,168],"opens activities.":[22,168]}}

/***/ })
/******/ ]);
//# sourceMappingURL=pebble-js-app.js.map