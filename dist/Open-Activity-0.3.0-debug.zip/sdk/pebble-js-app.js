/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;
/******/
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

	__webpack_require__(1);
	module.exports = __webpack_require__(2);


/***/ }),
/* 1 */
/***/ (function(module, exports) {

	/**
	 * Copyright 2024 Google LLC
	 *
	 * Licensed under the Apache License, Version 2.0 (the "License");
	 * you may not use this file except in compliance with the License.
	 * You may obtain a copy of the License at
	 *
	 *     http://www.apache.org/licenses/LICENSE-2.0
	 *
	 * Unless required by applicable law or agreed to in writing, software
	 * distributed under the License is distributed on an "AS IS" BASIS,
	 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	 * See the License for the specific language governing permissions and
	 * limitations under the License.
	 */
	
	(function(p) {
	  if (!p === undefined) {
	    console.error('Pebble object not found!?');
	    return;
	  }
	
	  // Aliases:
	  p.on = p.addEventListener;
	  p.off = p.removeEventListener;
	
	  // For Android (WebView-based) pkjs, print stacktrace for uncaught errors:
	  if (typeof window !== 'undefined' && window.addEventListener) {
	    window.addEventListener('error', function(event) {
	      if (event.error && event.error.stack) {
	        console.error('' + event.error + '\n' + event.error.stack);
	      }
	    });
	  }
	
	})(Pebble);


/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';
	
	var createLauncher = __webpack_require__(3);
	var settings = __webpack_require__(6);
	var uiSettings = __webpack_require__(7);
	var launcher = createLauncher({pebble: Pebble, storage: localStorage});
	
	Pebble.addEventListener('ready', function () { launcher.ready(); });
	Pebble.addEventListener('appmessage', function (event) { launcher.message(event && event.payload); });
	Pebble.addEventListener('showConfiguration', function () {
	  // Quick Launch does not need to initialize the legacy configuration page.
	  var page = __webpack_require__(9);
	  var current = settings.load(localStorage);
	  Pebble.openURL('data:text/html;charset=utf-8,' + encodeURIComponent(page(current || settings.defaults(), !current, uiSettings.load(localStorage))));
	});
	Pebble.addEventListener('webviewclosed', function (event) {
	  if (!event || !event.response) return;
	  try {
	    var text = event.response;
	    var response = JSON.parse(text.charAt(0) === '{' ? text : decodeURIComponent(text));
	    if (response && response.uiVersion === 1) {
	      var appearance = uiSettings.normalize(response.appearance);
	      var selected = settings.normalize(response.settings);
	      if (appearance && selected && settings.save(localStorage, selected) && uiSettings.save(localStorage, appearance)) launcher.appearanceChanged();
	    } else settings.save(localStorage, response);
	  } catch (error) {}
	});
	Pebble.addEventListener('configmessage', function (event) {
	  if (!event || typeof event.respond !== 'function') return;
	  var message = event.message || event.data || event.payload || event;
	  try {
	    if (typeof message === 'string') message = JSON.parse(message);
	    if (!message || message.type === 'getSettings' || message.type === 'load_settings') {
	      var current = settings.load(localStorage);
	      var loaded = {ok: true, settings: settings.choices(current || settings.defaults()),
	        needsRepair: !current, needsMigration: !!current && current.version === 1};
	      if (message && message.uiVersion === 1) {
	        var appearance = uiSettings.load(localStorage); loaded.appearance = appearance || uiSettings.defaults();
	        loaded.needsAppearanceRepair = !appearance;
	      }
	      event.respond(loaded);
	    } else if (message.type === 'saveSettings' || message.type === 'save_settings') {
	      var normalized = settings.normalize(message.settings);
	      var selected = normalized && settings.choices(normalized);
	      // Save through the active PKJS DOM and its native write-through store.
	      // Plugin-only writes can be replaced by Android's stale DOM at teardown.
	      var appearance = message.uiVersion === 1 ? uiSettings.normalize(message.appearance) : undefined;
	      if (!selected || message.uiVersion === 1 && !appearance) {event.respond(message.uiVersion === 1 ? {ok: false, rejected: true} : {ok: false}); return;}
	      if (!settings.save(localStorage, selected) || appearance && !uiSettings.save(localStorage, appearance)) {event.respond({ok: false}); return;}
	      var receipt = {ok: true, settings: selected};
	      if (appearance) {
	        receipt.appearance = appearance;
	        receipt.watchDelivery = launcher.appearanceChanged() ? 'queued' : 'deferred';
	      }
	      event.respond(receipt);
	    } else event.respond({ok: false});
	  } catch (error) { event.respond({ok: false}); }
	});


/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';
	
	var protocol = __webpack_require__(4);
	var navigation = __webpack_require__(5);
	var settings = __webpack_require__(6);
	var uiSettings = __webpack_require__(7);
	var createQueue = __webpack_require__(8);
	var operation = protocol.operation;
	var WATCH_STATE = '00000000-0000-0000-0001-000000000007';
	function uint32(value) {
	  return typeof value === 'number' && isFinite(value) && Math.floor(value) === value && value > 0 && value <= 4294967295;
	}
	
	module.exports = function (options) {
	  var pebble = options.pebble;
	  var now = options.now || function () { return Date.now(); };
	  var later = options.later || function (fn, delay) { return setTimeout(fn, delay); };
	  var cancelLater = options.cancelLater || function (id) { clearTimeout(id); };
	  // Keep generated wire values positive even on signed-int AppMessage bridges.
	  var ticket = options.ticket || function () { return Math.floor(Math.random() * 2147483647) + 1; };
	  var queue = createQueue(function (message, success, failure) { pebble.sendAppMessage(message, success, failure); });
	  var phase = 'idle', attempt = null, ready = false;
	
	  function stopSource(current) {
	    if (!current) return;
	    current.sourceDone = true;
	    if (current.source && typeof current.source.unsubscribe === 'function') {
	      try { current.source.unsubscribe(); } catch (error) {}
	    }
	    current.source = null;
	  }
	  function close(notify) {
	    if (phase === 'closed') return;
	    phase = 'closed'; queue.clear();
	    stopSource(attempt);
	    if (attempt && attempt.timer !== null) cancelLater(attempt.timer);
	    if (notify && attempt) queue.send(protocol.message(operation.CLOSE, {OA_SESSION: attempt.session}));
	  }
	  function current(value) { return attempt === value && phase !== 'closed' && now() < value.deadline; }
	  function sourceData(value, envelope) {
	    if (!current(value) || phase !== 'resolving') return;
	    var destination = navigation.resolve(envelope, value.role, now());
	    stopSource(value);
	    if (!destination) { close(true); return; }
	    value.destination = destination;
	    phase = 'preparing';
	    queue.send(protocol.message(operation.PREPARE, {
	      OA_SESSION: value.session, OA_TICKET: value.ticket,
	      OA_ROLE: protocol.role[value.role], OA_DESTINATION: destination.watchAppUuid
	    }), null, function () { if (current(value)) close(true); });
	  }
	  function start(message) {
	    if (phase !== 'idle') return;
	    var session = protocol.get(message, 'OA_SESSION');
	    var elapsed = protocol.get(message, 'OA_ELAPSED_MS');
	    var button = protocol.get(message, 'OA_BUTTON');
	    var gesture = protocol.get(message, 'OA_GESTURE');
	    var saved = settings.load(options.storage);
	    var role = gesture === protocol.gesture.hold || gesture === protocol.gesture.tap || gesture === protocol.gesture.combo ?
	      settings.select(saved, button, gesture) : null;
	    if (!uint32(session) || typeof elapsed !== 'number' || Math.floor(elapsed) !== elapsed ||
	        elapsed < 0 || elapsed >= protocol.budgetMs || !role) {
	      // A malformed hello never acquires a source or launches an app.
	      attempt = uint32(session) ? {session: session, timer: null} : null;
	      close(true); return;
	    }
	    var requestTicket = ticket();
	    if (!uint32(requestTicket)) { attempt = {session: session, timer: null}; close(true); return; }
	    attempt = {
	      session: session, ticket: requestTicket, role: role,
	      deadline: now() + protocol.budgetMs - elapsed,
	      destination: null, source: null, sourceDone: false, timer: null
	    };
	    var value = attempt;
	    phase = 'resolving';
	    value.timer = later(function () { if (attempt === value) close(true); }, protocol.budgetMs - elapsed);
	    if (typeof pebble.subscribeToSource !== 'function' || typeof pebble.invokeAction !== 'function') {
	      close(true); return;
	    }
	    try {
	      var source = pebble.subscribeToSource({
	        plugin: navigation.dynamicUuid,
	        category: 'navigation', item: 'presented_activities', properties: ['hint'],
	        onData: function (envelope) { sourceData(value, envelope); },
	        onError: function () { if (current(value) && phase === 'resolving') close(true); }
	      });
	      if (value.sourceDone || phase === 'closed') {
	        if (source && typeof source.unsubscribe === 'function') source.unsubscribe();
	      } else value.source = source;
	    } catch (error) { close(true); }
	  }
	  function confirm(message) {
	    var value = attempt;
	    if (!value || phase !== 'preparing' || !current(value)) return;
	    var elapsed = protocol.get(message, 'OA_ELAPSED_MS');
	    if (protocol.get(message, 'OA_SESSION') !== value.session ||
	        protocol.get(message, 'OA_TICKET') !== value.ticket ||
	        protocol.get(message, 'OA_ROLE') !== protocol.role[value.role] ||
	        protocol.get(message, 'OA_DESTINATION') !== value.destination.watchAppUuid) return;
	    if (typeof elapsed !== 'number' || Math.floor(elapsed) !== elapsed || elapsed < 0 ||
	        elapsed >= protocol.budgetMs || now() >= value.destination.expiresAtMs) { close(true); return; }
	    // State changes before invocation: duplicate confirmations can never dispatch twice.
	    phase = 'dispatched';
	    var pending;
	    try {
	      pending = pebble.invokeAction({
	        plugin: WATCH_STATE, action: 'launch_app', args: {uuid: value.destination.watchAppUuid},
	        timeoutMs: Math.max(1, Math.min(value.deadline - now(), protocol.budgetMs - elapsed))
	      });
	    } catch (error) { close(true); return; }
	    Promise.resolve(pending).then(function (result) {
	      if (attempt !== value || phase === 'closed') return;
	      if (!result || result.ok !== true) close(true);
	      // On success, the target replaces this native app. Never return to the face here.
	    }, function () { if (attempt === value && phase !== 'closed') close(true); });
	  }
	  return {
	    ready: function () {
	      if (ready || phase === 'closed') return;
	      ready = true;
	      var appearance = uiSettings.load(options.storage);
	      queue.send(protocol.message(operation.REQUEST, appearance ? {OA_THEME: appearance.theme === 'dark' ? 1 : 0} : {}), null, function () { close(false); });
	    },
	    message: function (message) {
	      var kind = protocol.get(message, 'OA_OPERATION');
	      if (kind === operation.HELLO) start(message);
	      else if (kind === operation.CONFIRM) confirm(message);
	      else if (kind === operation.CANCEL && attempt && protocol.get(message, 'OA_SESSION') === attempt.session) close(false);
	    },
	    appearanceChanged: function (complete) {
	      var appearance = uiSettings.load(options.storage);
	      if (!ready || phase !== 'idle' || !appearance) { if (complete) complete(false); return false; }
	      return queue.send(protocol.message(operation.SETTINGS, {OA_THEME: appearance.theme === 'dark' ? 1 : 0}),
	        function () { if (complete) complete(true); }, function () { if (complete) complete(false); });
	    },
	    cancel: function () { close(true); },
	    state: function () { return phase; }
	  };
	};


/***/ }),
/* 4 */
/***/ (function(module, exports) {

	'use strict';
	
	var keys = {
	  OA_OPERATION: 2000, OA_SESSION: 2001, OA_BUTTON: 2002,
	  OA_ROLE: 2003, OA_DESTINATION: 2004, OA_ELAPSED_MS: 2005, OA_TICKET: 2006,
	  OA_GESTURE: 2007, OA_THEME: 2008
	};
	module.exports = {
	  keys: keys,
	  operation: {REQUEST: 1, HELLO: 2, PREPARE: 3, CONFIRM: 4, CLOSE: 5, CANCEL: 6, SETTINGS: 7},
	  button: {back: 0, up: 1, select: 2, down: 3},
	  gesture: {hold: 1, tap: 2, combo: 3},
	  role: {primary: 1, secondary: 2},
	  budgetMs: 4000,
	  get: function (message, name) {
	    if (!message) return undefined;
	    return message[name] === undefined ? message[keys[name]] : message[name];
	  },
	  message: function (operation, values) {
	    var output = {}; output[keys.OA_OPERATION] = operation;
	    Object.keys(values || {}).forEach(function (name) { output[keys[name]] = values[name]; });
	    return output;
	  }
	};


/***/ }),
/* 5 */
/***/ (function(module, exports) {

	'use strict';
	
	var DYNAMIC = 'cc1281f1-3b4d-45b5-b235-6881b1fd8fbd';
	var HELPER = 'd2d0bf48-cf4c-42f6-8b5f-3657fb2de4e9';
	var ZERO = '00000000-0000-0000-0000-000000000000';
	function object(value) { return !!value && typeof value === 'object' && !Array.isArray(value); }
	function exact(value, fields) {
	  return object(value) && Object.keys(value).length === fields.length &&
	    Object.keys(value).every(function (key) { return fields.indexOf(key) !== -1; });
	}
	function integer(value, minimum, maximum) {
	  return typeof value === 'number' && isFinite(value) && Math.floor(value) === value &&
	    value >= minimum && value <= maximum;
	}
	function uuid(value) {
	  return typeof value === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(value) && value !== ZERO;
	}
	function utf8Bytes(text) {
	  var size = 0;
	  for (var i = 0; i < text.length; ++i) {
	    var ch = text.charCodeAt(i);
	    if (ch < 0x80) ++size;
	    else if (ch < 0x800) size += 2;
	    else if (ch >= 0xd800 && ch <= 0xdbff) {
	      if (++i >= text.length || text.charCodeAt(i) < 0xdc00 || text.charCodeAt(i) > 0xdfff) return Infinity;
	      size += 4;
	    } else if (ch >= 0xdc00 && ch <= 0xdfff) return Infinity;
	    else size += 3;
	  }
	  return size;
	}
	function destination(value) {
	  return value === null || (exact(value, ['watchAppUuid']) && uuid(value.watchAppUuid) && value.watchAppUuid !== HELPER);
	}
	function parseHint(text, now) {
	  // Every UTF-16 code unit needs at least one UTF-8 byte. Bound untrusted
	  // input before walking it, while retaining exact UTF-8/surrogate validation.
	  if (typeof text !== 'string' || text.length > 512 || utf8Bytes(text) > 512) return null;
	  var hint;
	  try { hint = JSON.parse(text); } catch (error) { return null; }
	  if (!exact(hint, ['schema', 'watchfaceUuid', 'nativeSession', 'viewSequence',
	      'presentationSequence', 'presentedAtMs', 'expiresAtMs', 'primary', 'secondary']) ||
	      hint.schema !== 1 || hint.watchfaceUuid !== DYNAMIC ||
	      !integer(hint.nativeSession, 1, 4294967295) ||
	      !integer(hint.viewSequence, 1, 4294967295) ||
	      !integer(hint.presentationSequence, 1, 4294967295) ||
	      !integer(hint.presentedAtMs, 1, 9007199254740991) ||
	      !integer(hint.expiresAtMs, 1, 9007199254740991) ||
	      !integer(now, 1, 9007199254740991) || hint.presentedAtMs > now ||
	      hint.expiresAtMs <= now || hint.expiresAtMs <= hint.presentedAtMs ||
	      hint.expiresAtMs - hint.presentedAtMs > 45000 ||
	      !destination(hint.primary) || !destination(hint.secondary)) return null;
	  return hint;
	}
	function resolve(envelope, role, now) {
	  if ((role !== 'primary' && role !== 'secondary') || !object(envelope) ||
	      envelope.pluginUuid !== DYNAMIC || !integer(envelope.validUntilMs, 1, 9007199254740991) ||
	      envelope.validUntilMs <= now || !Array.isArray(envelope.instances) || envelope.instances.length !== 1) return null;
	  var instance = envelope.instances[0];
	  if (!object(instance) || instance.instanceId !== 'current' || !object(instance.properties) ||
	      !object(instance.properties.hint) || !object(instance.properties.hint.longText)) return null;
	  var hint = parseHint(instance.properties.hint.longText.text, now);
	  if (!hint || envelope.validUntilMs > hint.expiresAtMs || !hint[role]) return null;
	  return {watchAppUuid: hint[role].watchAppUuid, expiresAtMs: Math.min(hint.expiresAtMs, envelope.validUntilMs)};
	}
	module.exports = {dynamicUuid: DYNAMIC, helperUuid: HELPER, uuid: uuid, utf8Bytes: utf8Bytes, parseHint: parseHint, resolve: resolve};


/***/ }),
/* 6 */
/***/ (function(module, exports) {

	'use strict';
	
	var KEY = 'open-activity-settings-v1';
	var SHORTCUTS = [
	  {id: 'hold-up', label: 'Hold Up', button: 1, gesture: 1},
	  {id: 'hold-select', label: 'Hold Center', button: 2, gesture: 1},
	  {id: 'hold-down', label: 'Hold Down', button: 3, gesture: 1},
	  {id: 'hold-back', label: 'Hold Back', button: 0, gesture: 1},
	  {id: 'tap-up', label: 'Tap Up', button: 1, gesture: 2},
	  {id: 'tap-down', label: 'Tap Down', button: 3, gesture: 2},
	  {id: 'combo-back-up', label: 'Hold Back + Up', button: 0, gesture: 3},
	  {id: 'combo-up-down', label: 'Hold Up + Down', button: 1, gesture: 3}
	];
	function role(value) { return value === 'primary' || value === 'secondary'; }
	function object(value) { return !!value && typeof value === 'object' && !Array.isArray(value); }
	function only(value, allowed) {
	  return Object.keys(value).every(function (key) { return allowed.indexOf(key) !== -1; });
	}
	function defaults() {
	  return {version: 2, primaryShortcut: 'hold-down', secondaryShortcut: 'hold-up'};
	}
	function shortcutId(value) {
	  if (value === 'none') return true;
	  return SHORTCUTS.some(function (shortcut) { return shortcut.id === value; });
	}
	function overrides(value, buttons) {
	  if (!object(value) || !only(value, buttons)) return null;
	  var output = {};
	  for (var i = 0; i < buttons.length; i++) {
	    var button = buttons[i];
	    if (!Object.prototype.hasOwnProperty.call(value, button)) continue;
	    var choice = value[button];
	    if (choice !== 'default' && !role(choice)) return null;
	    if (choice !== 'default') output[button] = choice;
	  }
	  return output;
	}
	function normalize(value) {
	  if (!object(value)) return null;
	  if (value.version === 2) {
	    if (!only(value, ['version', 'primaryShortcut', 'secondaryShortcut']) ||
	        !shortcutId(value.primaryShortcut) || !shortcutId(value.secondaryShortcut) ||
	        value.primaryShortcut !== 'none' && value.primaryShortcut === value.secondaryShortcut) return null;
	    return {version: 2, primaryShortcut: value.primaryShortcut, secondaryShortcut: value.secondaryShortcut};
	  }
	  if (!only(value, ['version', 'defaultRole', 'holdOverrides', 'tapOverrides', 'comboOverrides']) ||
	      value.version !== 1 || !role(value.defaultRole)) return null;
	  var holds = overrides(value.holdOverrides, ['up', 'down', 'select', 'back']);
	  var taps = value.tapOverrides === undefined ? {} : overrides(value.tapOverrides, ['up', 'down']);
	  var combos = value.comboOverrides === undefined ? {} : overrides(value.comboOverrides, ['backUp', 'upDown']);
	  if (!holds || !taps || !combos) return null;
	  var output = {version: 1, defaultRole: value.defaultRole, holdOverrides: holds};
	  if (Object.keys(taps).length) output.tapOverrides = taps;
	  if (Object.keys(combos).length) output.comboOverrides = combos;
	  return output;
	}
	function load(storage) {
	  try {
	    var value = storage.getItem(KEY);
	    return value === null || value === undefined ? defaults() : normalize(JSON.parse(value));
	  } catch (error) { return null; }
	}
	function save(storage, value) {
	  var settings = normalize(value);
	  if (!settings) return false;
	  try {
	    var encoded = JSON.stringify(settings);
	    storage.setItem(KEY, encoded);
	    return storage.getItem(KEY) === encoded;
	  } catch (error) { return false; }
	}
	function legacyOverride(settings, shortcut) {
	  var name = {0: 'back', 1: 'up', 2: 'select', 3: 'down'}[shortcut.button];
	  var chosen;
	  if (shortcut.gesture === 1) chosen = settings.holdOverrides;
	  else if (shortcut.gesture === 2) chosen = settings.tapOverrides;
	  else {
	    chosen = settings.comboOverrides;
	    name = shortcut.button === 0 ? 'backUp' : 'upDown';
	  }
	  return chosen && chosen[name];
	}
	function select(value, button, gesture) {
	  if (gesture === undefined) gesture = 1; // Existing callers select hold mappings.
	  var settings = normalize(value), shortcut;
	  if (!settings || typeof button !== 'number' || Math.floor(button) !== button) return null;
	  for (var i = 0; i < SHORTCUTS.length; i++) {
	    if (SHORTCUTS[i].button === button && SHORTCUTS[i].gesture === gesture) shortcut = SHORTCUTS[i];
	  }
	  if (!shortcut) return null;
	  if (settings.version === 1) return legacyOverride(settings, shortcut) || settings.defaultRole;
	  if (shortcut.id === settings.primaryShortcut) return 'primary';
	  if (shortcut.id === settings.secondaryShortcut) return 'secondary';
	  return null;
	}
	function choices(value) {
	  var settings = normalize(value);
	  if (!settings || settings.version === 2) return settings;
	  function choose(target, preferred) {
	    var matched = SHORTCUTS.filter(function (shortcut) {
	      return (legacyOverride(settings, shortcut) || settings.defaultRole) === target;
	    });
	    var explicit = matched.filter(function (shortcut) { return legacyOverride(settings, shortcut) === target; });
	    var preferredExplicit = explicit.filter(function (shortcut) { return shortcut.id === preferred; });
	    var preferredDefault = matched.filter(function (shortcut) { return shortcut.id === preferred; });
	    var selected = preferredExplicit[0] || explicit[0] || preferredDefault[0] || matched[0];
	    return selected ? selected.id : 'none';
	  }
	  return {version: 2, primaryShortcut: choose('primary', 'hold-down'), secondaryShortcut: choose('secondary', 'hold-up')};
	}
	module.exports = {key: KEY, shortcuts: SHORTCUTS, defaults: defaults, normalize: normalize,
	  choices: choices, load: load, save: save, select: select};


/***/ }),
/* 7 */
/***/ (function(module, exports) {

	'use strict';
	
	// UI preferences are independent of the version-1/version-2 shortcut record.
	// Reading or changing appearance never rewrites legacy routing bytes.
	var KEY = 'open-activity-ui-v1';
	function defaults() { return {version: 1, theme: 'light'}; }
	function normalize(value) {
	  if (!value || typeof value !== 'object' || Array.isArray(value) || value.version !== 1 ||
	      Object.keys(value).some(function(key) { return key !== 'version' && key !== 'theme'; }) ||
	      value.theme !== 'light' && value.theme !== 'dark') return null;
	  return {version: 1, theme: value.theme};
	}
	function load(storage) {
	  try {
	    var raw = storage.getItem(KEY);
	    return raw === null || raw === undefined ? defaults() : normalize(JSON.parse(raw));
	  } catch (error) { return null; }
	}
	function save(storage, value) {
	  var normalized = normalize(value);
	  if (!normalized) return false;
	  try {
	    var encoded = JSON.stringify(normalized);
	    if (storage.getItem(KEY) !== encoded) storage.setItem(KEY, encoded);
	    return storage.getItem(KEY) === encoded;
	  } catch (error) { return false; }
	}
	module.exports = {key: KEY, defaults: defaults, normalize: normalize, load: load, save: save};


/***/ }),
/* 8 */
/***/ (function(module, exports) {

	'use strict';
	
	// One bounded AppMessage queue. There are no retries or competing dispatchers.
	module.exports = function (send) {
	  var pending = [], busy = false;
	  function flush() {
	    if (busy || !pending.length) return;
	    var item = pending.shift(), settled = false;
	    busy = true;
	    function done(ok) {
	      if (settled) return;
	      settled = true; busy = false;
	      if (ok && item.success) item.success();
	      if (!ok && item.failure) item.failure();
	      flush();
	    }
	    try { send(item.message, function () { done(true); }, function () { done(false); }); }
	    catch (error) { done(false); }
	  }
	  return {
	    send: function (message, success, failure) {
	      if (pending.length >= 4) { if (failure) failure(); return false; }
	      pending.push({message: message, success: success, failure: failure}); flush(); return true;
	    },
	    clear: function () { pending = []; }
	  };
	};


/***/ }),
/* 9 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';
	
	var model = __webpack_require__(6);
	var uiModel = __webpack_require__(7);
	var translations = __webpack_require__(10);
	
	// Both settings paths use this layout. The build writes config.html from it.
	function behavior(initial) {
	  'use strict';
	  var primary = document.getElementById('primary'), secondary = document.getElementById('secondary');
	  var theme = document.getElementById('watch-theme'), delivery = document.getElementById('watch-delivery');
	  var appearanceSupported = false, appearanceRepair = false, savedAppearance = '';
	  var locale = typeof navigator !== 'undefined' && /^cs(?:[-_]|$)/i.test(navigator.language || '') ? 'cs' : 'en';
	  var dictionary = initial.translations && initial.translations[locale] || {};
	  function tr(text) { return dictionary[text] || text; }
	  if (document.documentElement) document.documentElement.lang = locale;
	  if (document.querySelectorAll) Array.prototype.forEach.call(document.querySelectorAll('[data-i18n]'), function(node) { node.textContent = tr(node.getAttribute('data-i18n')); });
	  var fields = [primary, secondary], form = document.getElementById('settings');
	  var save = document.getElementById('save'), discard = document.getElementById('discard');
	  var retry = document.getElementById('retry'), status = document.getElementById('status');
	  var actions = document.getElementById('actions'), conflict = document.getElementById('shortcut-error');
	  var assignment = document.getElementById('assignment-help');
	  var loaded = false, repairing = false, migrating = false, uncertain = false, saved = '', phase = 'loading';
	  var operation = 0, timer = null, bridgeReady = false, pkjsReady = false;
	  var layoutPending = false, lastFlow = null, lastHeight = null;
	  var legacy = initial.mode === 'legacy';
	  function shortcut(value) {
	    return ['none','hold-up','hold-select','hold-down','hold-back','tap-up','tap-down','combo-back-up','combo-up-down'].indexOf(value) !== -1;
	  }
	  function normalize(value) {
	    if (!value || typeof value !== 'object' || Array.isArray(value) || value.version !== 2 ||
	        Object.keys(value).some(function(name) { return ['version','primaryShortcut','secondaryShortcut'].indexOf(name) === -1; }) ||
	        !shortcut(value.primaryShortcut) || !shortcut(value.secondaryShortcut) ||
	        value.primaryShortcut !== 'none' && value.primaryShortcut === value.secondaryShortcut) return null;
	    return {version: 2, primaryShortcut: value.primaryShortcut, secondaryShortcut: value.secondaryShortcut};
	  }
	  function normalizeAppearance(value) {
	    if (!value || value.version !== 1 || value.theme !== 'light' && value.theme !== 'dark' ||
	        Object.keys(value).some(function(key) { return key !== 'version' && key !== 'theme'; })) return null;
	    return {version: 1, theme: value.theme};
	  }
	  function appearanceValue() { return appearanceSupported ? normalizeAppearance({version: 1, theme: theme.value}) : undefined; }
	  function value() {
	    return normalize({version: 2, primaryShortcut: primary.value, secondaryShortcut: secondary.value});
	  }
	  function edited() { return loaded && (JSON.stringify(value()) !== saved || appearanceSupported && JSON.stringify(appearanceValue()) !== savedAppearance); }
	  function dirty() { return loaded && (repairing || appearanceRepair || migrating || uncertain || edited()); }
	  function message(text, error) {
	    status.textContent = tr(text); status.className = error ? 'status error' : 'status';
	    layoutActions();
	  }
	  function layoutActions() {
	    if (typeof window === 'undefined' || typeof actions.getBoundingClientRect !== 'function') return;
	    if (layoutPending) return;
	    layoutPending = true;
	    // Status, viewport and ResizeObserver notifications may describe the same
	    // frame. Read geometry once after those changes and avoid unchanged writes.
	    if (typeof window.requestAnimationFrame === 'function') window.requestAnimationFrame(measureActions);
	    else setTimeout(measureActions, 0);
	  }
	  function measureActions() {
	    layoutPending = false;
	    var viewport = window.visualViewport && window.visualViewport.height || window.innerHeight;
	    var height = actions.getBoundingClientRect().height;
	    // A short viewport or large text needs a normal-flow action area. Keeping
	    // it fixed would cover the focused picker or the last help paragraph.
	    var inFlow = viewport < 560 || height > viewport * 0.28;
	    var flow = inFlow ? 'true' : 'false', reserved = (inFlow ? 0 : height) + 'px';
	    if (flow !== lastFlow) { actions.setAttribute('data-flow', flow); lastFlow = flow; }
	    if (reserved !== lastHeight) {
	      document.documentElement.style.setProperty('--actions-height', reserved); lastHeight = reserved;
	    }
	  }
	  function selectedLabel(field) {
	    for (var i = 0; i < field.options.length; i++)
	      if (field.options[i].value === field.value) return tr(field.options[i].textContent);
	    return '';
	  }
	  function describe() {
	    var duplicate = loaded && primary.value !== 'none' && primary.value === secondary.value;
	    conflict.hidden = !duplicate;
	    conflict.textContent = duplicate ? tr('Choose a different shortcut for each activity.') : '';
	    fields.forEach(function(field) {
	      document.getElementById(field.id + '-help').textContent = tr(!loaded ? 'Saved choice not loaded yet.' : field.value === 'none' ?
	        'No shortcut assigned.' : field.id === 'secondary' ? 'Opens the smaller activity row.' : 'Opens the large activity.');
	      field.options[0].textContent = tr(phase === 'load-error' ? 'Not loaded' : 'Loading saved choice…');
	      field.setAttribute('aria-invalid', duplicate ? 'true' : 'false');
	    });
	    var chosen = fields.filter(function(field) { return field.value && field.value !== 'none'; });
	    assignment.hidden = !!duplicate;
	    assignment.textContent = tr(!loaded ? 'Choose shortcuts, then assign Open Activity to them in Pebble’s Quick Launch settings.' :
	      duplicate ? 'Use a different shortcut for each activity before setting up Quick Launch.' :
	      !chosen.length ? 'No activity shortcut is enabled. Choose a shortcut above to open an activity.' :
	      'In Pebble’s Quick Launch settings, assign Open Activity to {shortcuts}.').replace('{shortcuts}', chosen.map(selectedLabel).join(tr(' and ')));
	    document.getElementById('watch-theme-help').textContent = tr(appearanceSupported ? 'Watch colours are independent of this phone page.' : 'Update Open Activity to change watch appearance.');
	  }
	  function controls() {
	    var editing = loaded && phase !== 'saving';
	    fields.forEach(function(field) { field.disabled = !editing; });
	    theme.disabled = !editing || !appearanceSupported;
	    save.disabled = !editing || !dirty() || !value() || appearanceSupported && !appearanceValue();
	    save.textContent = tr(phase === 'saving' ? 'Saving…' : 'Save');
	    discard.hidden = !legacy && !loaded;
	    discard.disabled = phase === 'saving' || !legacy && !uncertain && !edited();
	    discard.textContent = tr(legacy ? 'Cancel' : uncertain ? 'Reload saved' : 'Discard');
	    retry.hidden = phase !== 'load-error'; describe();
	  }
	  function changed() {
	    controls();
	    message(!value() ? 'Choose a different shortcut for each activity.' : uncertain ? 'Save not confirmed. Reload saved choices or save again.' :
	      edited() ? 'Unsaved changes.' : repairing || appearanceRepair ? 'Review these choices and save to repair unreadable settings.' :
	      migrating ? 'Save to use these two shortcuts.' : 'No changes to save.', !value() || uncertain);
	  }
	  function apply(settings, repair, migration, appearance, repairAppearance) {
	    primary.value = settings.primaryShortcut; secondary.value = settings.secondaryShortcut;
	    var normalizedAppearance = normalizeAppearance(appearance);
	    appearanceSupported = !!normalizedAppearance; appearanceRepair = repairAppearance === true;
	    theme.value = normalizedAppearance ? normalizedAppearance.theme : '';
	    savedAppearance = normalizedAppearance ? JSON.stringify(normalizedAppearance) : '';
	    delivery.hidden = true;
	    loaded = true; repairing = repair; migrating = migration; uncertain = false; saved = JSON.stringify(settings); phase = 'ready';
	    controls();
	    message(repair || appearanceRepair ? 'Saved settings could not be read. Review these choices before saving.' : migration ? 'Save to use these two shortcuts.' : 'No changes to save.', repair || appearanceRepair);
	  }
	  function stopTimer() { if (timer !== null) clearTimeout(timer); timer = null; }
	  function loadFailed() {
	    loaded = false; phase = 'load-error'; controls();
	    message('Could not load settings. Retry, or reopen this page from Pebble.', true);
	  }
	  function request(payload, complete, failed, target) {
	    var current = ++operation; stopTimer();
	    timer = setTimeout(function() { if (current === operation) { operation++; timer = null; failed(); } }, 6000);
	    function finish(callback, response) {
	      if (current !== operation) return;
	      operation++; stopTimer(); callback(response);
	    }
	    try {
	      var pending = Pebble.sendMessage(target || 'plugin', payload);
	      if (!pending || typeof pending.then !== 'function') { finish(failed); return; }
	      pending.then(function(response) { finish(complete, response); }, function() { finish(failed); });
	    } catch (error) { finish(failed); }
	  }
	  function load() {
	    var readback = uncertain;
	    loaded = false; phase = 'loading';
	    fields.forEach(function(field) { field.value = ''; }); theme.value = '';
	    controls(); message('Loading settings…');
	    if (!bridgeReady) { stopTimer(); timer = setTimeout(loadFailed, 6000); return; }
	    request({type: 'getSettings', uiVersion: 1}, function(response) {
	      var settings = response && response.ok === true && normalize(response.settings);
	      if (!settings || response.appearance !== undefined && !normalizeAppearance(response.appearance)) { loadFailed(); return; }
	      apply(settings, response.needsRepair === true, response.needsMigration === true, response.appearance, response.needsAppearanceRepair);
	      if (readback && !repairing && !appearanceRepair) message('Saved settings reloaded.');
	    }, loadFailed);
	  }
	  fields.forEach(function(field) { field.onchange = changed;
	    for (var i = 0; i < field.options.length; i++) field.options[i].textContent = tr(field.options[i].textContent);
	  });
	  theme.onchange = changed;
	  retry.onclick = load;
	  discard.onclick = function() {
	    if (legacy) location.href = 'pebblejs://close#';
	    else if (loaded && uncertain) load();
	    else if (loaded) apply(JSON.parse(saved), repairing, migrating, savedAppearance ? JSON.parse(savedAppearance) : undefined, appearanceRepair);
	  };
	  function saveFailed() {
	    uncertain = true; phase = 'ready'; controls();
	    message('Save not confirmed. Reload saved choices or save again.', true);
	  }
	  function settingsTarget(complete, failed) {
	    if (typeof Pebble.targets !== 'function') { complete(pkjsReady ? 'pkjs' : 'plugin'); return; }
	    var settled = false, lookupTimer = setTimeout(function() { finish(failed); }, 6000);
	    function finish(callback, target) { if (settled) return; settled = true; clearTimeout(lookupTimer); callback(target); }
	    try {
	      Promise.resolve(Pebble.targets()).then(function(targets) {
	        if (!Array.isArray(targets)) { finish(failed); return; }
	        finish(complete, targets.some(function(target) { return target && target.id === 'pkjs'; }) ? 'pkjs' : 'plugin');
	      }, function() { finish(failed); });
	    } catch (error) { finish(failed); }
	  }
	  form.onsubmit = function(event) {
	    if (event) event.preventDefault();
	    if (save.disabled) return;
	    var selected = value();
	    if (!selected) { saveFailed(); return; }
	    var selectedAppearance = appearanceValue();
	    if (legacy) { location.href = 'pebblejs://close#' + encodeURIComponent(JSON.stringify(selectedAppearance ? {uiVersion: 1, settings: selected, appearance: selectedAppearance} : selected)); return; }
	    phase = 'saving'; controls(); message('Saving…');
	    var attempts = 0;
	    function confirmed(settings, response) {
	      apply(settings, false, false, selectedAppearance); message('✓ Saved');
	      delivery.hidden = !selectedAppearance || response.watchDelivery !== 'deferred';
	    }
	    function write(target) {
	      if (++attempts > 3) { saveFailed(); return; }
	      var payload = {type: 'saveSettings', settings: selected};
	      if (selectedAppearance) { payload.uiVersion = 1; payload.appearance = selectedAppearance; }
	      request(payload, function(response) {
	        if (response && response.ok === false && response.rejected === true) {
	          uncertain = false; phase = 'ready'; controls(); message('Couldn’t save. Try again.', true); return;
	        }
	        var accepted = response && response.ok === true && normalize(response.settings);
	        if (!accepted || JSON.stringify(accepted) !== JSON.stringify(selected) || selectedAppearance &&
	            JSON.stringify(normalizeAppearance(response.appearance)) !== JSON.stringify(selectedAppearance)) { saveFailed(); return; }
	        // Android PKJS owns a restored DOM snapshot. Keep it synchronized before
	        // shutdown can persist that snapshot over the config plugin's store.
	        if (target === 'plugin') settingsTarget(function(current) { if (current === 'pkjs') write(current); else confirmed(accepted, response); }, saveFailed);
	        else confirmed(accepted, response);
	      }, function() {
	        if (target !== 'pkjs') { saveFailed(); return; }
	        settingsTarget(function(current) { if (current === 'plugin') write(current); else saveFailed(); }, saveFailed);
	      }, target);
	    }
	    settingsTarget(write, saveFailed);
	  };
	  save.onclick = function(event) { if (event) event.preventDefault(); form.onsubmit(); };
	  if (typeof window !== 'undefined') {
	    window.addEventListener('resize', layoutActions);
	    if (window.visualViewport) window.visualViewport.addEventListener('resize', layoutActions);
	    if (typeof ResizeObserver !== 'undefined') new ResizeObserver(layoutActions).observe(actions);
	  }
	  if (legacy) apply(initial.settings, initial.needsRepair, initial.needsMigration, initial.appearance, initial.needsAppearanceRepair);
	  else {
	    if (typeof Pebble !== 'undefined' && typeof Pebble.addEventListener === 'function') {
	      Pebble.addEventListener('ready', function(event) {
	        if (event && event.target === 'pkjs') { pkjsReady = true; return; }
	        if (event && event.target && event.target !== 'plugin') return;
	        if (bridgeReady) return;
	        bridgeReady = true; load();
	      });
	    }
	    load();
	  }
	}
	function render(initial) {
	  initial.translations = translations;
	  function picker(id, label) {
	    var options = '<option value="none" data-i18n="Not assigned">Not assigned</option>' + model.shortcuts.map(function(shortcut) {
	      return '<option value="' + shortcut.id + '">' + shortcut.label + '</option>';
	    }).join('');
	    return '<label data-i18n="' + label + '" for="' + id + '">' + label + '</label><select id="' + id + '" aria-describedby="' + id + '-help shortcut-error" disabled><option value="" disabled hidden selected data-i18n="Loading saved choice…">Loading saved choice…</option>' + options + '</select><p id="' + id + '-help" class="hint"></p>';
	  }
	  return [
	    '<!doctype html><html lang="en"><head><meta charset="utf-8">',
	    '<meta name="viewport" content="width=device-width,initial-scale=1"><title>Open Activity</title><style>',
	    ':root{color-scheme:light;--page:#f4f5f7;--card:#fff;--ink:#15181c;--muted:#5d6571;--line:#d9dee6;--accent:#6f42a9;--accent-ink:#fff;--field:#f4f5f7;--error:#a1231d}',
	    '@media(prefers-color-scheme:dark){:root{color-scheme:dark;--page:#11151b;--card:#1d232d;--ink:#f3f5f7;--muted:#b5bfcc;--line:#465165;--accent:#c9a7ff;--accent-ink:#211332;--field:#252e3b;--error:#ffb4ab}}',
	    '*{box-sizing:border-box}body{margin:0;background:var(--page);color:var(--ink);font:16px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}',
	    'html{scroll-padding-bottom:calc(var(--actions-height,144px) + 16px)}main{max-width:512px;margin:auto;padding:24px 16px calc(var(--actions-height,144px) + 24px)}h1{margin:0;font-size:28px;line-height:1.2;letter-spacing:-.6px}',
	    'header::after{content:"";display:block;width:48px;height:4px;border-radius:2px;background:var(--accent);margin:0 0 24px}header>p{color:var(--muted);margin:12px 0 24px}h2{margin:0 0 16px;font-size:20px;line-height:1.3;color:var(--ink)}p{margin:0 0 16px}',
	    '.card{margin:0 0 24px;padding:16px;background:var(--card);border:1px solid var(--line);border-radius:14px}',
	    'label{display:block;margin:16px 0 8px;font-weight:650}select,button{font:inherit;min-height:44px;border-radius:8px}',
	    'select{width:100%;padding:11px 10px;border:1px solid var(--line);background:var(--field);color:var(--ink)}',
	    'select[aria-invalid=true]{border-color:var(--error);box-shadow:0 0 0 1px var(--error)}.inline-error{margin:16px 0 0;font-size:14px;color:var(--error)}',
	    'button{padding:10px 12px;border:1px solid var(--line);background:var(--field);color:var(--ink);font-weight:650;cursor:pointer}',
	    'button:disabled{opacity:.45;cursor:default}select:disabled{opacity:.6}button:focus-visible,select:focus-visible,summary:focus-visible{outline:3px solid var(--accent);outline-offset:3px}',
	    '.hint{font-size:14px;color:var(--muted);margin:8px 0 0}.intro{color:var(--muted);font-size:14px}',
	    'details>summary{min-height:44px;display:list-item;align-content:center;cursor:pointer;font-weight:650}details.card>summary{color:var(--ink);font-size:17px}details[open]>summary{margin-bottom:16px}',
	    '.help ol{margin:12px 0 16px;padding-left:22px}.help li{padding-left:3px;margin:9px 0}.help p{color:var(--muted);font-size:14px}.help p:last-child{margin-bottom:0}',
	    'footer{position:fixed;bottom:0;left:0;right:0;padding:12px 16px max(16px,env(safe-area-inset-bottom));background:var(--page);border-top:1px solid var(--line)}footer[data-flow=true]{position:static}',
	    '.footer-inner{max-width:480px;margin:auto}.status{font-size:14px;color:var(--muted);text-align:left;margin:0 0 10px;min-height:20px}.status.error{color:var(--error)}',
	    '.actions{display:flex;gap:8px}.actions button{flex:1;min-width:0;overflow-wrap:anywhere}footer[data-flow=true] .actions{flex-direction:column}#save{min-height:48px;background:var(--accent);border-color:var(--accent);color:var(--accent-ink)}',
	    'button,select{transition:background-color 144ms ease-out,border-color 144ms ease-out}button:not(:disabled):active{transform:translateY(1px)}details[open]>:not(summary){animation:disclose 160ms ease-out}@keyframes disclose{from{opacity:0;transform:translateY(-3px)}to{opacity:1;transform:translateY(0)}}@media(prefers-reduced-motion:reduce){button,select{transition:none}button:not(:disabled):active{transform:none}details[open]>:not(summary){animation:none}}',
	    '.sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}[hidden]{display:none!important}@media(max-width:340px){main{padding-left:12px;padding-right:12px}.card{padding-left:14px;padding-right:14px}footer{padding-left:12px;padding-right:12px}.actions button{font-size:15px}}',
	    '@media(max-width:260px){.actions{flex-direction:column}select{min-width:0}main{padding-top:16px}}',
	    '</style></head><body><main><header><h1>Open Activity</h1><p data-i18n="Choose a shortcut for each activity.">Choose a shortcut for each activity.</p></header>',
	    '<form id="settings"><section class="card" aria-labelledby="shortcuts-heading"><h2 id="shortcuts-heading" data-i18n="Activity shortcuts">Activity shortcuts</h2>',
	    picker('primary', 'Primary activity'), picker('secondary', 'Secondary activity'),
	    '<p id="shortcut-error" class="inline-error" hidden></p><p id="assignment-help" class="intro" style="margin-top:20px"></p></section>',
	    '<section class="card" aria-labelledby="appearance-heading"><h2 id="appearance-heading" data-i18n="Watch appearance">Watch appearance</h2><label class="sr-only" for="watch-theme" data-i18n="Watch appearance">Watch appearance</label><select id="watch-theme" disabled aria-describedby="watch-theme-help watch-delivery"><option value="" disabled hidden selected data-i18n="Loading saved choice…">Loading saved choice…</option><option value="light" data-i18n="Light">Light</option><option value="dark" data-i18n="Dark">Dark</option></select><p id="watch-theme-help" class="hint"></p><p id="watch-delivery" class="hint" data-i18n="Watch appearance will update when Open Activity next opens." hidden>Watch appearance will update when Open Activity next opens.</p></section>',
	    '</form><details class="card help"><summary data-i18n="Setup & help">Setup &amp; help</summary><ol><li data-i18n="Install the current Dynamic build.">Install the current Dynamic build.</li><li data-i18n="Allow Open Activity to launch apps in the Pebble phone app.">Allow Open Activity to launch apps in the Pebble phone app.</li><li data-i18n="In Pebble’s Quick Launch settings, assign this same Open Activity app to each shortcut you want to use.">In Pebble’s Quick Launch settings, assign this same Open Activity app to each shortcut you want to use.</li></ol>',
	    '<p data-i18n="Use one connected watch. This opens Dynamic’s recent selection, including briefly after changing watchfaces.">Use one connected watch. This opens Dynamic’s recent selection, including briefly after changing watchfaces.</p>',
	    '<p data-i18n="A missing or expired activity returns to the watchface. It never substitutes Primary for a missing Secondary.">A missing or expired activity returns to the watchface. It never substitutes Primary for a missing Secondary.</p>',
	    '<p data-i18n="These choices apply when the shortcut is assigned to Open Activity. Other Quick Launch assignments stay as you set them.">These choices apply when the shortcut is assigned to Open Activity. Other Quick Launch assignments stay as you set them.</p>',
	    '<p data-i18n="Open Activity from the watch’s app list stays open for setup. Open its settings in the Pebble phone app, then press Back on the watch when finished. Assigned Quick Launch shortcuts still open activities automatically.">Open Activity from the watch’s app list stays open for setup. Open its settings in the Pebble phone app, then press Back on the watch when finished. Assigned Quick Launch shortcuts still open activities automatically.</p>',
	    '<p data-i18n="Back cancels while Opening… is shown. A launch already sent to the phone may still finish.">Back cancels while Opening… is shown. A launch already sent to the phone may still finish.</p>',
	    initial.mode === 'legacy' ? '<p class="hint" data-i18n="This legacy settings route closes after Save. Reopen settings to check the saved choices.">This legacy settings route closes after Save. Reopen settings to check the saved choices.</p>' : '',
	    '</details></main><footer id="actions"><div class="footer-inner"><p id="status" class="status" role="status" aria-live="polite" data-i18n="Loading settings…">Loading settings…</p><div class="actions">',
	    '<button id="retry" type="button" hidden data-i18n="Retry loading">Retry loading</button><button id="discard" type="button" disabled data-i18n="Discard">Discard</button><button id="save" type="submit" form="settings" disabled data-i18n="Save">Save</button>',
	    '</div></div></footer><script>(', behavior.toString(), ')(', JSON.stringify(initial).replace(/</g, '\\u003c'), ');</script></body></html>'
	  ].join('\n');
	}
	module.exports = function(settings, invalid, appearance) {
	  var current = model.normalize(settings) || model.defaults();
	  return render({mode: 'legacy', settings: model.choices(current), needsRepair: !!invalid, needsMigration: current.version === 1, appearance: appearance || uiModel.defaults(), needsAppearanceRepair: appearance === null});
	};
	module.exports.config = function() { return render({mode: 'plugin'}); };


/***/ }),
/* 10 */
/***/ (function(module, exports) {

	'use strict';
	
	// Phone configuration UI; source-provided names and the app name stay intact.
	module.exports = {cs: {
	  'Choose a shortcut for each activity.': 'Vyberte zkratku pro každou aktivitu.',
	  'Activity shortcuts': 'Zkratky aktivit', 'Primary activity': 'Hlavní aktivita',
	  'Secondary activity': 'Vedlejší aktivita', 'Not assigned': 'Nepřiřazeno',
	  'Loading saved choice…': 'Načítání uložené volby…', 'Not loaded': 'Nenačteno',
	  'Saved choice not loaded yet.': 'Uložená volba ještě není načtena.',
	  'No shortcut assigned.': 'Není přiřazena žádná zkratka.',
	  'Opens the smaller activity row.': 'Otevře aktivitu v menším řádku.',
	  'Opens the large activity.': 'Otevře hlavní aktivitu.',
	  'Choose a different shortcut for each activity.': 'Pro každou aktivitu vyberte jinou zkratku.',
	  'Choose shortcuts, then assign Open Activity to them in Pebble’s Quick Launch settings.': 'Vyberte zkratky a potom jim v nastavení rychlého spuštění Pebble přiřaďte Open Activity.',
	  'Use a different shortcut for each activity before setting up Quick Launch.': 'Před nastavením rychlého spuštění vyberte pro každou aktivitu jinou zkratku.',
	  'No activity shortcut is enabled. Choose a shortcut above to open an activity.': 'Žádná zkratka není zapnutá. Pro otevření aktivity vyberte zkratku výše.',
	  'In Pebble’s Quick Launch settings, assign Open Activity to {shortcuts}.': 'V nastavení rychlého spuštění Pebble přiřaďte Open Activity ke zkratkám: {shortcuts}.',
	  ' and ': ' a ', 'Hold Up': 'Podržení horního', 'Hold Center': 'Podržení prostředního',
	  'Hold Down': 'Podržení dolního', 'Hold Back': 'Podržení Zpět', 'Tap Up': 'Stisk horního',
	  'Tap Down': 'Stisk dolního', 'Hold Back + Up': 'Podržení Zpět + horního',
	  'Hold Up + Down': 'Podržení horního + dolního',
	  'Watch appearance': 'Vzhled hodinek', 'Light': 'Světlý', 'Dark': 'Tmavý',
	  'Watch colours are independent of this phone page.': 'Barvy hodinek jsou nezávislé na vzhledu této stránky.',
	  'Update Open Activity to change watch appearance.': 'Pro změnu vzhledu aktualizujte Open Activity.',
	  'Watch appearance will update when Open Activity next opens.': 'Vzhled hodinek se aktualizuje při příštím otevření Open Activity.',
	  'No changes to save.': 'Žádné změny k uložení.', 'Unsaved changes.': 'Neuložené změny.',
	  'Saving…': 'Ukládání…', '✓ Saved': '✓ Uloženo', 'Save': 'Uložit', 'Discard': 'Zahodit',
	  'Cancel': 'Zrušit', 'Reload saved': 'Načíst uložené', 'Retry loading': 'Zkusit načíst znovu',
	  'Loading settings…': 'Načítání nastavení…',
	  'Couldn’t save. Try again.': 'Uložení se nezdařilo. Zkuste to znovu.',
	  'Save not confirmed. Reload saved choices or save again.': 'Uložení není potvrzeno. Načtěte uložené volby nebo uložení opakujte.',
	  'Review these choices and save to repair unreadable settings.': 'Zkontrolujte volby a uložením opravte nečitelné nastavení.',
	  'Saved settings could not be read. Review these choices before saving.': 'Uložené nastavení nelze přečíst. Před uložením zkontrolujte volby.',
	  'Save to use these two shortcuts.': 'Uložením začnete používat tyto dvě zkratky.',
	  'Could not load settings. Retry, or reopen this page from Pebble.': 'Nastavení nelze načíst. Zkuste to znovu nebo stránku znovu otevřete z Pebble.',
	  'Saved settings reloaded.': 'Uložené nastavení bylo znovu načteno.',
	  'Setup & help': 'Nastavení a nápověda',
	  'Install the current Dynamic build.': 'Nainstalujte aktuální sestavení Dynamic.',
	  'Allow Open Activity to launch apps in the Pebble phone app.': 'V aplikaci Pebble v telefonu povolte Open Activity spouštět aplikace.',
	  'In Pebble’s Quick Launch settings, assign this same Open Activity app to each shortcut you want to use.': 'V nastavení rychlého spuštění Pebble přiřaďte stejnou aplikaci Open Activity ke každé požadované zkratce.',
	  'Use one connected watch. This opens Dynamic’s recent selection, including briefly after changing watchfaces.': 'Používejte jedny připojené hodinky. Otevře se poslední výběr Dynamic, i krátce po změně ciferníku.',
	  'A missing or expired activity returns to the watchface. It never substitutes Primary for a missing Secondary.': 'Chybějící nebo neplatná aktivita vás vrátí na ciferník. Chybějící vedlejší aktivita se nenahradí hlavní.',
	  'These choices apply when the shortcut is assigned to Open Activity. Other Quick Launch assignments stay as you set them.': 'Volby platí pro zkratky přiřazené Open Activity. Ostatní přiřazení rychlého spuštění zůstávají beze změny.',
	  'Open Activity from the watch’s app list stays open for setup. Open its settings in the Pebble phone app, then press Back on the watch when finished. Assigned Quick Launch shortcuts still open activities automatically.': 'Při spuštění ze seznamu aplikací zůstane Open Activity otevřená pro nastavení. Otevřete její nastavení v telefonu a po dokončení stiskněte na hodinkách Zpět. Přiřazené zkratky dál otevírají aktivity automaticky.',
	  'Back cancels while Opening… is shown. A launch already sent to the phone may still finish.': 'Při zobrazení Otevírání… lze akci zrušit tlačítkem Zpět. Spuštění již odeslané do telefonu může být dokončeno.',
	  'This legacy settings route closes after Save. Reopen settings to check the saved choices.': 'Tato starší cesta nastavení se po uložení zavře. Uložené volby zkontrolujte opětovným otevřením nastavení.'
	}};


/***/ })
/******/ ]);
//# sourceMappingURL=pebble-js-app.js.map